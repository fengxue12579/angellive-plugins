// ============================================================
// StripChat AngelLive Plugin v1.4.0
// 新增：瑟瑟聚合Worker线路（高画质1080p/720p）、画质排序优化
// ============================================================

var _SC_BASE_URL = "https://go.mavrtracktor.com";
var _SC_PAGE_URL = "https://zh.stripchat.global";
var _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

var _SC_CDN_URL = "https://edge-hls.growcdnssedge.com";
var _SC_CF_WORKER_URL = "https://stripchat-proxy.6h8jr4dgcb.workers.dev";

// 瑟瑟聚合 Worker（提供签名高画质 1080p/720p 等）
// 通过自己的 CF Worker 代理访问（解决被墙问题）
var _SC_ADULTLIVE_WORKER = "https://stripchat-proxy.6h8jr4dgcb.workers.dev/alproxy";

// ============================================================
// 工具函数
// ============================================================

function _sc_makeError(code, message, context) {
  if (globalThis.Host && typeof Host.makeError === "function") {
    return Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

function _sc_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw _sc_makeError(code, message, context);
}

// 将原始 CDN URL 转换为 CF Worker 代理 URL
function _sc_convertToProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL) return originalUrl;
  if (!originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  var hostname = "";
  var pathAndQuery = "";
  if (slashIndex === -1) {
    hostname = withoutProtocol;
    pathAndQuery = "";
  } else {
    hostname = withoutProtocol.substring(0, slashIndex);
    pathAndQuery = withoutProtocol.substring(slashIndex);
  }

  if (!hostname) return originalUrl;
  return _SC_CF_WORKER_URL + "/proxy/" + hostname + pathAndQuery;
}

// 从画质 key 提取分辨率数值，用于排序
// 例如 "480p" -> 480, "original" -> 9999 (原画最高)
function _sc_qualityValue(key) {
  if (key === "original") return 9999;
  var match = String(key).match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

// 画质排序：从高到低
function _sc_sortQualitys(qualitys) {
  return qualitys.sort(function(a, b) {
    return b.qn - a.qn;
  });
}

// ============================================================
// 分类定义
// ============================================================

function _sc_getCategoryDefinitions() {
  return [
    {
      id: "girls/chinese",
      parentId: "",
      title: "女主播",
      icon: "",
      biz: "girls/chinese",
      subList: [
        { id: "girls/chinese", parentId: "girls/chinese", title: "中国女孩", icon: "", biz: "girls/chinese" },
        { id: "girls/japanese", parentId: "girls/chinese", title: "日本女孩", icon: "", biz: "girls/japanese" },
        { id: "girls/korean", parentId: "girls/chinese", title: "韩国女孩", icon: "", biz: "girls/korean" },
        { id: "girls/american", parentId: "girls/chinese", title: "美国女孩", icon: "", biz: "girls/american" },
        { id: "girls/russian", parentId: "girls/chinese", title: "俄罗斯女孩", icon: "", biz: "girls/russian" },
        { id: "girls/new", parentId: "girls/chinese", title: "最新女主播", icon: "", biz: "girls/new" }
      ]
    },
    {
      id: "couples/chinese",
      parentId: "",
      title: "情侣",
      icon: "",
      biz: "couples/chinese",
      subList: [
        { id: "couples/chinese", parentId: "couples/chinese", title: "中国情侣", icon: "", biz: "couples/chinese" },
        { id: "couples/popular", parentId: "couples/chinese", title: "热门情侣", icon: "", biz: "couples/popular" }
      ]
    },
    {
      id: "men/popular",
      parentId: "",
      title: "男主播",
      icon: "",
      biz: "men/popular",
      subList: [
        { id: "men/popular", parentId: "men/popular", title: "最受欢迎", icon: "", biz: "men/popular" },
        { id: "men/gays", parentId: "men/popular", title: "男同聊天", icon: "", biz: "men/gays" }
      ]
    },
    {
      id: "girls/recommended",
      parentId: "",
      title: "推荐",
      icon: "",
      biz: "girls/recommended",
      subList: [
        { id: "girls/recommended", parentId: "girls/recommended", title: "全部推荐", icon: "", biz: "girls/recommended" }
      ]
    },
    {
      id: "girls/popular",
      parentId: "",
      title: "热门",
      icon: "",
      biz: "girls/popular",
      subList: [
        { id: "girls/popular", parentId: "girls/popular", title: "全部热门", icon: "", biz: "girls/popular" }
      ]
    },
    {
      id: "couples/group-sex",
      parentId: "",
      title: "群交直播",
      icon: "",
      biz: "couples/group-sex",
      subList: [
        { id: "couples/group-sex", parentId: "couples/group-sex", title: "全部群交", icon: "", biz: "couples/group-sex" }
      ]
    },
    {
      id: "couples/lesbians",
      parentId: "",
      title: "女同",
      icon: "",
      biz: "couples/lesbians",
      subList: [
        { id: "couples/lesbians", parentId: "couples/lesbians", title: "全部女同", icon: "", biz: "couples/lesbians" }
      ]
    },
    {
      id: "girls/vr",
      parentId: "",
      title: "VR",
      icon: "",
      biz: "girls/vr",
      subList: [
        { id: "girls/vr", parentId: "girls/vr", title: "全部VR", icon: "", biz: "girls/vr" }
      ]
    },
    {
      id: "trans/popular",
      parentId: "",
      title: "变性人",
      icon: "",
      biz: "trans/popular",
      subList: [
        { id: "trans/popular", parentId: "trans/popular", title: "全部变性人", icon: "", biz: "trans/popular" }
      ]
    },
    {
      id: "girls/new",
      parentId: "",
      title: "新主播",
      icon: "",
      biz: "girls/new",
      subList: [
        { id: "girls/new", parentId: "girls/new", title: "全部新主播", icon: "", biz: "girls/new" }
      ]
    }
  ];
}

// ============================================================
// API 请求
// ============================================================

function _sc_fetchModels(cateId, page) {
  var limit = 200;
  var offset = (page - 1) * limit;
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=" + limit
    + "&offset=" + offset
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

function _sc_searchModels(keyword) {
  var url = _SC_BASE_URL + "/api/models"
    + "?q=" + encodeURIComponent(keyword)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=200"
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

// ============================================================
// 核心功能
// ============================================================

function _sc_getCategories() {
  return Promise.resolve(_sc_getCategoryDefinitions());
}

function _sc_getRooms(cateId, page) {
  return _sc_fetchModels(cateId, page).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: String(m.snapshotUrl || ""),
        userHeadImg: String(m.avatarUrl || m.snapshotUrl || ""),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_getRoomDetail(roomId) {
  return _sc_fetchModels("girls/popular", 1).then(function (models) {
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }
    if (!found) {
      _sc_throw("NOT_FOUND", "room not found", { roomId: String(roomId) });
    }
    return {
      roomId: String(found.id || ""),
      userId: String(found.id || ""),
      userName: String(found.username || ""),
      roomTitle: String(found.username || ""),
      roomCover: String(found.snapshotUrl || ""),
      userHeadImg: String(found.avatarUrl || found.snapshotUrl || ""),
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: String(found.viewersCount || "0")
    };
  });
}

// 构建单个画质对象
function _sc_buildQuality(roomId, title, qn, url, headers) {
  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: "m3u8",
    liveType: "stripchat",
    headers: headers,
    playbackHints: {
      streamFormat: "hlsLive",
      selectionBehavior: "direct"
    }
  };
}

// 从 stream.urls 构建画质列表，按分辨率从高到低排序
function _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers) {
  var qualitys = [];
  var urlKeys = Object.keys(streamUrls);

  for (var k = 0; k < urlKeys.length; k++) {
    var key = urlKeys[k];
    var playUrl = streamUrls[key];
    if (!playUrl) continue;

    var qnValue = _sc_qualityValue(key);
    var title = key === "original" ? "原画" : key.toUpperCase();

    qualitys.push(_sc_buildQuality(roomId, title, qnValue, playUrl, headers));
  }

  // 按分辨率从高到低排序
  return _sc_sortQualitys(qualitys);
}

// 从瑟瑟聚合 Worker 获取签名高画质（1080p/720p 等）
function _sc_fetchAdultliveQualities(roomId, headers) {
  var qualitiesURL = _SC_ADULTLIVE_WORKER + "/qualities?room=" + encodeURIComponent(String(roomId));

  return Host.http.request({
    url: qualitiesURL,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": "https://stripchat.com/"
    },
    timeout: 30
  }).then(function (resp) {
    if (resp.status !== 200) return [];
    var obj = JSON.parse(resp.bodyText || "{}");
    var list = obj.qualitys || obj.qualities || [];
    var qualitys = [];
    for (var i = 0; i < list.length; i++) {
      var item = list[i] || {};
      var url = String(item.url || "");
      var title = String(item.title || "").trim() || "Auto";
      var qn = Number(item.qn || 0);
      // 接受 Worker 域名下的 URL（带签名或 master）
      if (url && (url.indexOf("stripchatparse") > -1 || url.indexOf("/alproxy") > -1)) {
        qualitys.push(_sc_buildQuality(roomId, title, qn, url, headers));
      }
    }
    return qualitys;
  }).then(function (qualitys) {
    // 按分辨率从高到低排序
    return _sc_sortQualitys(qualitys);
  }).then(null, function () {
    return [];
  });
}

function _sc_getPlayback(roomId) {
  // 直接从 API 获取主播数据（不请求房间页，防 Cloudflare）
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }

    var headers = {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    };

    // 从API获取真实画质URL
    var streamUrls = {};
    var modelUsername = "";  // 瑟瑟聚合 Worker 需要 username 而不是数字 roomId
    if (found && found.stream && found.stream.urls) {
      streamUrls = found.stream.urls;
    }
    if (found && found.username) {
      modelUsername = String(found.username);
    }

    var defaultQualitys = [];
    var proxyQualitys = [];

    if (Object.keys(streamUrls).length > 0) {
      // 有 API 返回的画质，按分辨率排序
      defaultQualitys = _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers);

      // 构建 CF 代理线路（同样排序）
      for (var j = 0; j < defaultQualitys.length; j++) {
        var q = defaultQualitys[j];
        var proxyUrl = _sc_convertToProxyUrl(q.url);
        if (proxyUrl !== q.url) {
          proxyQualitys.push(_sc_buildQuality(roomId, q.title, q.qn, proxyUrl, headers));
        }
      }
    }

    // 如果API没返回画质，使用默认 master 地址作为 Auto 兜底
    if (defaultQualitys.length === 0) {
      var masterUrl = _SC_CDN_URL + "/hls/"
        + encodeURIComponent(String(roomId))
        + "/master/"
        + encodeURIComponent(String(roomId))
        + "_480p.m3u8?playlistType=lowLatency";

      // Auto 放在最后
      defaultQualitys.push(_sc_buildQuality(roomId, "Auto", 0, masterUrl, headers));

      var proxyMasterUrl = _sc_convertToProxyUrl(masterUrl);
      if (proxyMasterUrl !== masterUrl) {
        proxyQualitys.push(_sc_buildQuality(roomId, "Auto", 0, proxyMasterUrl, headers));
      }
    }

    // 如果没有固定清晰度，只有 Auto，直接返回
    // 如果有固定清晰度，在列表末尾添加 Auto master 作为兜底
    if (defaultQualitys.length > 1 || (defaultQualitys.length === 1 && defaultQualitys[0].title !== "Auto")) {
      var autoMasterUrl = _SC_CDN_URL + "/hls/"
        + encodeURIComponent(String(roomId))
        + "/master/"
        + encodeURIComponent(String(roomId))
        + "_480p.m3u8?playlistType=lowLatency";
      defaultQualitys.push(_sc_buildQuality(roomId, "Auto", 0, autoMasterUrl, headers));

      var proxyAutoUrl = _sc_convertToProxyUrl(autoMasterUrl);
      if (proxyAutoUrl !== autoMasterUrl) {
        proxyQualitys.push(_sc_buildQuality(roomId, "Auto", 0, proxyAutoUrl, headers));
      }
    }

    var results = [];

    // 第一条线路：瑟瑟聚合 Worker（高画质 1080p/720p）— 默认
    // 第二条线路：直连 growcdn — 备用
    // 第三条线路：CF Worker 代理 — 备用

    // 先尝试获取瑟瑟聚合 Worker 高画质（需要 username）
    var workerRoom = modelUsername || String(roomId);
    // 高画质线路需要用 stripchat.com 的 Referer（Worker 播放会校验）
    var alHeaders = {
      "User-Agent": _SC_USER_AGENT,
      "Referer": "https://stripchat.com/" + workerRoom,
      "Origin": "https://stripchat.com"
    };
    return _sc_fetchAdultliveQualities(workerRoom, alHeaders).then(function (alQualitys) {
      if (alQualitys.length > 0) {
        // 高画质可用，作为默认线路
        var alMasterUrl = _SC_ADULTLIVE_WORKER + "/master?room=" + encodeURIComponent(workerRoom);
        alQualitys.push(_sc_buildQuality(roomId, "Auto", 0, alMasterUrl, alHeaders));
        results.push({
          cdn: "adultlive",
          displayName: "高画质",
          qualitys: alQualitys
        });
      } else {
        // 高画质不可用，直连作为默认
        results.push({
          cdn: "growcdn",
          displayName: "默认线路",
          qualitys: defaultQualitys
        });
      }

      // 添加备用线路
      if (alQualitys.length > 0) {
        // 高画质是默认，直连作为备用
        results.push({
          cdn: "growcdn",
          displayName: "直连备用",
          qualitys: defaultQualitys
        });
      }

      if (proxyQualitys.length > 0) {
        results.push({
          cdn: "cfproxy",
          displayName: "CF加速",
          qualitys: proxyQualitys
        });
      }

      return results;
    });
  });
}

function _sc_refreshPlayback(roomId, cdnId, qn) {
  var cdn = String(cdnId || "growcdn");
  var playUrl = "";
  var title = "480P";

  if (cdn === "adultlive") {
    // 瑟瑟聚合 Worker 线路
    playUrl = _SC_ADULTLIVE_WORKER + "/master?room=" + encodeURIComponent(String(roomId));
    title = "Auto";
  } else if (cdn === "cfproxy") {
    // CF 代理线路
    playUrl = _SC_CDN_URL + "/hls/"
      + encodeURIComponent(String(roomId))
      + "/master/"
      + encodeURIComponent(String(roomId))
      + "_480p.m3u8?playlistType=lowLatency";
    playUrl = _sc_convertToProxyUrl(playUrl);
  } else {
    // 默认直连线路
    playUrl = _SC_CDN_URL + "/hls/"
      + encodeURIComponent(String(roomId))
      + "/master/"
      + encodeURIComponent(String(roomId))
      + "_480p.m3u8?playlistType=lowLatency";
  }

  return Promise.resolve({
    roomId: String(roomId),
    title: title,
    qn: 0,
    url: playUrl,
    liveCodeType: "m3u8",
    liveType: "stripchat",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    playbackHints: {
      streamFormat: "hlsLive",
      selectionBehavior: "direct"
    }
  });
}

function _sc_search(keyword) {
  return _sc_searchModels(keyword).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: String(m.snapshotUrl || ""),
        userHeadImg: String(m.avatarUrl || m.snapshotUrl || ""),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_resolveShare(shareCode) {
  var input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  var username = "";
  var patterns = [
    /stripchat\.(?:global|com)\/([\w]+)/,
    /\/([\w]+)$/
  ];

  for (var p = 0; p < patterns.length; p++) {
    var m = input.match(patterns[p]);
    if (m && m[1]) {
      username = m[1];
      break;
    }
  }

  if (!username && /^[a-zA-Z0-9_]+$/.test(input)) {
    username = input;
  }

  if (!username) {
    _sc_throw("NOT_FOUND", "cannot extract username from shareCode", { shareCode: input });
  }

  return Promise.resolve({
    roomId: username,
    userId: username,
    userName: username,
    roomTitle: username,
    roomCover: "",
    userHeadImg: "",
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: "0"
  });
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function () {
    return _sc_getCategories();
  },

  getRooms: function (payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _sc_getRooms(id, page);
  },

  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getPlayback(roomId);
  },

  refreshPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    var cdn = String((payload && payload.cdn) || "");
    var quality = (payload && payload.quality) || {};
    var qualityContext = quality.requestContext || {};
    var qn = Number(qualityContext.qn !== undefined ? qualityContext.qn : quality.qn || 0);
    var cdnId = String(qualityContext.cdn || cdn || "growcdn");

    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_refreshPlayback(roomId, cdnId, qn);
  },

  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getRoomDetail(roomId);
  },

  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return Promise.resolve({ liveState: "1" });
  },

  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _sc_search(keyword);
  },

  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _sc_resolveShare(shareCode);
  },

  clearCredential: function () {
    return Promise.resolve({ ok: true });
  },

  setCredential: function () {
    return Promise.resolve({ ok: true });
  }
};
