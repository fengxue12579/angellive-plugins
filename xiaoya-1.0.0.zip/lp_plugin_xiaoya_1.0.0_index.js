// ============================================================
// 小雅直播 AngelLive Plugin v1.0.0
// 整合多源M3U直播资源，自动去重，分类聚合
// ============================================================

var _XY_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

// M3U源地址
var _XY_M3U_SOURCES = [
  "https://aaa.6h8jr4dgcb.workers.dev/live.m3u",
  "https://7236.6h8jr4dgcb.workers.dev/live.m3u"
];

// ============================================================
// 工具函数
// ============================================================

function _xy_makeError(code, message, context) {
  if (globalThis.Host && typeof Host.makeError === "function") {
    return Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

function _xy_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw _xy_makeError(code, message, context);
}

// 网络请求封装
function _xy_httpRequest(url, headers, timeout, retries) {
  retries = retries || 2;
  timeout = timeout || 30;
  headers = headers || {};

  function attempt(remain) {
    return Host.http.request({
      platformId: "xiaoya",
      authMode: "none",
      request: {
        url: url,
        method: "GET",
        headers: headers,
        timeout: timeout
      }
    }).then(function(resp) {
      if (resp.status >= 500 && remain > 0) {
        return attempt(remain - 1);
      }
      return resp;
    }).then(null, function(err) {
      if (remain > 0) {
        return attempt(remain - 1);
      }
      throw err;
    });
  }

  return attempt(retries);
}

// 解析M3U内容，返回频道列表
function _xy_parseM3U(m3uText, sourceIndex) {
  var channels = [];
  var lines = String(m3uText || "").split(/\r?\n/);
  var currentExtInf = null;
  var sourceLabel = "源" + (sourceIndex + 1);

  for (var i = 0; i < lines.length; i++) {
    var line = String(lines[i]).trim();
    if (!line || line.indexOf("#") === 0) {
      // 处理 EXTINF 行
      if (line.indexOf("#EXTINF:") === 0) {
        currentExtInf = _xy_parseExtInf(line);
      }
      continue;
    }

    // 非注释行且前面有EXTINF，则为URL
    if (currentExtInf) {
      currentExtInf.url = line;
      currentExtInf.source = sourceLabel;
      channels.push(currentExtInf);
      currentExtInf = null;
    }
  }

  return channels;
}

// 解析 #EXTINF 行
function _xy_parseExtInf(line) {
  var result = {
    title: "",
    groupTitle: "未分类",
    logo: "",
    tvgId: "",
    tvgName: "",
    duration: -1
  };

  // 提取 duration
  var durationMatch = line.match(/#EXTINF:\s*([-\d\.]+)/);
  if (durationMatch) {
    result.duration = parseFloat(durationMatch[1]);
  }

  // 提取 group-title
  var groupMatch = line.match(/group-title="([^"]*)"/i);
  if (groupMatch) {
    result.groupTitle = groupMatch[1].trim() || "未分类";
  }

  // 提取 tvg-logo
  var logoMatch = line.match(/tvg-logo="([^"]*)"/i);
  if (logoMatch) {
    result.logo = logoMatch[1].trim();
  }

  // 提取 tvg-id
  var tvgIdMatch = line.match(/tvg-id="([^"]*)"/i);
  if (tvgIdMatch) {
    result.tvgId = tvgIdMatch[1].trim();
  }

  // 提取 tvg-name
  var tvgNameMatch = line.match(/tvg-name="([^"]*)"/i);
  if (tvgNameMatch) {
    result.tvgName = tvgNameMatch[1].trim();
  }

  // 提取 title（逗号后面的内容）
  var commaIndex = line.lastIndexOf(",");
  if (commaIndex >= 0) {
    result.title = line.substring(commaIndex + 1).trim();
  }

  return result;
}

// 标准化频道名称用于去重
function _xy_normalizeChannelKey(channel) {
  var title = String(channel.title || "").trim();
  // 去除常见后缀、空格，转小写
  title = title.replace(/\s+/g, "").toLowerCase();
  title = title.replace(/【.*?】/g, "");
  title = title.replace(/\[.*?\]/g, "");
  title = title.replace(/\(.*?\)/g, "");
  title = title.replace(/（.*?）/g, "");
  title = title.replace(/hd$/i, "");
  title = title.replace(/fhd$/i, "");
  title = title.replace(/\d+p$/i, "");
  return title;
}

// 合并去重多个源的频道
function _xy_mergeChannels(allChannelsList) {
  var merged = {};

  for (var s = 0; s < allChannelsList.length; s++) {
    var channels = allChannelsList[s];
    for (var i = 0; i < channels.length; i++) {
      var ch = channels[i];
      var key = _xy_normalizeChannelKey(ch);
      if (!key) continue;

      if (!merged[key]) {
        merged[key] = {
          title: ch.title,
          groupTitle: ch.groupTitle,
          logo: ch.logo,
          tvgId: ch.tvgId,
          tvgName: ch.tvgName,
          urls: [],
          sources: []
        };
      }

      // 去重URL
      var urlExists = false;
      for (var u = 0; u < merged[key].urls.length; u++) {
        if (merged[key].urls[u] === ch.url) {
          urlExists = true;
          break;
        }
      }
      if (!urlExists && ch.url) {
        merged[key].urls.push(ch.url);
        merged[key].sources.push(ch.source);
      }
    }
  }

  return merged;
}

// 将合并后的频道映射到分类
function _xy_mapToCategories(mergedChannels) {
  var categories = {
    "comprehensive": [],   // 综合
    "tw": [],              // 台湾
    "anchor": [],          // 主播
    "uncategorized": []    // 未分类
  };

  var keys = Object.keys(mergedChannels);
  for (var i = 0; i < keys.length; i++) {
    var ch = mergedChannels[keys[i]];
    var group = String(ch.groupTitle || "未分类").trim();
    var title = String(ch.title || "").trim();

    // 判断分类逻辑
    var lowerGroup = group.toLowerCase();
    var lowerTitle = title.toLowerCase();

    // 台湾相关关键词
    var twKeywords = ["tw", "台湾", "台视", "中视", "华视", "民视", "公视", "tvbs", "中天", "东森", "三立", "非凡", "年代", "纬来", "客家", "原住民族", "大爱", "好消息", "唯心", "环球", "镜电视", "寰宇"];
    var isTW = false;
    for (var t = 0; t < twKeywords.length; t++) {
      if (lowerGroup.indexOf(twKeywords[t]) >= 0 || lowerTitle.indexOf(twKeywords[t]) >= 0) {
        isTW = true;
        break;
      }
    }

    // 主播相关关键词
    var anchorKeywords = ["主播", "网红", "女神", "美女", "模特", "秀", "直播", "live", "show", "诱惑", "性感", "热舞", "清纯", "萝莉", "御姐", "少妇"];
    var isAnchor = false;
    for (var a = 0; a < anchorKeywords.length; a++) {
      if (lowerGroup.indexOf(anchorKeywords[a]) >= 0 || lowerTitle.indexOf(anchorKeywords[a]) >= 0) {
        isAnchor = true;
        break;
      }
    }

    // 用户上传的直播.m3u中的特定频道也归入tw
    var specialTWChannels = ["惊艳", "潘朵拉完美", "香蕉", "松視1台", "松視2台", "松視3台"];
    for (var s = 0; s < specialTWChannels.length; s++) {
      if (title.indexOf(specialTWChannels[s]) >= 0) {
        isTW = true;
        break;
      }
    }

    if (isTW) {
      categories.tw.push(ch);
    } else if (isAnchor) {
      categories.anchor.push(ch);
    } else if (group === "未分类" || lowerGroup === "undefined" || lowerGroup === "") {
      categories.uncategorized.push(ch);
    } else {
      categories.comprehensive.push(ch);
    }
  }

  return categories;
}

// ============================================================
// 分类定义
// ============================================================

function _xy_getCategoryDefinitions() {
  return [
    {
      id: "comprehensive",
      title: "综合",
      icon: "",
      biz: "comprehensive",
      subList: [
        { id: "comprehensive", parentId: "comprehensive", title: "全部综合", icon: "", biz: "comprehensive" }
      ]
    },
    {
      id: "tw",
      title: "台湾",
      icon: "",
      biz: "tw",
      subList: [
        { id: "tw", parentId: "tw", title: "全部台湾", icon: "", biz: "tw" },
        { id: "tw_tv", parentId: "tw", title: "台湾电视", icon: "", biz: "tw_tv" },
        { id: "tw_adult", parentId: "tw", title: "台湾成人", icon: "", biz: "tw_adult" }
      ]
    },
    {
      id: "anchor",
      title: "主播",
      icon: "",
      biz: "anchor",
      subList: [
        { id: "anchor", parentId: "anchor", title: "全部主播", icon: "", biz: "anchor" },
        { id: "anchor_hot", parentId: "anchor", title: "热门主播", icon: "", biz: "anchor_hot" },
        { id: "anchor_new", parentId: "anchor", title: "新晋主播", icon: "", biz: "anchor_new" }
      ]
    },
    {
      id: "uncategorized",
      title: "未分类",
      icon: "",
      biz: "uncategorized",
      subList: [
        { id: "uncategorized", parentId: "uncategorized", title: "全部未分类", icon: "", biz: "uncategorized" }
      ]
    }
  ];
}

// ============================================================
// 数据获取
// ============================================================

// 获取所有M3U源数据并合并
function _xy_fetchAllSources() {
  var promises = [];

  for (var i = 0; i < _XY_M3U_SOURCES.length; i++) {
    (function(index) {
      var p = _xy_httpRequest(_XY_M3U_SOURCES[index], {
        "User-Agent": _XY_USER_AGENT
      }, 30, 2).then(function(resp) {
        if (resp.status === 200 && resp.bodyText) {
          return _xy_parseM3U(resp.bodyText, index);
        }
        return [];
      }).then(null, function(err) {
        return [];
      });
      promises.push(p);
    })(i);
  }

  return Promise.all(promises).then(function(results) {
    var merged = _xy_mergeChannels(results);
    return _xy_mapToCategories(merged);
  });
}

// 缓存机制
var _xy_cache = {
  categories: null,
  timestamp: 0,
  ttl: 5 * 60 * 1000 // 5分钟缓存
};

function _xy_getCachedCategories() {
  var now = Date.now();
  if (_xy_cache.categories && (now - _xy_cache.timestamp) < _xy_cache.ttl) {
    return Promise.resolve(_xy_cache.categories);
  }

  return _xy_fetchAllSources().then(function(categories) {
    _xy_cache.categories = categories;
    _xy_cache.timestamp = now;
    return categories;
  });
}

// ============================================================
// 核心功能实现
// ============================================================

function _xy_getCategories() {
  return Promise.resolve(_xy_getCategoryDefinitions());
}

function _xy_getRooms(cateId, page) {
  return _xy_getCachedCategories().then(function(categories) {
    var targetCate = String(cateId || "").trim();
    var allRooms = [];

    // 根据分类ID获取对应频道
    if (targetCate === "comprehensive" || targetCate === "comprehensive_all") {
      allRooms = categories.comprehensive || [];
    } else if (targetCate === "tw" || targetCate === "tw_all") {
      allRooms = categories.tw || [];
    } else if (targetCate.indexOf("tw_") === 0) {
      allRooms = categories.tw || [];
    } else if (targetCate === "anchor" || targetCate === "anchor_all") {
      allRooms = categories.anchor || [];
    } else if (targetCate.indexOf("anchor_") === 0) {
      allRooms = categories.anchor || [];
    } else if (targetCate === "uncategorized" || targetCate === "uncategorized_all") {
      allRooms = categories.uncategorized || [];
    } else {
      // 默认返回所有
      allRooms = (categories.comprehensive || [])
        .concat(categories.tw || [])
        .concat(categories.anchor || [])
        .concat(categories.uncategorized || []);
    }

    // 分页
    var pageSize = 50;
    var startIndex = (page - 1) * pageSize;
    var endIndex = startIndex + pageSize;
    var pageRooms = allRooms.slice(startIndex, endIndex);

    return pageRooms.map(function(ch, index) {
      var roomId = _xy_generateRoomId(ch, startIndex + index);
      return {
        roomId: roomId,
        userId: roomId,
        userName: ch.title || "未知频道",
        roomTitle: ch.title || "未知频道",
        roomCover: ch.logo || "",
        userHeadImg: ch.logo || "",
        liveType: "xiaoya",
        liveState: "1",
        liveWatchedCount: "0",
        groupTitle: ch.groupTitle || "未分类"
      };
    });
  });
}

// 生成稳定的roomId
function _xy_generateRoomId(ch, index) {
  var base = String(ch.title || "").trim() || ("channel_" + index);
  var hash = 0;
  for (var i = 0; i < base.length; i++) {
    var char = base.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return "xy_" + Math.abs(hash);
}

function _xy_getRoomDetail(roomId) {
  return _xy_getCachedCategories().then(function(categories) {
    var allChannels = (categories.comprehensive || [])
      .concat(categories.tw || [])
      .concat(categories.anchor || [])
      .concat(categories.uncategorized || []);

    for (var i = 0; i < allChannels.length; i++) {
      var ch = allChannels[i];
      var expectedId = _xy_generateRoomId(ch, i);
      if (expectedId === roomId) {
        return {
          roomId: roomId,
          userId: roomId,
          userName: ch.title || "未知频道",
          roomTitle: ch.title || "未知频道",
          roomCover: ch.logo || "",
          userHeadImg: ch.logo || "",
          liveType: "xiaoya",
          liveState: "1",
          liveWatchedCount: "0"
        };
      }
    }

    _xy_throw("NOT_FOUND", "room not found", { roomId: roomId });
  });
}

function _xy_getPlayback(roomId) {
  return _xy_getCachedCategories().then(function(categories) {
    var allChannels = (categories.comprehensive || [])
      .concat(categories.tw || [])
      .concat(categories.anchor || [])
      .concat(categories.uncategorized || []);

    for (var i = 0; i < allChannels.length; i++) {
      var ch = allChannels[i];
      var expectedId = _xy_generateRoomId(ch, i);
      if (expectedId === roomId) {
        var qualitys = [];
        for (var u = 0; u < (ch.urls || []).length; u++) {
          qualitys.push({
            roomId: roomId,
            title: u === 0 ? "原画" : ("线路" + (u + 1)),
            qn: u === 0 ? 9999 : (9999 - u),
            url: ch.urls[u],
            liveCodeType: "m3u8",
            liveType: "xiaoya",
            userAgent: _XY_USER_AGENT,
            headers: {
              "Referer": "https://xiaoya.live/"
            }
          });
        }

        if (qualitys.length === 0) {
          _xy_throw("PLAYBACK_ERROR", "no playback url found", { roomId: roomId });
        }

        return [{
          cdn: "default",
          displayName: "默认线路",
          qualitys: qualitys
        }];
      }
    }

    _xy_throw("NOT_FOUND", "room not found for playback", { roomId: roomId });
  });
}

function _xy_search(keyword) {
  var kw = String(keyword || "").trim().toLowerCase();
  if (!kw) return Promise.resolve([]);

  return _xy_getCachedCategories().then(function(categories) {
    var allChannels = (categories.comprehensive || [])
      .concat(categories.tw || [])
      .concat(categories.anchor || [])
      .concat(categories.uncategorized || []);

    var results = [];
    for (var i = 0; i < allChannels.length; i++) {
      var ch = allChannels[i];
      var title = String(ch.title || "").toLowerCase();
      var group = String(ch.groupTitle || "").toLowerCase();

      if (title.indexOf(kw) >= 0 || group.indexOf(kw) >= 0) {
        var roomId = _xy_generateRoomId(ch, i);
        results.push({
          roomId: roomId,
          userId: roomId,
          userName: ch.title || "未知频道",
          roomTitle: ch.title || "未知频道",
          roomCover: ch.logo || "",
          userHeadImg: ch.logo || "",
          liveType: "xiaoya",
          liveState: "1",
          liveWatchedCount: "0"
        });
      }
    }

    return results;
  });
}

function _xy_getLiveState(roomId) {
  return Promise.resolve({ liveState: "1" });
}

function _xy_resolveShare(shareCode) {
  _xy_throw("NOT_SUPPORTED", "share resolve is not supported", { shareCode: shareCode });
}

function _xy_getDanmaku(payload) {
  return { args: {}, headers: null };
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function() {
    return _xy_getCategories();
  },

  getRooms: function(payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _xy_throw("INVALID_ARGS", "id is required", { field: "id" });
    if (page < 1) page = 1;
    return _xy_getRooms(id, page);
  },

  getPlayback: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getPlayback(roomId);
  },

  getRoomDetail: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getRoomDetail(roomId);
  },

  getLiveState: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getLiveState(roomId);
  },

  search: function(payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _xy_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _xy_search(keyword);
  },

  resolveShare: function(payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _xy_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _xy_resolveShare(shareCode);
  },

  getDanmaku: function(payload) {
    return Promise.resolve(_xy_getDanmaku(payload));
  }
};
