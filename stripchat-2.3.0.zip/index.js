// ============================================================
// StripChat AngelLive Plugin v2.3.0
// 移植 Python 版 MOUFLON 解密，通过 CF Worker 解密代理获取高画质
// 使用 _auto.m3u8 master playlist + MOUFLON 解密参数
// ============================================================

var _SC_BASE_URL = "https://go.mavrtracktor.com";
var _SC_PAGE_URL = "https://zh.stripchat.global";
var _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

var _SC_CDN_URL = "https://edge-hls.growcdnssedge.com";
var _SC_CF_WORKER_URL = "https://stripchat-proxy.fengxue556.ccwu.cc";

// ============================================================
// 工具函数
// ============================================================

function _sc_makeError(code, message, context) {
  if (globalThis.Host && typeof Host.makeError === "function") {
    return Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

function _sc_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw _sc_makeError(code, message, context);
}

// 将原始 CDN URL 转换为 CF Worker 代理 URL
function _sc_convertToProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL) return originalUrl;
  if (!originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  var hostname = "";
  var pathAndQuery = "";
  if (slashIndex === -1) {
    hostname = withoutProtocol;
    pathAndQuery = "";
  } else {
    hostname = withoutProtocol.substring(0, slashIndex);
    pathAndQuery = withoutProtocol.substring(slashIndex);
  }

  if (!hostname) return originalUrl;
  return _SC_CF_WORKER_URL + "/proxy/" + hostname + pathAndQuery;
}

// 将 m3u8 URL 转换为 CF Worker MOUFLON 解密代理 URL
function _sc_convertToM3u8ProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL) return originalUrl;
  if (!originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  var hostname = "";
  var pathAndQuery = "";
  if (slashIndex === -1) {
    hostname = withoutProtocol;
    pathAndQuery = "";
  } else {
    hostname = withoutProtocol.substring(0, slashIndex);
    pathAndQuery = withoutProtocol.substring(slashIndex);
  }

  if (!hostname) return originalUrl;
  return _SC_CF_WORKER_URL + "/m3u8/" + hostname + pathAndQuery;
}

// 从画质 key 提取分辨率数值，用于排序
// 例如 "1080p60" -> 1080, "720p" -> 720, "480p" -> 480, "original" -> 9999
function _sc_qualityValue(key) {
  if (key === "original") return 9999;
  var match = String(key).match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

// 从 preset 字符串提取显示标题
// 例如 "1080p60" -> "1080p60", "720p" -> "720p"
function _sc_presetTitle(preset) {
  return String(preset || "").replace(/_blurred$/, "模糊");
}

// 从 hlsPlaylist URL 提取 CDN 域名和路径前缀
function _sc_extractCdnBase(hlsPlaylistUrl) {
  if (!hlsPlaylistUrl) return "";
  // 匹配 https://edge-hls.xxx.com/hls/123/master/123_240p.m3u8
  var match = String(hlsPlaylistUrl).match(/^(https?:\/\/[^\/]+\/hls\/\d+\/master\/)/);
  return match ? match[1] : "";
}

// 画质排序：从高到低
function _sc_sortQualitys(qualitys) {
  return qualitys.sort(function(a, b) {
    return b.qn - a.qn;
  });
}

// ============================================================
// 分类定义
// ============================================================

function _sc_getCategoryDefinitions() {
  return [
    {
      id: "girls/chinese",
      parentId: "",
      title: "女主播",
      icon: "",
      biz: "girls/chinese",
      subList: [
        { id: "girls/chinese", parentId: "girls/chinese", title: "中国女孩", icon: "", biz: "girls/chinese" },
        { id: "girls/japanese", parentId: "girls/chinese", title: "日本女孩", icon: "", biz: "girls/japanese" },
        { id: "girls/korean", parentId: "girls/chinese", title: "韩国女孩", icon: "", biz: "girls/korean" },
        { id: "girls/american", parentId: "girls/chinese", title: "美国女孩", icon: "", biz: "girls/american" },
        { id: "girls/russian", parentId: "girls/chinese", title: "俄罗斯女孩", icon: "", biz: "girls/russian" },
        { id: "girls/new", parentId: "girls/chinese", title: "最新女主播", icon: "", biz: "girls/new" }
      ]
    },
    {
      id: "couples/chinese",
      parentId: "",
      title: "情侣",
      icon: "",
      biz: "couples/chinese",
      subList: [
        { id: "couples/chinese", parentId: "couples/chinese", title: "中国情侣", icon: "", biz: "couples/chinese" },
        { id: "couples/popular", parentId: "couples/chinese", title: "热门情侣", icon: "", biz: "couples/popular" }
      ]
    },
    {
      id: "men/popular",
      parentId: "",
      title: "男主播",
      icon: "",
      biz: "men/popular",
      subList: [
        { id: "men/popular", parentId: "men/popular", title: "最受欢迎", icon: "", biz: "men/popular" },
        { id: "men/gays", parentId: "men/popular", title: "男同聊天", icon: "", biz: "men/gays" }
      ]
    },
    {
      id: "girls/recommended",
      parentId: "",
      title: "推荐",
      icon: "",
      biz: "girls/recommended",
      subList: [
        { id: "girls/recommended", parentId: "girls/recommended", title: "全部推荐", icon: "", biz: "girls/recommended" }
      ]
    },
    {
      id: "girls/popular",
      parentId: "",
      title: "热门",
      icon: "",
      biz: "girls/popular",
      subList: [
        { id: "girls/popular", parentId: "girls/popular", title: "全部热门", icon: "", biz: "girls/popular" }
      ]
    },
    {
      id: "couples/group-sex",
      parentId: "",
      title: "群交直播",
      icon: "",
      biz: "couples/group-sex",
      subList: [
        { id: "couples/group-sex", parentId: "couples/group-sex", title: "全部群交", icon: "", biz: "couples/group-sex" }
      ]
    },
    {
      id: "couples/lesbians",
      parentId: "",
      title: "女同",
      icon: "",
      biz: "couples/lesbians",
      subList: [
        { id: "couples/lesbians", parentId: "couples/lesbians", title: "全部女同", icon: "", biz: "couples/lesbians" }
      ]
    },
    {
      id: "girls/vr",
      parentId: "",
      title: "VR",
      icon: "",
      biz: "girls/vr",
      subList: [
        { id: "girls/vr", parentId: "girls/vr", title: "全部VR", icon: "", biz: "girls/vr" }
      ]
    },
    {
      id: "trans/popular",
      parentId: "",
      title: "变性人",
      icon: "",
      biz: "trans/popular",
      subList: [
        { id: "trans/popular", parentId: "trans/popular", title: "全部变性人", icon: "", biz: "trans/popular" }
      ]
    },
    {
      id: "girls/new",
      parentId: "",
      title: "新主播",
      icon: "",
      biz: "girls/new",
      subList: [
        { id: "girls/new", parentId: "girls/new", title: "全部新主播", icon: "", biz: "girls/new" }
      ]
    }
  ];
}

// ============================================================
// API 请求
// ============================================================

function _sc_fetchModels(cateId, page) {
  var limit = 200;
  var offset = (page - 1) * limit;
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=" + limit
    + "&offset=" + offset
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

function _sc_searchModels(keyword) {
  var url = _SC_BASE_URL + "/api/models"
    + "?q=" + encodeURIComponent(keyword)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=200"
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

// ============================================================
// 核心功能
// ============================================================

function _sc_getCategories() {
  return Promise.resolve(_sc_getCategoryDefinitions());
}

function _sc_getRooms(cateId, page) {
  return _sc_fetchModels(cateId, page).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: String(m.snapshotUrl || ""),
        userHeadImg: String(m.avatarUrl || m.snapshotUrl || ""),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_getRoomDetail(roomId) {
  return _sc_fetchModels("girls/popular", 1).then(function (models) {
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }
    if (!found) {
      _sc_throw("NOT_FOUND", "room not found", { roomId: String(roomId) });
    }
    return {
      roomId: String(found.id || ""),
      userId: String(found.id || ""),
      userName: String(found.username || ""),
      roomTitle: String(found.username || ""),
      roomCover: String(found.snapshotUrl || ""),
      userHeadImg: String(found.avatarUrl || found.snapshotUrl || ""),
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: String(found.viewersCount || "0")
    };
  });
}

// 构建单个画质对象（userAgent 独立字段，headers 中不重复）
function _sc_buildQuality(roomId, title, qn, url, headers) {
  // 从 headers 中提取 User-Agent 到独立字段（文档要求不重复）
  var ua = "";
  var cleanHeaders = {};
  if (headers) {
    for (var key in headers) {
      if (headers.hasOwnProperty(key)) {
        if (key.toLowerCase() === "user-agent") {
          ua = String(headers[key]);
        } else {
          cleanHeaders[key] = headers[key];
        }
      }
    }
  }
  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: "m3u8",
    liveType: "stripchat",
    userAgent: ua || _SC_USER_AGENT,
    headers: cleanHeaders,
    playbackHints: {
      streamFormat: "hlsLive",
      selectionBehavior: "direct"
    }
  };
}

// 从 stream.urls 构建画质列表，按分辨率从高到低排序
function _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers) {
  var qualitys = [];
  var urlKeys = Object.keys(streamUrls);

  for (var k = 0; k < urlKeys.length; k++) {
    var key = urlKeys[k];
    var playUrl = streamUrls[key];
    if (!playUrl) continue;

    var qnValue = _sc_qualityValue(key);
    var title = key === "original" ? "原画" : key.toUpperCase();

    qualitys.push(_sc_buildQuality(roomId, title, qnValue, playUrl, headers));
  }

  // 按分辨率从高到低排序
  return _sc_sortQualitys(qualitys);
}

// ============================================================
// HLS Master Playlist 解析（学习瑟瑟聚合平台4）
// ============================================================

// 解析 HLS 属性行，提取 key=value
function _sc_parseHLSAttributes(line) {
  var attrs = {};
  var start = line.indexOf(":");
  var body = start >= 0 ? line.substring(start + 1) : line;
  var re = /([A-Z0-9-]+)=("[^"]*"|[^,]*)/gi;
  var match;
  while ((match = re.exec(body)) !== null) {
    attrs[match[1].toUpperCase()] = String(match[2]).replace(/^"|"$/g, "");
  }
  return attrs;
}

// 从 RESOLUTION 提取高度（如 "1920x1080" → 1080）
function _sc_variantHeight(attrs) {
  var resolution = String(attrs && attrs.RESOLUTION || "");
  var match = resolution.match(/x(\d{3,4})/i);
  return match ? parseInt(match[1], 10) : 0;
}

// 找到 #EXT-X-STREAM-INF 下一行的 URI
function _sc_nextPlaylistURI(lines, start) {
  for (var i = start; i < lines.length; i++) {
    var line = String(lines[i]).trim();
    if (!line || line.charAt(0) === "#") continue;
    return line;
  }
  return "";
}

// 将相对 URI 转为绝对 URL
function _sc_resolveURL(uri, baseURL) {
  if (!uri) return "";
  if (uri.indexOf("http://") === 0 || uri.indexOf("https://") === 0) return uri;
  var base = baseURL;
  if (base.indexOf("?") > -1) base = base.substring(0, base.indexOf("?"));
  if (base.indexOf("#") > -1) base = base.substring(0, base.indexOf("#"));
  if (uri.charAt(0) === "/") {
    var protocolEnd = base.indexOf("://");
    var hostStart = protocolEnd + 3;
    var pathStart = base.indexOf("/", hostStart);
    var root = pathStart > 0 ? base.substring(0, pathStart) : base;
    return root + uri;
  }
  var lastSlash = base.lastIndexOf("/");
  var dir = lastSlash >= 0 ? base.substring(0, lastSlash + 1) : base + "/";
  return dir + uri;
}

// 解析 HLS master playlist，返回固定清晰度列表
function _sc_parseMasterPlaylist(text, baseURL, roomId, headers) {
  var lines = String(text).split(/\r?\n/);
  var variants = [];
  for (var i = 0; i < lines.length; i++) {
    var line = String(lines[i]).trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    var uri = _sc_nextPlaylistURI(lines, i + 1);
    if (!uri) continue;
    var attrs = _sc_parseHLSAttributes(line);
    var qn = _sc_variantHeight(attrs);
    var bandwidth = parseInt(attrs && attrs.BANDWIDTH || "0", 10);
    variants.push({
      title: qn > 0 ? qn + "p" : String(attrs.NAME || attrs.RESOLUTION || "Auto"),
      qn: qn,
      bandwidth: bandwidth,
      url: _sc_resolveURL(uri, baseURL)
    });
  }
  // 按分辨率从高到低排序
  variants.sort(function (a, b) {
    if (b.qn !== a.qn) return b.qn - a.qn;
    return b.bandwidth - a.bandwidth;
  });
  // 去重
  var seen = {};
  var qualitys = [];
  for (var v = 0; v < variants.length; v++) {
    var variant = variants[v];
    if (!variant.url || seen[variant.url]) continue;
    seen[variant.url] = true;
    qualitys.push(_sc_buildQuality(roomId, variant.title, variant.qn, variant.url, headers));
  }
  return qualitys;
}

// 获取固定清晰度：请求 master playlist 并解析
function _sc_fetchFixedQualities(masterURL, roomId, headers) {
  return Host.http.request({
    url: masterURL,
    method: "GET",
    headers: headers,
    timeout: 15
  }).then(function (resp) {
    if (resp.status !== 200) return [];
    return _sc_parseMasterPlaylist(resp.bodyText || "", masterURL, roomId, headers);
  }).then(null, function () {
    return [];
  });
}

function _sc_getPlayback(roomId) {
  // 直接从 API 获取主播数据（不请求房间页，防 Cloudflare）
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }

    var headers = {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    };

    // 从API获取主播信息
    var hlsPlaylist = "";
    if (found && found.hlsPlaylist) {
      hlsPlaylist = String(found.hlsPlaylist);
    }

    var defaultQualitys = [];
    var proxyQualitys = [];

    // ============================================================
    // 核心逻辑：使用 _auto.m3u8 + MOUFLON 解密代理
    // _auto.m3u8 是多清晰度 master playlist，包含 #EXT-X-STREAM-INF
    // 通过 CF Worker /m3u8/ 路由自动解密 MOUFLON + 重写 URL
    // ============================================================
    if (hlsPlaylist) {
      // 从 hlsPlaylist 提取 CDN 基础路径，替换为 _auto.m3u8
      var cdnBase = _sc_extractCdnBase(hlsPlaylist);
      if (cdnBase) {
        // 构造 _auto.m3u8 URL（多清晰度 master playlist）
        var autoUrl = cdnBase + encodeURIComponent(String(roomId)) + "_auto.m3u8?playlistType=lowLatency";

        // 直连 URL（备用）
        defaultQualitys.push(_sc_buildQuality(roomId, "Auto", 0, autoUrl, headers));

        // MOUFLON 解密代理 URL（通过 /m3u8/ 路由）
        var decryptProxyUrl = _sc_convertToM3u8ProxyUrl(autoUrl);
        if (decryptProxyUrl !== autoUrl) {
          proxyQualitys.push(_sc_buildQuality(roomId, "Auto", 0, decryptProxyUrl, headers));
        }
      }
    }

    // 兜底
    if (defaultQualitys.length === 0) {
      var fallbackUrl = _SC_CDN_URL + "/hls/"
        + encodeURIComponent(String(roomId))
        + "/master/"
        + encodeURIComponent(String(roomId))
        + "_auto.m3u8?playlistType=lowLatency";
      defaultQualitys.push(_sc_buildQuality(roomId, "Auto", 0, fallbackUrl, headers));
      var fallbackProxy = _sc_convertToM3u8ProxyUrl(fallbackUrl);
      if (fallbackProxy !== fallbackUrl) {
        proxyQualitys.push(_sc_buildQuality(roomId, "Auto", 0, fallbackProxy, headers));
      }
    }

    var results = [];

    // ============================================================
    // 线路1：MOUFLON 解密代理（默认线路，支持高画质）
    // CF Worker 自动解密 m3u8 中的 MOUFLON URI
    // ============================================================
    if (proxyQualitys.length > 0) {
      results.push({
        cdn: "cfproxy",
        displayName: "高画质(解密)",
        qualitys: proxyQualitys
      });
    }

    // ============================================================
    // 线路2：直连（备用，需要能访问 StripChat CDN）
    // ============================================================
    results.push({
      cdn: "growcdn",
      displayName: "流畅模式(直连)",
      qualitys: defaultQualitys
    });

    return results;
  });
}

function _sc_refreshPlayback(roomId, cdnId, qn) {
  var cdn = String(cdnId || "cfproxy");

  // 重新从 API 获取最新 hlsPlaylist
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  var headers = {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  };

  return Host.http.request({
    url: url,
    method: "GET",
    headers: headers,
    timeout: 30
  }).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }

    var hlsPlaylist = "";
    if (found && found.hlsPlaylist) {
      hlsPlaylist = String(found.hlsPlaylist);
    }

    // 构造 _auto.m3u8 URL
    var autoUrl = "";
    if (hlsPlaylist) {
      var cdnBase = _sc_extractCdnBase(hlsPlaylist);
      if (cdnBase) {
        autoUrl = cdnBase + encodeURIComponent(String(roomId)) + "_auto.m3u8?playlistType=lowLatency";
      }
    }

    if (!autoUrl) {
      autoUrl = _SC_CDN_URL + "/hls/"
        + encodeURIComponent(String(roomId))
        + "/master/"
        + encodeURIComponent(String(roomId))
        + "_auto.m3u8?playlistType=lowLatency";
    }

    // 根据 cdn 类型决定是否使用 MOUFLON 解密代理
    var useProxy = (cdn === "cfproxy");
    var playUrl = autoUrl;

    if (useProxy) {
      playUrl = _sc_convertToM3u8ProxyUrl(autoUrl);
    }

    return Promise.resolve(_sc_buildQuality(roomId, "Auto", 0, playUrl, headers));
  });
}

function _sc_search(keyword) {
  return _sc_searchModels(keyword).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: String(m.snapshotUrl || ""),
        userHeadImg: String(m.avatarUrl || m.snapshotUrl || ""),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_resolveShare(shareCode) {
  var input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  var username = "";
  var patterns = [
    /stripchat\.(?:global|com)\/([\w]+)/,
    /\/([\w]+)$/
  ];

  for (var p = 0; p < patterns.length; p++) {
    var m = input.match(patterns[p]);
    if (m && m[1]) {
      username = m[1];
      break;
    }
  }

  if (!username && /^[a-zA-Z0-9_]+$/.test(input)) {
    username = input;
  }

  if (!username) {
    _sc_throw("NOT_FOUND", "cannot extract username from shareCode", { shareCode: input });
  }

  return Promise.resolve({
    roomId: username,
    userId: username,
    userName: username,
    roomTitle: username,
    roomCover: "",
    userHeadImg: "",
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: "0"
  });
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function () {
    return _sc_getCategories();
  },

  getRooms: function (payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _sc_getRooms(id, page);
  },

  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getPlayback(roomId);
  },

  refreshPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    var cdn = String((payload && payload.cdn) || "");
    var quality = (payload && payload.quality) || {};
    var qualityContext = quality.requestContext || {};
    var qn = Number(qualityContext.qn !== undefined ? qualityContext.qn : quality.qn || 0);
    var cdnId = String(qualityContext.cdn || cdn || "growcdn");

    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_refreshPlayback(roomId, cdnId, qn);
  },

  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getRoomDetail(roomId);
  },

  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return Promise.resolve({ liveState: "1" });
  },

  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _sc_search(keyword);
  },

  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _sc_resolveShare(shareCode);
  },

  clearCredential: function () {
    return Promise.resolve({ ok: true });
  },

  setCredential: function () {
    return Promise.resolve({ ok: true });
  }
};
