// ============================================================
// StripChat AngelLive Plugin v2.9.0
// 支持账号登录 Cookie 注入 | 三线路播放 | 封面图片代理
// ============================================================

// ---- Login Credential Management (inline) ----
var _sc_loginPlatformId = "stripchat";
var _sc_loginRuntime = {
  credentialSynced: false,
  credentialStatus: { state: "missing", expireAt: 0, userId: "", userName: "", message: "" }
};
function _sc_loginTrim(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function _sc_loginBuildCredentialStatus(s) {
  var src = s && typeof s === "object" ? s : {};
  return { state: _sc_loginTrim(src.state) || "unknown", expireAt: src.expireAt || 0, userId: _sc_loginTrim(src.userId), userName: _sc_loginTrim(src.userName), message: _sc_loginTrim(src.message) };
}
function _sc_loginSetCredentialStatus(s) { _sc_loginRuntime.credentialStatus = _sc_loginBuildCredentialStatus(s); return _sc_loginBuildCredentialStatus(_sc_loginRuntime.credentialStatus); }
function _sc_loginMarkSynced(msg) { _sc_loginRuntime.credentialSynced = true; return _sc_loginSetCredentialStatus({ state: "unknown", expireAt: 0, userId: "", userName: "", message: _sc_loginTrim(msg) || "credential synced" }); }
function _sc_loginMarkCleared() { _sc_loginRuntime.credentialSynced = false; return _sc_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "" }); }
function _sc_loginReadCookieHeader() { if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") { return _sc_loginTrim(Host.session.getCookieHeader(_sc_loginPlatformId)); } return ""; }
function _sc_loginReadCookieValue(hdr, name) {
  var cookie = _sc_loginTrim(hdr), target = _sc_loginTrim(name);
  if (!cookie || !target) return "";
  var parts = cookie.split(";"); for (var i = 0; i < parts.length; i++) { var seg = _sc_loginTrim(parts[i]); if (!seg) continue; var idx = seg.indexOf("="); var key = idx >= 0 ? seg.slice(0, idx).trim() : seg; var val = idx >= 0 ? seg.slice(idx + 1).trim() : ""; if (key === target) return val; } return "";
}
function _sc_loginIsLoggedIn(hdr) { return _sc_loginReadCookieValue(hdr, "isLogged") === "1"; }
// ---- End Login Credential Management ----

var _SC_BASE_URL = "https://go.mavrtracktor.com";
var _SC_PAGE_URL = "https://zh.stripchat.global";
var _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

var _SC_CDN_URL = "https://edge-hls.growcdnssedge.com";
var _SC_CF_WORKER_URL = "https://stripchat-proxy.fengxue556.ccwu.cc";

// ============================================================
// 工具函数
// ============================================================

function _sc_makeError(code, message, context) {
  if (globalThis.Host && typeof Host.makeError === "function") {
    return Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

function _sc_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw _sc_makeError(code, message, context);
}

// 将图片 URL 转换为 CF Worker 代理 URL（走 /scimg/）
function _sc_convertToImgProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL || !originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  if (slashIndex === -1) return originalUrl;

  var hostname = withoutProtocol.substring(0, slashIndex);
  var pathAndQuery = withoutProtocol.substring(slashIndex);

  return _SC_CF_WORKER_URL + "/scimg/" + hostname + pathAndQuery;
}

// 将原始 CDN URL 转换为 CF Worker 代理 URL
function _sc_convertToProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL) return originalUrl;
  if (!originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  var hostname = "";
  var pathAndQuery = "";
  if (slashIndex === -1) {
    hostname = withoutProtocol;
    pathAndQuery = "";
  } else {
    hostname = withoutProtocol.substring(0, slashIndex);
    pathAndQuery = withoutProtocol.substring(slashIndex);
  }

  if (!hostname) return originalUrl;
  return _SC_CF_WORKER_URL + "/proxy/" + hostname + pathAndQuery;
}

// 将 m3u8 URL 转换为 CF Worker MOUFLON 解密代理 URL
function _sc_convertToM3u8ProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL) return originalUrl;
  if (!originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  var hostname = "";
  var pathAndQuery = "";
  if (slashIndex === -1) {
    hostname = withoutProtocol;
    pathAndQuery = "";
  } else {
    hostname = withoutProtocol.substring(0, slashIndex);
    pathAndQuery = withoutProtocol.substring(slashIndex);
  }

  if (!hostname) return originalUrl;
  return _SC_CF_WORKER_URL + "/m3u8/" + hostname + pathAndQuery;
}

// 从画质 key 提取分辨率数值，用于排序
// 例如 "1080p60" -> 1080, "720p" -> 720, "480p" -> 480, "original" -> 9999
function _sc_qualityValue(key) {
  if (key === "original") return 9999;
  var match = String(key).match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

// 从 preset 字符串提取显示标题
// 例如 "1080p60" -> "1080p60", "720p" -> "720p"
function _sc_presetTitle(preset) {
  return String(preset || "").replace(/_blurred$/, "模糊");
}

// 从 hlsPlaylist URL 提取 CDN 域名和路径前缀
function _sc_extractCdnBase(hlsPlaylistUrl) {
  if (!hlsPlaylistUrl) return "";
  // 匹配 https://edge-hls.xxx.com/hls/123/master/123_240p.m3u8
  var match = String(hlsPlaylistUrl).match(/^(https?:\/\/[^\/]+\/hls\/\d+\/master\/)/);
  return match ? match[1] : "";
}

// 画质排序：从高到低
function _sc_sortQualitys(qualitys) {
  return qualitys.sort(function(a, b) {
    return b.qn - a.qn;
  });
}

// ============================================================
// 网络请求封装（带重试和错误处理）
// ============================================================

function _sc_httpRequest(url, headers, timeout, retries) {
  retries = retries || 2;
  timeout = timeout || 30;

  function attempt(remain) {
    return Host.http.request({
      platformId: "stripchat",
      authMode: "platform_cookie",
      request: {
        url: url,
        method: "GET",
        headers: headers,
        timeout: timeout
      }
    }).then(function(resp) {
      if (resp.status >= 500 && remain > 0) {
        return attempt(remain - 1);
      }
      return resp;
    }).then(null, function(err) {
      if (remain > 0) {
        return attempt(remain - 1);
      }
      throw err;
    });
  }

  return attempt(retries);
}

// ============================================================
// 分类定义
// ============================================================

function _sc_getCategoryDefinitions() {
  return [
    {
      id: "girls/chinese",
      parentId: "",
      title: "女主播",
      icon: "",
      biz: "girls/chinese",
      subList: [
        { id: "girls/chinese", parentId: "girls/chinese", title: "中国女孩", icon: "", biz: "girls/chinese" },
        { id: "girls/japanese", parentId: "girls/chinese", title: "日本女孩", icon: "", biz: "girls/japanese" },
        { id: "girls/korean", parentId: "girls/chinese", title: "韩国女孩", icon: "", biz: "girls/korean" },
        { id: "girls/american", parentId: "girls/chinese", title: "美国女孩", icon: "", biz: "girls/american" },
        { id: "girls/russian", parentId: "girls/chinese", title: "俄罗斯女孩", icon: "", biz: "girls/russian" },
        { id: "girls/new", parentId: "girls/chinese", title: "最新女主播", icon: "", biz: "girls/new" }
      ]
    },
    {
      id: "couples/chinese",
      parentId: "",
      title: "情侣",
      icon: "",
      biz: "couples/chinese",
      subList: [
        { id: "couples/chinese", parentId: "couples/chinese", title: "中国情侣", icon: "", biz: "couples/chinese" },
        { id: "couples/popular", parentId: "couples/chinese", title: "热门情侣", icon: "", biz: "couples/popular" }
      ]
    },
    {
      id: "men/popular",
      parentId: "",
      title: "男主播",
      icon: "",
      biz: "men/popular",
      subList: [
        { id: "men/popular", parentId: "men/popular", title: "最受欢迎", icon: "", biz: "men/popular" },
        { id: "men/gays", parentId: "men/popular", title: "男同聊天", icon: "", biz: "men/gays" }
      ]
    },
    {
      id: "girls/recommended",
      parentId: "",
      title: "推荐",
      icon: "",
      biz: "girls/recommended",
      subList: [
        { id: "girls/recommended", parentId: "girls/recommended", title: "全部推荐", icon: "", biz: "girls/recommended" }
      ]
    },
    {
      id: "girls/popular",
      parentId: "",
      title: "热门",
      icon: "",
      biz: "girls/popular",
      subList: [
        { id: "girls/popular", parentId: "girls/popular", title: "全部热门", icon: "", biz: "girls/popular" }
      ]
    },
    {
      id: "couples/group-sex",
      parentId: "",
      title: "群交直播",
      icon: "",
      biz: "couples/group-sex",
      subList: [
        { id: "couples/group-sex", parentId: "couples/group-sex", title: "全部群交", icon: "", biz: "couples/group-sex" }
      ]
    },
    {
      id: "couples/lesbians",
      parentId: "",
      title: "女同",
      icon: "",
      biz: "couples/lesbians",
      subList: [
        { id: "couples/lesbians", parentId: "couples/lesbians", title: "全部女同", icon: "", biz: "couples/lesbians" }
      ]
    },
    {
      id: "girls/vr",
      parentId: "",
      title: "VR",
      icon: "",
      biz: "girls/vr",
      subList: [
        { id: "girls/vr", parentId: "girls/vr", title: "全部VR", icon: "", biz: "girls/vr" }
      ]
    },
    {
      id: "trans/popular",
      parentId: "",
      title: "变性人",
      icon: "",
      biz: "trans/popular",
      subList: [
        { id: "trans/popular", parentId: "trans/popular", title: "全部变性人", icon: "", biz: "trans/popular" }
      ]
    },
    {
      id: "girls/new",
      parentId: "",
      title: "新主播",
      icon: "",
      biz: "girls/new",
      subList: [
        { id: "girls/new", parentId: "girls/new", title: "全部新主播", icon: "", biz: "girls/new" }
      ]
    }
  ];
}

// ============================================================
// API 请求
// ============================================================

function _sc_fetchModels(cateId, page) {
  var limit = 200;
  var offset = (page - 1) * limit;
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=" + limit
    + "&offset=" + offset
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return _sc_httpRequest(url, {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  }, 30, 2).then(function(resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

function _sc_searchModels(keyword) {
  var url = _SC_BASE_URL + "/api/models"
    + "?q=" + encodeURIComponent(keyword)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=200"
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return _sc_httpRequest(url, {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  }, 30, 2).then(function(resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

// ============================================================
// 核心功能
// ============================================================

function _sc_getCategories() {
  return Promise.resolve(_sc_getCategoryDefinitions());
}

function _sc_getRooms(cateId, page) {
  return _sc_fetchModels(cateId, page).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: _sc_convertToImgProxyUrl(String(m.snapshotUrl || "")),
        userHeadImg: _sc_convertToImgProxyUrl(String(m.avatarUrl || m.snapshotUrl || "")),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_getRoomDetail(roomId) {
  return _sc_fetchModels("girls/popular", 1).then(function (models) {
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }
    if (!found) {
      _sc_throw("NOT_FOUND", "room not found", { roomId: String(roomId) });
    }
    return {
      roomId: String(found.id || ""),
      userId: String(found.id || ""),
      userName: String(found.username || ""),
      roomTitle: String(found.username || ""),
      roomCover: _sc_convertToImgProxyUrl(String(found.snapshotUrl || "")),
      userHeadImg: _sc_convertToImgProxyUrl(String(found.avatarUrl || found.snapshotUrl || "")),
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: String(found.viewersCount || "0")
    };
  });
}

// 构建单个画质对象（userAgent 独立字段，headers 中不重复）
function _sc_buildQuality(roomId, title, qn, url, headers) {
  // 从 headers 中提取 User-Agent 到独立字段（文档要求不重复）
  var ua = "";
  var cleanHeaders = {};
  if (headers) {
    for (var key in headers) {
      if (headers.hasOwnProperty(key)) {
        if (key.toLowerCase() === "user-agent") {
          ua = String(headers[key]);
        } else {
          cleanHeaders[key] = headers[key];
        }
      }
    }
  }
  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: "m3u8",
    liveType: "stripchat",
    userAgent: ua || _SC_USER_AGENT,
    headers: cleanHeaders,
    playbackHints: {
      streamFormat: "hlsLive",
      selectionBehavior: "direct"
    }
  };
}

// 从 stream.urls 构建画质列表，按分辨率从高到低排序
function _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers) {
  var qualitys = [];
  var urlKeys = Object.keys(streamUrls);

  for (var k = 0; k < urlKeys.length; k++) {
    var key = urlKeys[k];
    var playUrl = streamUrls[key];
    if (!playUrl) continue;

    var qnValue = _sc_qualityValue(key);
    var title = key === "original" ? "原画" : key.toUpperCase();

    qualitys.push(_sc_buildQuality(roomId, title, qnValue, playUrl, headers));
  }

  // 按分辨率从高到低排序
  return _sc_sortQualitys(qualitys);
}

// ============================================================
// HLS Master Playlist 解析（学习瑟瑟聚合平台4）
// ============================================================

// 解析 HLS 属性行，提取 key=value
function _sc_parseHLSAttributes(line) {
  var attrs = {};
  var start = line.indexOf(":");
  var body = start >= 0 ? line.substring(start + 1) : line;
  var re = /([A-Z0-9-]+)=("[^"]*"|[^,]*)/gi;
  var match;
  while ((match = re.exec(body)) !== null) {
    attrs[match[1].toUpperCase()] = String(match[2]).replace(/^"|"$/g, "");
  }
  return attrs;
}

// 从 RESOLUTION 提取高度（如 "1920x1080" → 1080）
function _sc_variantHeight(attrs) {
  var resolution = String(attrs && attrs.RESOLUTION || "");
  var match = resolution.match(/x(\d{3,4})/i);
  return match ? parseInt(match[1], 10) : 0;
}

// 找到 #EXT-X-STREAM-INF 下一行的 URI
function _sc_nextPlaylistURI(lines, start) {
  for (var i = start; i < lines.length; i++) {
    var line = String(lines[i]).trim();
    if (!line || line.charAt(0) === "#") continue;
    return line;
  }
  return "";
}

// 将相对 URI 转为绝对 URL
function _sc_resolveURL(uri, baseURL) {
  if (!uri) return "";
  if (uri.indexOf("http://") === 0 || uri.indexOf("https://") === 0) return uri;
  var base = baseURL;
  if (base.indexOf("?") > -1) base = base.substring(0, base.indexOf("?"));
  if (base.indexOf("#") > -1) base = base.substring(0, base.indexOf("#"));
  if (uri.charAt(0) === "/") {
    var protocolEnd = base.indexOf("://");
    var hostStart = protocolEnd + 3;
    var pathStart = base.indexOf("/", hostStart);
    var root = pathStart > 0 ? base.substring(0, pathStart) : base;
    return root + uri;
  }
  var lastSlash = base.lastIndexOf("/");
  var dir = lastSlash >= 0 ? base.substring(0, lastSlash + 1) : base + "/";
  return dir + uri;
}

// 解析 HLS master playlist，返回固定清晰度列表
function _sc_parseMasterPlaylist(text, baseURL, roomId, headers) {
  var lines = String(text).split(/\r?\n/);
  var variants = [];
  for (var i = 0; i < lines.length; i++) {
    var line = String(lines[i]).trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    var uri = _sc_nextPlaylistURI(lines, i + 1);
    if (!uri) continue;
    var attrs = _sc_parseHLSAttributes(line);
    var qn = _sc_variantHeight(attrs);
    var bandwidth = parseInt(attrs && attrs.BANDWIDTH || "0", 10);
    variants.push({
      title: qn > 0 ? qn + "p" : String(attrs.NAME || attrs.RESOLUTION || "Auto"),
      qn: qn,
      bandwidth: bandwidth,
      url: _sc_resolveURL(uri, baseURL)
    });
  }
  // 按分辨率从高到低排序
  variants.sort(function (a, b) {
    if (b.qn !== a.qn) return b.qn - a.qn;
    return b.bandwidth - a.bandwidth;
  });
  // 去重
  var seen = {};
  var qualitys = [];
  for (var v = 0; v < variants.length; v++) {
    var variant = variants[v];
    if (!variant.url || seen[variant.url]) continue;
    seen[variant.url] = true;
    qualitys.push(_sc_buildQuality(roomId, variant.title, variant.qn, variant.url, headers));
  }
  return qualitys;
}

// 获取固定清晰度：请求 master playlist 并解析
function _sc_fetchFixedQualities(masterURL, roomId, headers) {
  return Host.http.request({
    platformId: "stripchat",
    authMode: "platform_cookie",
    request: {
      url: masterURL,
      method: "GET",
      headers: headers,
      timeout: 15
    }
  }).then(function (resp) {
    if (resp.status !== 200) return [];
    return _sc_parseMasterPlaylist(resp.bodyText || "", masterURL, roomId, headers);
  }).then(null, function () {
    return [];
  });
}

function _sc_getPlayback(roomId) {
  // 直接从 API 获取主播数据（不请求房间页，防 Cloudflare）
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  return Host.http.request({
    platformId: "stripchat",
    authMode: "platform_cookie",
    request: {
      url: url,
      method: "GET",
      headers: {
        "User-Agent": _SC_USER_AGENT,
        "Referer": _SC_PAGE_URL + "/"
      },
      timeout: 30
    }
  }).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }

    var headers = {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    };

    // 从API获取真实画质URL
    var streamUrls = {};
    var modelUsername = "";
    if (found && found.stream && found.stream.urls) {
      streamUrls = found.stream.urls;
    }
    if (found && found.username) {
      modelUsername = String(found.username);
    }

    var defaultQualitys = [];
    var proxyQualitys = [];
    var decryptQualitys = [];

    if (Object.keys(streamUrls).length > 0) {
      // 有 API 返回的画质，按分辨率排序
      defaultQualitys = _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers);

      // 构建 CF 代理线路（同样排序）
      for (var j = 0; j < defaultQualitys.length; j++) {
        var q = defaultQualitys[j];
        var proxyUrl = _sc_convertToProxyUrl(q.url);
        if (proxyUrl !== q.url) {
          proxyQualitys.push(_sc_buildQuality(roomId, q.title, q.qn, proxyUrl, headers));
        }
      }

      // 构建 MOUFLON 解密线路（通过 /m3u8/ 路由）
      for (var k = 0; k < defaultQualitys.length; k++) {
        var q2 = defaultQualitys[k];
        var decryptUrl = _sc_convertToM3u8ProxyUrl(q2.url);
        if (decryptUrl !== q2.url) {
          decryptQualitys.push(_sc_buildQuality(roomId, q2.title, q2.qn, decryptUrl, headers));
        }
      }
    }

    // 如果API没返回画质，使用默认 master 地址作为兜底
    if (defaultQualitys.length === 0) {
      var fallbackMasterUrl = _SC_CDN_URL + "/hls/"
        + encodeURIComponent(String(roomId))
        + "/master/"
        + encodeURIComponent(String(roomId))
        + "_480p.m3u8?playlistType=lowLatency";
      defaultQualitys.push(_sc_buildQuality(roomId, "Auto", 0, fallbackMasterUrl, headers));

      var fallbackProxyMasterUrl = _sc_convertToProxyUrl(fallbackMasterUrl);
      if (fallbackProxyMasterUrl !== fallbackMasterUrl) {
        proxyQualitys.push(_sc_buildQuality(roomId, "Auto", 0, fallbackProxyMasterUrl, headers));
      }

      var fallbackDecryptUrl = _sc_convertToM3u8ProxyUrl(fallbackMasterUrl);
      if (fallbackDecryptUrl !== fallbackMasterUrl) {
        decryptQualitys.push(_sc_buildQuality(roomId, "Auto", 0, fallbackDecryptUrl, headers));
      }
    }

    // 尝试从 master playlist 解析所有可用画质（破解 ABR 动态码率）
    var masterPromise = Promise.resolve([]);
    if (defaultQualitys.length > 0) {
      var bestUrl = defaultQualitys[0].url;
      // 从任意画质 URL 推导 master URL（去掉 _480p/_720p 等后缀）
      var masterGuess = bestUrl.replace(/_\d+p\.m3u8/, ".m3u8");
      if (masterGuess !== bestUrl) {
        masterPromise = _sc_fetchFixedQualities(masterGuess, roomId, headers).catch(function () { return []; });
      }
    }

    return masterPromise.then(function (masterQualitys) {
      // master 解析出的画质作为补充（不替换 API 原始画质）
      if (masterQualitys.length > 0) {
        // 检查 master 是否有 API 没有的更高画质
        var existingTitles = {};
        for (var e = 0; e < defaultQualitys.length; e++) {
          existingTitles[defaultQualitys[e].title] = true;
        }
        for (var m = 0; m < masterQualitys.length; m++) {
          if (!existingTitles[masterQualitys[m].title]) {
            defaultQualitys.push(masterQualitys[m]);
            // 补充 CF 代理线路
            var proxyUrl = _sc_convertToProxyUrl(masterQualitys[m].url);
            if (proxyUrl !== masterQualitys[m].url) {
              proxyQualitys.push(_sc_buildQuality(roomId, masterQualitys[m].title, masterQualitys[m].qn, proxyUrl, headers));
            }
            // 补充 MOUFLON 解密线路
            var decryptUrl = _sc_convertToM3u8ProxyUrl(masterQualitys[m].url);
            if (decryptUrl !== masterQualitys[m].url) {
              decryptQualitys.push(_sc_buildQuality(roomId, masterQualitys[m].title, masterQualitys[m].qn, decryptUrl, headers));
            }
          }
        }
      }

      var results = [];

      // ============================================================
      // 线路1：直连（默认线路）
      // ============================================================
      results.push({
        cdn: "growcdn",
        displayName: "直连",
        qualitys: defaultQualitys.length > 0 ? defaultQualitys : [_sc_buildQuality(roomId, "Auto", 0, _SC_CDN_URL + "/hls/" + encodeURIComponent(String(roomId)) + "/master/" + encodeURIComponent(String(roomId)) + "_480p.m3u8?playlistType=lowLatency", headers)]
      });

      // ============================================================
      // 线路2：CF Worker 代理
      // ============================================================
      if (proxyQualitys.length > 0) {
        results.push({
          cdn: "cfproxy",
          displayName: "CF加速",
          qualitys: proxyQualitys
        });
      }

      return results;
    }); // end masterPromise.then
  });
}

function _sc_refreshPlayback(roomId, cdnId, qn) {
  var cdn = String(cdnId || "decrypt");

  // 重新从 API 获取最新 stream.urls
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  var headers = {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  };

  return Host.http.request({
    platformId: "stripchat",
    authMode: "platform_cookie",
    request: {
      url: url,
      method: "GET",
      headers: headers,
      timeout: 30
    }
  }).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }

    var streamUrls = {};
    if (found && found.stream && found.stream.urls) {
      streamUrls = found.stream.urls;
    }

    // 构建画质列表
    var allQualitys = [];
    if (Object.keys(streamUrls).length > 0) {
      allQualitys = _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers);
    }

    // 根据 cdn 类型决定使用哪种代理
    // cfproxy -> /proxy/ 代理路由
    // growcdn -> 直连
    if (allQualitys.length > 0) {
      var best = allQualitys[0]; // 已按分辨率从高到低排序
      var playUrl = best.url;

      if (cdn === "cfproxy") {
        playUrl = _sc_convertToProxyUrl(best.url);
      }

      return Promise.resolve(_sc_buildQuality(roomId, best.title, best.qn, playUrl, headers));
    }

    // 兜底
    var fallbackUrl = _SC_CDN_URL + "/hls/"
      + encodeURIComponent(String(roomId))
      + "/master/"
      + encodeURIComponent(String(roomId))
      + "_480p.m3u8?playlistType=lowLatency";

    if (cdn === "cfproxy") {
      fallbackUrl = _sc_convertToProxyUrl(fallbackUrl);
    }

    return Promise.resolve(_sc_buildQuality(roomId, "Auto", 0, fallbackUrl, headers));
  });
}

function _sc_search(keyword) {
  return _sc_searchModels(keyword).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: _sc_convertToImgProxyUrl(String(m.snapshotUrl || "")),
        userHeadImg: _sc_convertToImgProxyUrl(String(m.avatarUrl || m.snapshotUrl || "")),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_resolveShare(shareCode) {
  var input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  var username = "";
  var patterns = [
    /stripchat\.(?:global|com)\/([\w]+)/,
    /\/([\w]+)$/
  ];

  for (var p = 0; p < patterns.length; p++) {
    var m = input.match(patterns[p]);
    if (m && m[1]) {
      username = m[1];
      break;
    }
  }

  if (!username && /^[a-zA-Z0-9_]+$/.test(input)) {
    username = input;
  }

  if (!username) {
    _sc_throw("NOT_FOUND", "cannot extract username from shareCode", { shareCode: input });
  }

  return Promise.resolve({
    roomId: username,
    userId: username,
    userName: username,
    roomTitle: username,
    roomCover: "",
    userHeadImg: "",
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: "0"
  });
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function () {
    return _sc_getCategories();
  },

  getRooms: function (payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _sc_getRooms(id, page);
  },

  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getPlayback(roomId);
  },

  refreshPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    var cdn = String((payload && payload.cdn) || "");
    var quality = (payload && payload.quality) || {};
    var qualityContext = quality.requestContext || {};
    var qn = Number(qualityContext.qn !== undefined ? qualityContext.qn : quality.qn || 0);
    var cdnId = String(qualityContext.cdn || cdn || "growcdn");

    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_refreshPlayback(roomId, cdnId, qn);
  },

  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getRoomDetail(roomId);
  },

  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return Promise.resolve({ liveState: "1" });
  },

  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _sc_search(keyword);
  },

  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _sc_resolveShare(shareCode);
  },

  clearCredential: function () {
    return Promise.resolve(_sc_loginMarkCleared());
  },

  setCredential: function () {
    return Promise.resolve(Object.assign({ ok: true }, _sc_loginMarkSynced("credential synced")));
  },

  getCredentialStatus: async function (payload) {
    var cookieHeader = _sc_loginReadCookieHeader();
    if (!cookieHeader) {
      return _sc_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未检测到 Cookie" });
    }
    if (!_sc_loginIsLoggedIn(cookieHeader)) {
      return _sc_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未登录，请使用账号密码登录" });
    }
    var moeUuid = _sc_loginReadCookieValue(cookieHeader, "moe_uuid");
    var sessionId = _sc_loginReadCookieValue(cookieHeader, "stripchat_com_sessionId");
    return _sc_loginSetCredentialStatus({ state: "valid", expireAt: 0, userId: moeUuid || sessionId || "stripchat_user", userName: "StripChat 用户", message: "" });
  },

  validateCredential: async function (payload) {
    var cookieHeader = _sc_loginReadCookieHeader();
    if (!cookieHeader) {
      return _sc_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未检测到 Cookie" });
    }
    if (!_sc_loginIsLoggedIn(cookieHeader)) {
      return _sc_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未登录，请使用账号密码登录" });
    }
    var moeUuid = _sc_loginReadCookieValue(cookieHeader, "moe_uuid");
    var sessionId = _sc_loginReadCookieValue(cookieHeader, "stripchat_com_sessionId");
    return _sc_loginSetCredentialStatus({ state: "valid", expireAt: 0, userId: moeUuid || sessionId || "stripchat_user", userName: "StripChat 用户", message: "" });
  }
};
