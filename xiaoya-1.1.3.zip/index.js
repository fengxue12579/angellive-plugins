// ============================================================
// 小雅直播 AngelLive Plugin v1.1.0
// 基于API获取分类+房间+封面图，M3U源作为备用，TW分类单独添加
// ============================================================

var _XY_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Version/120.0.0.0 Safari/537.36";

// 主API
var _XY_API_HOST = "http://api.hclyz.com:81/mf";

// TW分类关键词（用于从API数据中识别TW频道）
var _XY_TW_KEYWORDS = ["惊艳", "潘朵拉完美", "香蕉", "松視", "松视", "台湾", "tw", "TW"];

// 默认封面图（使用可靠的图片源）
var _XY_DEFAULT_COVER = "https://picsum.photos/400/225";

// ============================================================
// 工具函数
// ============================================================

function _xy_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw new Error(String(message || "unknown error"));
}

function _xy_httpGet(url, headers, timeout) {
  return Host.http.request({
    platformId: "xiaoya",
    authMode: "none",
    request: {
      url: url,
      method: "GET",
      headers: headers || { "User-Agent": _XY_USER_AGENT },
      timeout: timeout || 30
    }
  });
}

// 图片URL修复
// T4源码用slink.ltd代理，但AngelLive客户端可能无法访问
// 策略：直接使用原始URL，让客户端自己处理
function _xy_fixImgUrl(imgUrl) {
  if (!imgUrl || typeof imgUrl !== "string" || imgUrl.indexOf("http") !== 0) return _XY_DEFAULT_COVER;
  return String(imgUrl);
}

// 生成稳定的roomId
function _xy_hashId(str) {
  var hash = 0;
  for (var i = 0; i < str.length; i++) {
    var c = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + c;
    hash = hash & hash;
  }
  return "xy_" + Math.abs(hash);
}

// ============================================================
// API数据获取
// ============================================================

// 获取平台分类列表（从json.txt）
function _xy_fetchPlatformList() {
  return _xy_httpGet(_XY_API_HOST + "/json.txt").then(function(resp) {
    if (resp.status !== 200 || !resp.bodyText) return [];
    var obj = JSON.parse(resp.bodyText || "{}");
    var list = obj.pingtai || [];
    // 第一个是总数，跳过
    return list.slice(1).map(function(item) {
      return {
        title: String(item.title || ""),
        address: String(item.address || ""),
        xinimg: String(item.xinimg || ""),
        number: parseInt(item.Number || "0", 10)
      };
    });
  }).then(null, function() {
    return [];
  });
}

// 获取某个平台下的主播列表
function _xy_fetchAnchors(address) {
  return _xy_httpGet(_XY_API_HOST + "/" + encodeURIComponent(address)).then(function(resp) {
    if (resp.status !== 200 || !resp.bodyText) return [];
    var obj = JSON.parse(resp.bodyText || "{}");
    return (obj.zhubo || []).map(function(vod) {
      return {
        title: String(vod.title || ""),
        address: String(vod.address || "")
      };
    });
  }).then(null, function() {
    return [];
  });
}

// 获取M3U源并解析TW频道
function _xy_parseM3U(m3uText, sourceIndex) {
  var channels = [];
  var lines = String(m3uText || "").split(/\r?\n/);
  var currentExtInf = null;

  for (var i = 0; i < lines.length; i++) {
    var line = String(lines[i]).trim();
    if (!line || line.indexOf("#") === 0) {
      if (line.indexOf("#EXTINF:") === 0) {
        var result = { title: "", groupTitle: "未分类", logo: "", url: "" };
        var groupMatch = line.match(/group-title="([^"]*)"/i);
        if (groupMatch) result.groupTitle = groupMatch[1].trim() || "未分类";
        var logoMatch = line.match(/tvg-logo="([^"]*)"/i);
        if (logoMatch) result.logo = logoMatch[1].trim();
        var commaIdx = line.lastIndexOf(",");
        if (commaIdx >= 0) result.title = line.substring(commaIdx + 1).trim();
        currentExtInf = result;
      }
      continue;
    }
    if (currentExtInf) {
      currentExtInf.url = line;
      channels.push(currentExtInf);
      currentExtInf = null;
    }
  }
  return channels;
}

function _xy_isTWChannel(title) {
  for (var i = 0; i < _XY_TW_KEYWORDS.length; i++) {
    if (title.indexOf(_XY_TW_KEYWORDS[i]) >= 0) return true;
  }
  return false;
}

// TW频道硬编码（M3U源无法访问，直接内置TW频道列表）
function _xy_fetchTWChannels() {
  return Promise.resolve([
    { title: "惊艳", url: "https://v2h.lblh.xyz/live/惊艳.m3u8", logo: "" },
    { title: "潘朵拉完美", url: "https://v2h.lblh.xyz/live/潘朵拉完美.m3u8", logo: "" },
    { title: "香蕉", url: "https://v2h.lblh.xyz/live/香蕉.m3u8", logo: "" },
    { title: "松視1台", url: "https://v2h.lblh.xyz/live/松視1台.m3u8", logo: "" },
    { title: "松視2台", url: "https://v2h.lblh.xyz/live/松視2台.m3u8", logo: "" },
    { title: "松視3台", url: "https://v2h.lblh.xyz/live/松視3台.m3u8", logo: "" }
  ]);
}

// ============================================================
// 缓存
// ============================================================

var _xy_cache = {
  platforms: null,      // API平台列表
  categories: null,     // 最终分类数据（含TW）
  categoryDefs: null,   // 分类定义
  timestamp: 0,
  ttl: 5 * 60 * 1000
};

function _xy_getCachedData() {
  var now = Date.now();
  if (_xy_cache.categories && _xy_cache.categoryDefs && (now - _xy_cache.timestamp) < _xy_cache.ttl) {
    return Promise.resolve({
      categories: _xy_cache.categories,
      categoryDefs: _xy_cache.categoryDefs
    });
  }

  // 并行获取：API平台列表 + TW频道
  return Promise.all([
    _xy_fetchPlatformList(),
    _xy_fetchTWChannels()
  ]).then(function(results) {
    var platforms = results[0];
    var twChannels = results[1];

    // 构建分类数据
    var categories = {};
    var categoryDefs = [];

    // 1. 添加TW分类（如果有TW频道）
    if (twChannels.length > 0) {
      categories["tw"] = twChannels.map(function(ch) {
        return {
          title: ch.title,
          address: ch.url,
          logo: ch.logo || _XY_DEFAULT_COVER,
          groupTitle: "TW直播"
        };
      });
      categoryDefs.push({
        id: "tw",
        title: "TW直播",
        icon: "",
        biz: "tw",
        subList: [
          { id: "tw", parentId: "tw", title: "全部TW", icon: "", biz: "tw" }
        ]
      });
    }

    // 2. 添加API平台分类（按Number排序，大的在前）
    platforms.sort(function(a, b) { return b.number - a.number; });

    for (var i = 0; i < platforms.length; i++) {
      var p = platforms[i];
      if (!p.title || !p.address) continue;

      var cateId = _xy_hashId(p.address);
      var logo = _xy_fixImgUrl(p.xinimg) || _XY_DEFAULT_COVER;

      // 分类定义
      categoryDefs.push({
        id: cateId,
        title: p.title,
        icon: logo,
        biz: cateId,
        subList: [
          { id: cateId, parentId: cateId, title: "全部" + p.title, icon: "", biz: cateId }
        ]
      });

      // 分类数据（存储平台信息，getRooms时再拉取主播）
      categories[cateId] = {
        platformTitle: p.title,
        platformAddress: p.address,
        platformLogo: logo,
        anchors: null, // 延迟加载
        loaded: false
      };
    }

    _xy_cache.categories = categories;
    _xy_cache.categoryDefs = categoryDefs;
    _xy_cache.timestamp = now;

    return { categories: categories, categoryDefs: categoryDefs };
  });
}

// 延迟加载某个分类的主播列表
function _xy_loadAnchorsForCategory(cateId) {
  return _xy_getCachedData().then(function(data) {
    var cate = data.categories[cateId];
    if (!cate || !cate.platformAddress) return [];

    // 已加载过，直接返回
    if (cate.loaded && cate.anchors) {
      return Promise.resolve(cate.anchors);
    }

    // 首次加载
    return _xy_fetchAnchors(cate.platformAddress).then(function(anchors) {
      var result = anchors.map(function(a) {
        return {
          title: a.title,
          address: a.address,
          logo: cate.platformLogo || _XY_DEFAULT_COVER,
          groupTitle: cate.platformTitle
        };
      });
      cate.anchors = result;
      cate.loaded = true;
      return result;
    });
  });
}

// ============================================================
// 核心功能
// ============================================================

function _xy_getCategories() {
  return _xy_getCachedData().then(function(data) {
    return data.categoryDefs;
  });
}

function _xy_getRooms(cateId, page) {
  return _xy_getCachedData().then(function(data) {
    var targetCate = String(cateId || "").trim();

    // TW分类
    if (targetCate === "tw") {
      var twChannels = data.categories["tw"] || [];
      var start = (page - 1) * 50;
      var pageItems = twChannels.slice(start, start + 50);
      return pageItems.map(function(ch) {
        var roomId = _xy_hashId(ch.title);
        var cover = ch.logo || _XY_DEFAULT_COVER;
        return {
          roomId: roomId,
          userId: roomId,
          userName: ch.title || "未知频道",
          roomTitle: ch.title || "未知频道",
          roomCover: cover,
          userHeadImg: cover,
          liveType: "xiaoya",
          liveState: "1",
          liveWatchedCount: "0"
        };
      });
    }

    // API平台分类（延迟加载主播）
    return _xy_loadAnchorsForCategory(targetCate).then(function(anchors) {
      var start = (page - 1) * 50;
      var pageItems = anchors.slice(start, start + 50);
      return pageItems.map(function(a) {
        var roomId = _xy_hashId(a.title);
        var cover = a.logo || _XY_DEFAULT_COVER;
        return {
          roomId: roomId,
          userId: roomId,
          userName: a.title || "未知频道",
          roomTitle: a.title || "未知频道",
          roomCover: cover,
          userHeadImg: cover,
          liveType: "xiaoya",
          liveState: "1",
          liveWatchedCount: "0"
        };
      });
    });
  });
}

function _xy_getRoomDetail(roomId) {
  return _xy_getCachedData().then(function(data) {
    // 在TW分类中查找
    var twChannels = data.categories["tw"] || [];
    for (var t = 0; t < twChannels.length; t++) {
      if (_xy_hashId(twChannels[t].title) === roomId) {
        var cover = twChannels[t].logo || _XY_DEFAULT_COVER;
        return {
          roomId: roomId,
          userId: roomId,
          userName: twChannels[t].title,
          roomTitle: twChannels[t].title,
          roomCover: cover,
          userHeadImg: cover,
          liveType: "xiaoya",
          liveState: "1",
          liveWatchedCount: "0"
        };
      }
    }

    // 在已加载的平台分类中查找
    var cateKeys = Object.keys(data.categories);
    for (var k = 0; k < cateKeys.length; k++) {
      var cate = data.categories[cateKeys[k]];
      if (cate.anchors) {
        for (var a = 0; a < cate.anchors.length; a++) {
          if (_xy_hashId(cate.anchors[a].title) === roomId) {
            var cover2 = cate.anchors[a].logo || _XY_DEFAULT_COVER;
            return {
              roomId: roomId,
              userId: roomId,
              userName: cate.anchors[a].title,
              roomTitle: cate.anchors[a].title,
              roomCover: cover2,
              userHeadImg: cover2,
              liveType: "xiaoya",
              liveState: "1",
              liveWatchedCount: "0"
            };
          }
        }
      }
    }

    _xy_throw("NOT_FOUND", "room not found", { roomId: roomId });
  });
}

function _xy_getPlayback(roomId) {
  return _xy_getCachedData().then(function(data) {
    // 在TW分类中查找
    var twChannels = data.categories["tw"] || [];
    for (var t = 0; t < twChannels.length; t++) {
      if (_xy_hashId(twChannels[t].title) === roomId) {
        return [{
          cdn: "default",
          displayName: "默认线路",
          qualitys: [{
            roomId: roomId,
            title: "原画",
            qn: 9999,
            url: twChannels[t].address,
            liveCodeType: "ts",
            liveType: "xiaoya",
            userAgent: _XY_USER_AGENT,
            headers: {}
          }]
        }];
      }
    }

    // 在已加载的平台分类中查找
    var cateKeys = Object.keys(data.categories);
    for (var k = 0; k < cateKeys.length; k++) {
      var cate = data.categories[cateKeys[k]];
      if (cate.anchors) {
        for (var a = 0; a < cate.anchors.length; a++) {
          if (_xy_hashId(cate.anchors[a].title) === roomId) {
            return [{
              cdn: "default",
              displayName: cate.platformTitle || "默认线路",
              qualitys: [{
                roomId: roomId,
                title: "原画",
                qn: 9999,
                url: cate.anchors[a].address,
                liveCodeType: "m3u8",
                liveType: "xiaoya",
                userAgent: _XY_USER_AGENT,
                headers: {}
              }]
            }];
          }
        }
      }
    }

    _xy_throw("NOT_FOUND", "room not found for playback", { roomId: roomId });
  });
}

function _xy_search(keyword) {
  var kw = String(keyword || "").trim().toLowerCase();
  if (!kw) return Promise.resolve([]);

  return _xy_getCachedData().then(function(data) {
    var results = [];

    // 搜索TW分类
    var twChannels = data.categories["tw"] || [];
    for (var t = 0; t < twChannels.length; t++) {
      if (twChannels[t].title.toLowerCase().indexOf(kw) >= 0) {
        var roomId = _xy_hashId(twChannels[t].title);
        var cover = twChannels[t].logo || _XY_DEFAULT_COVER;
        results.push({
          roomId: roomId, userId: roomId,
          userName: twChannels[t].title, roomTitle: twChannels[t].title,
          roomCover: cover, userHeadImg: cover,
          liveType: "xiaoya", liveState: "1", liveWatchedCount: "0"
        });
      }
    }

    // 搜索已加载的平台分类
    var cateKeys = Object.keys(data.categories);
    for (var k = 0; k < cateKeys.length; k++) {
      var cate = data.categories[cateKeys[k]];
      if (cate.anchors) {
        for (var a = 0; a < cate.anchors.length; a++) {
          if (cate.anchors[a].title.toLowerCase().indexOf(kw) >= 0) {
            var roomId2 = _xy_hashId(cate.anchors[a].title);
            var cover2 = cate.anchors[a].logo || _XY_DEFAULT_COVER;
            results.push({
              roomId: roomId2, userId: roomId2,
              userName: cate.anchors[a].title, roomTitle: cate.anchors[a].title,
              roomCover: cover2, userHeadImg: cover2,
              liveType: "xiaoya", liveState: "1", liveWatchedCount: "0"
            });
          }
        }
      }
    }

    return results;
  });
}

function _xy_getLiveState(roomId) {
  return Promise.resolve({ liveState: "1" });
}

function _xy_resolveShare(shareCode) {
  _xy_throw("NOT_SUPPORTED", "share resolve is not supported", { shareCode: shareCode });
}

function _xy_getDanmaku(payload) {
  return { args: {}, headers: null };
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function() {
    return _xy_getCategories();
  },

  getRooms: function(payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _xy_throw("INVALID_ARGS", "id is required", { field: "id" });
    if (page < 1) page = 1;
    return _xy_getRooms(id, page);
  },

  getPlayback: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getPlayback(roomId);
  },

  getRoomDetail: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getRoomDetail(roomId);
  },

  getLiveState: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getLiveState(roomId);
  },

  search: function(payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _xy_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _xy_search(keyword);
  },

  resolveShare: function(payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _xy_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _xy_resolveShare(shareCode);
  },

  getDanmaku: function(payload) {
    return Promise.resolve(_xy_getDanmaku(payload));
  }
};
