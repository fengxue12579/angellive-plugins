/**
 * 小雅直播 - LiveParse 插件 v2.0.3
 * 基于 T4 API 直播源 + TW直播本地频道
 * 数据来源: api.hclyz.com
 */

// ==================== 配置 ====================
var PLUGIN_ID = "xiaoya-live";
var API_HOST = "http://api.hclyz.com:81/mf";
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var LIVE_TYPE = "99";
var TW_CATEGORY_ID = "__tw_live__";

// ==================== TW直播本地频道 ====================
var TW_CHANNELS = [
  { id: "tw_0", title: "惊艳", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/85.ts" },
  { id: "tw_1", title: "潘朵拉完美", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/86.ts" },
  { id: "tw_2", title: "香蕉", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/117.ts" },
  { id: "tw_3", title: "松視1台", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/88.ts" },
  { id: "tw_4", title: "松視2台", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/89.ts" },
  { id: "tw_5", title: "松視3台", address: "http://15.204.105.50:25461/live-G2s9zK2n9m/xDtwVfWM8T/90.ts" }
];

// ==================== 工具函数 ====================
function _throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw new Error(String(message || "unknown error"));
}

function _str(value, fallback) {
  if (typeof value === "string") return value.trim();
  return fallback || "";
}

function _int(value, fallback) {
  var n = parseInt(value, 10);
  return isNaN(n) ? (fallback || 0) : n;
}

function _rp(payload) {
  if (payload && typeof payload === "object" && !Array.isArray(payload)) return payload;
  return {};
}

// ==================== HTTP 请求（准则 5.1） ====================
async function _httpGet(url) {
  var response = await Host.http.request({
    platformId: PLUGIN_ID,
    authMode: "none",
    request: {
      url: url,
      method: "GET",
      headers: { "User-Agent": UA }
    }
  });
  var bodyText = response.bodyText || "";
  if (typeof bodyText === "string" && bodyText.length > 0) {
    return JSON.parse(bodyText);
  }
  return {};
}

// ==================== 数据缓存 ====================
var _categoryCache = null;
var _categoryCacheTime = 0;
var _categoryCacheTTL = 10 * 60 * 1000;

var _listCache = {};
var _listCacheTime = {};
var _listCacheTTL = 5 * 60 * 1000;

async function fetchCategories() {
  var now = Date.now();
  if (_categoryCache && (now - _categoryCacheTime) < _categoryCacheTTL) {
    return _categoryCache;
  }

  var json = await _httpGet(API_HOST + "/json.txt");
  var platforms = json.pingtai || [];
  var classes = platforms.slice(1).map(function(item) {
    return {
      id: _str(item.address),
      title: _str(item.title),
      icon: _str(item.xinimg || ""),
      number: _int(item.Number, 0)
    };
  });

  _categoryCache = classes;
  _categoryCacheTime = now;
  return classes;
}

async function fetchAnchors(tid) {
  var now = Date.now();
  if (_listCache[tid] && (now - _listCacheTime[tid]) < _listCacheTTL) {
    return _listCache[tid];
  }

  var json = await _httpGet(API_HOST + "/" + tid);
  var zhubo = json.zhubo || [];

  var anchors = zhubo.map(function(vod, index) {
    return {
      id: tid + "_" + index,
      title: _str(vod.title),
      address: _str(vod.address),
      tid: tid
    };
  });

  _listCache[tid] = anchors;
  _listCacheTime[tid] = now;
  return anchors;
}

// ==================== 频道转 LiveModel（准则 4.2） ====================
function anchorToRoom(anchor) {
  return {
    userName: anchor.title,
    roomTitle: anchor.title,
    roomCover: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
    userHeadImg: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
    liveType: LIVE_TYPE,
    liveState: "1",
    userId: anchor.id,
    roomId: anchor.id,
    liveWatchedCount: -1
  };
}

// ==================== LiveParse 插件（准则 3） ====================
globalThis.LiveParsePlugin = {
  apiVersion: 1,

  // ---- 8 个核心方法（准则 3） ----

  // 4.1 getCategories → LiveMainListModel[]
  async getCategories(payload) {
    var classes = await fetchCategories();

    var subList = classes.map(function(cat) {
      return {
        id: cat.id,
        parentId: "root",
        title: cat.title,
        icon: cat.icon,
        biz: ""
      };
    });

    subList.sort(function(a, b) {
      return a.title.localeCompare(b.title, "zh-CN");
    });

    // 在最前面添加TW直播分类
    subList.unshift({
      id: TW_CATEGORY_ID,
      parentId: "root",
      title: "TW直播",
      icon: "",
      biz: ""
    });

    return [
      {
        id: "root",
        title: "小雅直播",
        icon: "",
        biz: "",
        subList: subList
      }
    ];
  },

  // 4.2 getRooms → LiveModel[]
  async getRooms(payload) {
    var rp = _rp(payload);
    var categoryId = _str(rp.id) === "root" ? "" : _str(rp.id);
    var page = Math.max(1, _int(rp.page, 1));
    var pageSize = Math.max(1, _int(rp.pageSize, 50));

    // TW直播分类：返回本地频道
    if (categoryId === TW_CATEGORY_ID) {
      var start = (page - 1) * pageSize;
      var end = start + pageSize;
      var pageChannels = TW_CHANNELS.slice(start, end);
      return pageChannels.map(function(ch) {
        return {
          userName: ch.title,
          roomTitle: ch.title,
          roomCover: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
          userHeadImg: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
          liveType: LIVE_TYPE,
          liveState: "1",
          userId: ch.id,
          roomId: ch.id,
          liveWatchedCount: -1
        };
      });
    }

    if (!categoryId) {
      var classes = await fetchCategories();
      if (classes.length > 0) {
        categoryId = classes[0].id;
      } else {
        return [];
      }
    }

    var anchors = await fetchAnchors(categoryId);
    var start = (page - 1) * pageSize;
    var end = start + pageSize;
    var pageAnchors = anchors.slice(start, end);

    return pageAnchors.map(function(anchor) {
      return anchorToRoom(anchor);
    });
  },

  // 4.3 getPlayback → LiveQualityModel[]
  async getPlayback(payload) {
    var rp = _rp(payload);
    var roomId = _str(rp.roomId || rp.userId);
    if (!roomId) {
      _throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    }

    // TW直播频道
    if (roomId.indexOf("tw_") === 0) {
      var twChannel = TW_CHANNELS.find(function(ch) { return ch.id === roomId; });
      if (!twChannel) {
        _throw("NOT_FOUND", "频道不存在: " + roomId, { roomId: roomId });
      }
      return [
        {
          cdn: "default",
          qualitys: [
            {
              roomId: twChannel.id,
              title: "原画",
              qn: 0,
              url: twChannel.address,
              liveCodeType: "m3u8",
              liveType: LIVE_TYPE,
              userAgent: UA,
              headers: {}
            }
          ]
        }
      ];
    }

    var parts = roomId.split("_");
    var tid = parts[0];
    var index = _int(parts[1], 0);

    var anchors = await fetchAnchors(tid);
    var anchor = anchors[index];

    if (!anchor) {
      _throw("NOT_FOUND", "频道不存在: " + roomId, { roomId: roomId });
    }

    return [
      {
        cdn: "default",
        qualitys: [
          {
            roomId: anchor.id,
            title: "原画",
            qn: 0,
            url: anchor.address,
            liveCodeType: "flv",
            liveType: LIVE_TYPE,
            userAgent: UA,
            headers: {}
          }
        ]
      }
    ];
  },

  // 4.2 search → LiveModel[]
  async search(payload) {
    var rp = _rp(payload);
    var keyword = _str(rp.keyword).trim();
    if (!keyword) {
      return [];
    }

    var page = Math.max(1, _int(rp.page, 1));
    var pageSize = Math.max(1, _int(rp.pageSize, 50));

    var classes = await fetchCategories();
    var allAnchors = [];

    for (var i = 0; i < classes.length; i++) {
      try {
        var anchors = await fetchAnchors(classes[i].id);
        allAnchors = allAnchors.concat(anchors);
      } catch (e) {
        // 跳过失败的分类
      }
    }

    var keywordLower = keyword.toLowerCase();
    var filtered = allAnchors.filter(function(anchor) {
      return anchor.title.toLowerCase().indexOf(keywordLower) >= 0;
    });

    // 同时搜索TW频道
    var twFiltered = TW_CHANNELS.filter(function(ch) {
      return ch.title.toLowerCase().indexOf(keywordLower) >= 0;
    });
    var twRooms = twFiltered.map(function(ch) {
      return {
        userName: ch.title,
        roomTitle: ch.title,
        roomCover: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
        userHeadImg: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
        liveType: LIVE_TYPE,
        liveState: "1",
        userId: ch.id,
        roomId: ch.id,
        liveWatchedCount: -1
      };
    });

    var start = (page - 1) * pageSize;
    var end = start + pageSize;
    var pageAnchors = filtered.slice(start, end);

    var apiRooms = pageAnchors.map(function(anchor) {
      return anchorToRoom(anchor);
    });
    return apiRooms.concat(twRooms);
  },

  // 4.2 getRoomDetail → LiveModel
  async getRoomDetail(payload) {
    var rp = _rp(payload);
    var roomId = _str(rp.roomId || rp.userId);
    if (!roomId) {
      _throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    }

    // TW直播频道
    if (roomId.indexOf("tw_") === 0) {
      var twChannel = TW_CHANNELS.find(function(ch) { return ch.id === roomId; });
      if (!twChannel) {
        _throw("NOT_FOUND", "频道不存在: " + roomId, { roomId: roomId });
      }
      return {
        userName: twChannel.title,
        roomTitle: twChannel.title,
        roomCover: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
        userHeadImg: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
        liveType: LIVE_TYPE,
        liveState: "1",
        userId: twChannel.id,
        roomId: twChannel.id,
        liveWatchedCount: -1
      };
    }

    var parts = roomId.split("_");
    var tid = parts[0];
    var index = _int(parts[1], 0);

    var anchors = await fetchAnchors(tid);
    var anchor = anchors[index];

    if (!anchor) {
      _throw("NOT_FOUND", "频道不存在: " + roomId, { roomId: roomId });
    }

    return {
      userName: anchor.title,
      roomTitle: anchor.title,
      roomCover: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
      userHeadImg: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
      liveType: LIVE_TYPE,
      liveState: "1",
      userId: anchor.id,
      roomId: anchor.id,
      liveWatchedCount: -1
    };
  },

  // 4.4 getLiveState → { liveState: "0|1|2|3" }
  async getLiveState(payload) {
    var rp = _rp(payload);
    var roomId = _str(rp.roomId || rp.userId);
    if (!roomId) {
      return { liveState: "0" };
    }

    // TW直播频道始终在线
    if (roomId.indexOf("tw_") === 0) {
      var twChannel = TW_CHANNELS.find(function(ch) { return ch.id === roomId; });
      if (twChannel) {
        return { liveState: "1" };
      }
      return { liveState: "0" };
    }

    var parts = roomId.split("_");
    var tid = parts[0];
    var index = _int(parts[1], 0);

    try {
      var anchors = await fetchAnchors(tid);
      if (anchors[index]) {
        return { liveState: "1" };
      }
    } catch (e) {
      // ignore
    }

    return { liveState: "0" };
  },

  // resolveShare → LiveModel
  async resolveShare(payload) {
    return {};
  },

  // 4.5 getDanmaku → { args, headers }
  async getDanmaku(payload) {
    return { args: {}, headers: null };
  },

  // ---- 可选弹幕驱动方法（准则 4.6） ----
  async createDanmakuSession(payload) {
    return { ok: true, timer: { mode: "off" } };
  },

  async onDanmakuOpen(payload) {
    return { writes: [], timer: { mode: "off" } };
  },

  async onDanmakuFrame(payload) {
    return { messages: [], writes: [], timer: { mode: "off" } };
  },

  async onDanmakuTick(payload) {
    return { writes: [], timer: { mode: "off" } };
  },

  async destroyDanmakuSession(payload) {
    return { ok: true };
  },

  // ---- 可选凭证方法（准则 6） ----
  async setCookie(payload) {
    return { ok: true };
  },

  async clearCookie() {
    _categoryCache = null;
    _listCache = {};
    return { ok: true };
  },

  async setCredential(payload) {
    return { ok: true };
  },

  async clearCredential() {
    _categoryCache = null;
    _listCache = {};
    return { ok: true };
  },

  async getCredentialStatus(payload) {
    return { valid: false };
  },

  async validateCredential(payload) {
    return { ok: true };
  }
};
