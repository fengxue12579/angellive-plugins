// ============================================================
// 小雅直播 AngelLive Plugin v2.0.0
// 基于T4 API重写，正确识别FLV格式，适配AngelLive/KSPlayer
// ============================================================

var _XY_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36";
var _XY_API_HOST = "http://api.hclyz.com:81/mf";
var _XY_IMG_PROXY = "https://xiaoye.6h8jr4dgcb.workers.dev";

// 默认封面图
var _XY_DEFAULT_COVER = _XY_IMG_PROXY + "/?url=https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png";

// ============================================================
// 工具函数
// ============================================================

function _xy_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw new Error(String(message || "unknown error"));
}

function _xy_httpGet(url, headers, timeout) {
  return Host.http.request({
    platformId: "xiaoya",
    authMode: "none",
    request: {
      url: url,
      method: "GET",
      headers: headers || { "User-Agent": _XY_USER_AGENT },
      timeout: timeout || 30
    }
  });
}

// 图片URL修复：使用CF Worker代理
function _xy_fixImgUrl(imgUrl) {
  if (!imgUrl || typeof imgUrl !== "string") return _XY_DEFAULT_COVER;
  var url = String(imgUrl).trim();
  if (url.indexOf("http") !== 0) return _XY_DEFAULT_COVER;
  if (url.indexOf(_XY_IMG_PROXY) === 0) return url;
  return _XY_IMG_PROXY + "/?url=" + encodeURIComponent(url);
}

// 生成稳定的roomId
function _xy_hashId(str) {
  var hash = 0;
  for (var i = 0; i < str.length; i++) {
    var c = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + c;
    hash = hash & hash;
  }
  return "xy_" + Math.abs(hash);
}

// 判断URL格式类型
function _xy_detectCodeType(url) {
  var lowerUrl = String(url || "").toLowerCase();
  if (lowerUrl.indexOf(".flv") >= 0) return "flv";
  if (lowerUrl.indexOf(".m3u8") >= 0) return "m3u8";
  if (lowerUrl.indexOf(".ts") >= 0) return "mpegts";
  return "flv";
}

// TW频道硬编码
function _xy_fetchTWChannels() {
  return Promise.resolve([
    { title: "惊艳", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/115.ts", logo: "" },
    { title: "潘朵拉完美", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/116.ts", logo: "" },
    { title: "香蕉", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/117.ts", logo: "" },
    { title: "松視1台", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/118.ts", logo: "" },
    { title: "松視2台", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/119.ts", logo: "" },
    { title: "松視3台", address: "http://15.204.105.50:25461/live/G2s9zK2n9m/xDtwVfWM8T/120.ts", logo: "" }
  ]);
}

// ============================================================
// API数据获取
// ============================================================

// 获取平台分类列表
function _xy_fetchPlatformList() {
  return _xy_httpGet(_XY_API_HOST + "/json.txt").then(function(resp) {
    if (resp.status !== 200 || !resp.bodyText) return [];
    var obj = JSON.parse(resp.bodyText || "{}");
    var list = obj.pingtai || [];
    return list.slice(1).map(function(item) {
      return {
        title: String(item.title || ""),
        address: String(item.address || ""),
        xinimg: String(item.xinimg || ""),
        number: parseInt(item.Number || "0", 10)
      };
    });
  }).then(null, function() { return []; });
}

// 获取某个平台下的主播列表
function _xy_fetchAnchors(address) {
  return _xy_httpGet(_XY_API_HOST + "/" + encodeURIComponent(address)).then(function(resp) {
    if (resp.status !== 200 || !resp.bodyText) return [];
    var obj = JSON.parse(resp.bodyText || "{}");
    return (obj.zhubo || []).map(function(vod) {
      return {
        title: String(vod.title || ""),
        address: String(vod.address || ""),
        img: String(vod.img || "")
      };
    });
  }).then(null, function() { return []; });
}

// ============================================================
// 缓存
// ============================================================

var _xy_cache = {
  categories: null,
  categoryDefs: null,
  timestamp: 0,
  ttl: 5 * 60 * 1000
};

function _xy_getCachedData() {
  var now = Date.now();
  if (_xy_cache.categories && _xy_cache.categoryDefs && (now - _xy_cache.timestamp) < _xy_cache.ttl) {
    return Promise.resolve({
      categories: _xy_cache.categories,
      categoryDefs: _xy_cache.categoryDefs
    });
  }

  return Promise.all([
    _xy_fetchPlatformList(),
    _xy_fetchTWChannels()
  ]).then(function(results) {
    var platforms = results[0];
    var twChannels = results[1];

    var categories = {};
    var categoryDefs = [];

    // 1. TW分类放最前面
    if (twChannels.length > 0) {
      categories["tw"] = {
        platformTitle: "TW直播",
        platformAddress: "",
        platformLogo: _XY_DEFAULT_COVER,
        anchors: twChannels.map(function(ch) {
          return {
            title: ch.title,
            address: ch.address,
            logo: ch.logo || _XY_DEFAULT_COVER,
            groupTitle: "TW直播",
            codeType: "mpegts"
          };
        }),
        loaded: true
      };
      categoryDefs.push({
        id: "tw",
        title: "TW直播",
        icon: "",
        biz: "tw",
        subList: [
          { id: "tw", parentId: "tw", title: "全部TW", icon: "", biz: "tw" }
        ]
      });
    }

    // 2. 按Number排序，大的在前
    platforms.sort(function(a, b) { return b.number - a.number; });

    for (var i = 0; i < platforms.length; i++) {
      var p = platforms[i];
      if (!p.title || !p.address) continue;

      var cateId = _xy_hashId(p.address);
      var logo = _xy_fixImgUrl(p.xinimg);

      categoryDefs.push({
        id: cateId,
        title: p.title,
        icon: logo,
        biz: cateId,
        subList: [
          { id: cateId, parentId: cateId, title: "全部" + p.title, icon: "", biz: cateId }
        ]
      });

      categories[cateId] = {
        platformTitle: p.title,
        platformAddress: p.address,
        platformLogo: logo,
        anchors: null,
        loaded: false
      };
    }

    _xy_cache.categories = categories;
    _xy_cache.categoryDefs = categoryDefs;
    _xy_cache.timestamp = now;

    return { categories: categories, categoryDefs: categoryDefs };
  });
}

// 延迟加载某个分类的主播列表
function _xy_loadAnchorsForCategory(cateId) {
  return _xy_getCachedData().then(function(data) {
    var cate = data.categories[cateId];
    if (!cate || !cate.platformAddress) return [];

    if (cate.loaded && cate.anchors) {
      return Promise.resolve(cate.anchors);
    }

    return _xy_fetchAnchors(cate.platformAddress).then(function(anchors) {
      var result = anchors.map(function(a) {
        return {
          title: a.title,
          address: a.address,
          logo: _xy_fixImgUrl(a.img) || cate.platformLogo || _XY_DEFAULT_COVER,
          groupTitle: cate.platformTitle,
          codeType: _xy_detectCodeType(a.address)
        };
      });
      cate.anchors = result;
      cate.loaded = true;
      return result;
    });
  });
}

// ============================================================
// 核心功能
// ============================================================

function _xy_getCategories() {
  return _xy_getCachedData().then(function(data) {
    return data.categoryDefs;
  });
}

function _xy_getRooms(cateId, page) {
  return _xy_loadAnchorsForCategory(cateId).then(function(anchors) {
    var start = (page - 1) * 50;
    var pageItems = anchors.slice(start, start + 50);
    return pageItems.map(function(a) {
      var roomId = _xy_hashId(a.title);
      return {
        roomId: roomId,
        userId: roomId,
        userName: a.title || "未知频道",
        roomTitle: a.title || "未知频道",
        roomCover: a.logo || _XY_DEFAULT_COVER,
        userHeadImg: a.logo || _XY_DEFAULT_COVER,
        liveType: "xiaoya",
        liveState: "1",
        liveWatchedCount: "0"
      };
    });
  });
}

function _xy_getRoomDetail(roomId) {
  return _xy_getCachedData().then(function(data) {
    var cateKeys = Object.keys(data.categories);
    for (var k = 0; k < cateKeys.length; k++) {
      var cate = data.categories[cateKeys[k]];
      if (cate.anchors) {
        for (var a = 0; a < cate.anchors.length; a++) {
          if (_xy_hashId(cate.anchors[a].title) === roomId) {
            var cover = cate.anchors[a].logo || _XY_DEFAULT_COVER;
            return {
              roomId: roomId,
              userId: roomId,
              userName: cate.anchors[a].title,
              roomTitle: cate.anchors[a].title,
              roomCover: cover,
              userHeadImg: cover,
              liveType: "xiaoya",
              liveState: "1",
              liveWatchedCount: "0"
            };
          }
        }
      }
    }
    _xy_throw("NOT_FOUND", "room not found", { roomId: roomId });
  });
}

function _xy_getPlayback(roomId) {
  return _xy_getCachedData().then(function(data) {
    var cateKeys = Object.keys(data.categories);
    for (var k = 0; k < cateKeys.length; k++) {
      var cate = data.categories[cateKeys[k]];
      if (cate.anchors) {
        for (var a = 0; a < cate.anchors.length; a++) {
          if (_xy_hashId(cate.anchors[a].title) === roomId) {
            return [{
              cdn: "default",
              displayName: cate.platformTitle || "默认线路",
              qualitys: [{
                roomId: roomId,
                title: "原画",
                qn: 9999,
                url: cate.anchors[a].address,
                liveCodeType: "m3u8",
                liveType: "xiaoya",
                userAgent: _XY_USER_AGENT,
                headers: {},
                playbackHints: {
                  streamFormat: "hlsLive",
                  selectionBehavior: "direct"
                }
              }]
            }];
          }
        }
      }
    }
    _xy_throw("NOT_FOUND", "room not found for playback", { roomId: roomId });
  });
}

function _xy_search(keyword) {
  var kw = String(keyword || "").trim().toLowerCase();
  if (!kw) return Promise.resolve([]);

  return _xy_getCachedData().then(function(data) {
    var results = [];
    var cateKeys = Object.keys(data.categories);
    for (var k = 0; k < cateKeys.length; k++) {
      var cate = data.categories[cateKeys[k]];
      if (cate.anchors) {
        for (var a = 0; a < cate.anchors.length; a++) {
          if (cate.anchors[a].title.toLowerCase().indexOf(kw) >= 0) {
            var roomId = _xy_hashId(cate.anchors[a].title);
            var cover = cate.anchors[a].logo || _XY_DEFAULT_COVER;
            results.push({
              roomId: roomId, userId: roomId,
              userName: cate.anchors[a].title, roomTitle: cate.anchors[a].title,
              roomCover: cover, userHeadImg: cover,
              liveType: "xiaoya", liveState: "1", liveWatchedCount: "0"
            });
          }
        }
      }
    }
    return results;
  });
}

function _xy_getLiveState(roomId) {
  return Promise.resolve({ liveState: "1" });
}

function _xy_resolveShare(shareCode) {
  _xy_throw("NOT_SUPPORTED", "share resolve is not supported", { shareCode: shareCode });
}

function _xy_getDanmaku(payload) {
  return { args: {}, headers: null };
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function() {
    return _xy_getCategories();
  },

  getRooms: function(payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _xy_throw("INVALID_ARGS", "id is required", { field: "id" });
    if (page < 1) page = 1;
    return _xy_getRooms(id, page);
  },

  getPlayback: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getPlayback(roomId);
  },

  getRoomDetail: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getRoomDetail(roomId);
  },

  getLiveState: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xy_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xy_getLiveState(roomId);
  },

  search: function(payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _xy_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _xy_search(keyword);
  },

  resolveShare: function(payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _xy_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _xy_resolveShare(shareCode);
  },

  getDanmaku: function(payload) {
    return Promise.resolve(_xy_getDanmaku(payload));
  }
};
