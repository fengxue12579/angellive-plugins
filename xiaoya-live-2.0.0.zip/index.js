/**
 * 小雅直播 - LiveParse/AngelLive 插件 v2.0.0
 * 基于 T4 API 直播源
 * 数据来源: api.hclyz.com
 */

// ==================== 配置 ====================
var API_HOST = "http://api.hclyz.com:81/mf";
var UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var LIVE_TYPE = "99";

// ==================== 工具函数 ====================
function _throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw new Error(String(message || "unknown error"));
}

function _str(value, fallback) {
  if (typeof value === "string") return value.trim();
  return fallback || "";
}

function _int(value, fallback) {
  var n = parseInt(value, 10);
  return isNaN(n) ? (fallback || 0) : n;
}

function _rp(payload) {
  if (payload && typeof payload === "object" && !Array.isArray(payload)) return payload;
  return {};
}

// ==================== HTTP 请求 ====================
async function _httpGet(url) {
  var res = await fetch(url, {
    headers: { "User-Agent": UA }
  });
  if (!res.ok) {
    _throw("HTTP_ERROR", "HTTP " + res.status + " for " + url, { status: res.status });
  }
  return await res.json();
}

// ==================== 数据缓存 ====================
var _categoryCache = null;
var _categoryCacheTime = 0;
var _categoryCacheTTL = 10 * 60 * 1000;

var _listCache = {};
var _listCacheTime = {};
var _listCacheTTL = 5 * 60 * 1000;

async function fetchCategories() {
  var now = Date.now();
  if (_categoryCache && (now - _categoryCacheTime) < _categoryCacheTTL) {
    return _categoryCache;
  }

  var json = await _httpGet(API_HOST + "/json.txt");
  var platforms = json.pingtai || [];
  // 跳过第一个（通常是"推荐"或"全部"）
  var classes = platforms.slice(1).map(function(item) {
    return {
      id: _str(item.address),
      title: _str(item.title),
      icon: _str(item.xinimg || ""),
      number: _int(item.Number, 0)
    };
  });

  _categoryCache = classes;
  _categoryCacheTime = now;
  return classes;
}

async function fetchAnchors(tid) {
  var now = Date.now();
  if (_listCache[tid] && (now - _listCacheTime[tid]) < _listCacheTTL) {
    return _listCache[tid];
  }

  var json = await _httpGet(API_HOST + "/" + tid);
  var zhubo = json.zhubo || [];

  var anchors = zhubo.map(function(vod, index) {
    return {
      id: tid + "_" + index,
      title: _str(vod.title),
      address: _str(vod.address),
      tid: tid
    };
  });

  _listCache[tid] = anchors;
  _listCacheTime[tid] = now;
  return anchors;
}

// ==================== 频道转房间对象 ====================
function anchorToRoom(anchor) {
  return {
    userName: anchor.title,
    roomTitle: anchor.title,
    roomCover: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
    userHeadImg: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
    liveType: LIVE_TYPE,
    liveState: "1",
    userId: anchor.id,
    roomId: anchor.id,
    liveWatchedCount: "-1",
    biz: anchor.tid
  };
}

// ==================== LiveParse 插件 ====================
globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async setCookie(payload) {
    return { ok: true };
  },

  async clearCookie() {
    _categoryCache = null;
    _listCache = {};
    return { ok: true };
  },

  async getCategories(payload) {
    var classes = await fetchCategories();

    var subList = classes.map(function(cat) {
      return {
        id: cat.id,
        parentId: "root",
        title: cat.title,
        icon: cat.icon,
        biz: ""
      };
    });

    // 按数量排序
    subList.sort(function(a, b) {
      return b.title.localeCompare(a.title, "zh-CN");
    });

    return [
      {
        id: "root",
        title: "小雅直播",
        icon: "",
        biz: "",
        subList: subList
      }
    ];
  },

  async getRooms(payload) {
    var rp = _rp(payload);
    var categoryId = _str(rp.id) === "root" ? "" : _str(rp.id);
    var page = Math.max(1, _int(rp.page, 1));
    var pageSize = Math.max(1, _int(rp.pageSize, 50));

    // 如果没有选择分类，返回第一个分类的内容
    if (!categoryId) {
      var classes = await fetchCategories();
      if (classes.length > 0) {
        categoryId = classes[0].id;
      } else {
        return [];
      }
    }

    var anchors = await fetchAnchors(categoryId);

    var start = (page - 1) * pageSize;
    var end = start + pageSize;
    var pageAnchors = anchors.slice(start, end);

    return pageAnchors.map(function(anchor) {
      return anchorToRoom(anchor);
    });
  },

  async getPlayback(payload) {
    var rp = _rp(payload);
    var roomId = _str(rp.roomId || rp.userId);
    if (!roomId) {
      _throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    }

    // roomId 格式: tid_index
    var parts = roomId.split("_");
    var tid = parts[0];
    var index = _int(parts[1], 0);

    var anchors = await fetchAnchors(tid);
    var anchor = anchors[index];

    if (!anchor) {
      _throw("NOT_FOUND", "频道不存在: " + roomId, { roomId: roomId });
    }

    return {
      url: anchor.address,
      title: anchor.title,
      headers: {}
    };
  },

  async search(payload) {
    var rp = _rp(payload);
    var keyword = _str(rp.keyword).trim();
    if (!keyword) {
      return [];
    }

    var page = Math.max(1, _int(rp.page, 1));
    var pageSize = Math.max(1, _int(rp.pageSize, 50));

    // 搜索所有分类
    var classes = await fetchCategories();
    var allAnchors = [];

    for (var i = 0; i < classes.length; i++) {
      try {
        var anchors = await fetchAnchors(classes[i].id);
        allAnchors = allAnchors.concat(anchors);
      } catch (e) {
        // 跳过失败的分类
      }
    }

    var keywordLower = keyword.toLowerCase();
    var filtered = allAnchors.filter(function(anchor) {
      return anchor.title.toLowerCase().indexOf(keywordLower) >= 0;
    });

    var start = (page - 1) * pageSize;
    var end = start + pageSize;
    var pageAnchors = filtered.slice(start, end);

    return pageAnchors.map(function(anchor) {
      return anchorToRoom(anchor);
    });
  },

  async getRoomDetail(payload) {
    var rp = _rp(payload);
    var roomId = _str(rp.roomId || rp.userId);
    if (!roomId) {
      _throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    }

    var parts = roomId.split("_");
    var tid = parts[0];
    var index = _int(parts[1], 0);

    var anchors = await fetchAnchors(tid);
    var anchor = anchors[index];

    if (!anchor) {
      _throw("NOT_FOUND", "频道不存在: " + roomId, { roomId: roomId });
    }

    return {
      userName: anchor.title,
      roomTitle: anchor.title,
      roomCover: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
      userHeadImg: "https://raw.githubusercontent.com/fish2018/lib/refs/heads/main/imgs/live.png",
      liveType: LIVE_TYPE,
      liveState: "1",
      userId: anchor.id,
      roomId: anchor.id,
      liveWatchedCount: "-1",
      biz: tid,
      notice: "在线直播中"
    };
  },

  async getLiveState(payload) {
    var rp = _rp(payload);
    var roomId = _str(rp.roomId || rp.userId);
    if (!roomId) {
      return { liveState: "0" };
    }

    var parts = roomId.split("_");
    var tid = parts[0];
    var index = _int(parts[1], 0);

    try {
      var anchors = await fetchAnchors(tid);
      if (anchors[index]) {
        return { liveState: "1" };
      }
    } catch (e) {
      // ignore
    }

    return { liveState: "0" };
  },

  async resolveShare(payload) {
    return {};
  },

  async getDanmaku(payload) {
    return { args: {}, headers: null };
  },

  async createDanmakuSession(payload) {
    return { args: {}, headers: null };
  },

  async onDanmakuOpen(payload) {
    return { ok: true };
  },

  async onDanmakuClose(payload) {
    return { ok: true };
  },

  async sendDanmaku(payload) {
    return { ok: true };
  },

  async getCredentialKinds() {
    return { kinds: [] };
  },

  async validateCredential(payload) {
    return { ok: true };
  },

  async checkCredentialStatus(payload) {
    return { valid: false };
  },

  async clearCredential(payload) {
    return { ok: true };
  }
};
