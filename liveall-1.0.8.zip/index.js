/* 聚合直播 LiveParse Plugin v1.0.0
 * 9平台：来秀/畅聊/流星/VV星球/乐嗨/PandaTV/Stripchat/体育直播/蜘蛛直播
 * 基于 py_liveall_9plat.py 转换
 */

/* ================= MD5 (用于来秀/乐嗨签名) ================= */
var MD5 = (function() {
  function md5cycle(x, k) {
    var a = x[0], b = x[1], c = x[2], d = x[3];
    a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586);
    c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
    a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426);
    c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
    a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417);
    c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
    a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101);
    c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
    a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632);
    c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
    a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083);
    c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
    a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690);
    c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
    a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784);
    c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
    a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463);
    c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
    a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353);
    c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
    a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222);
    c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
    a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835);
    c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
    a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415);
    c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
    a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606);
    c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
    a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744);
    c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
    a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379);
    c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
    x[0] = add32(a, x[0]); x[1] = add32(b, x[1]); x[2] = add32(c, x[2]); x[3] = add32(d, x[3]);
  }
  function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
  function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
  function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
  function md51(s) {
    var txt = ''; var n = s.length, state = [1732584193, -271733879, -1732584194, 271733878], i;
    for (i = 64; i <= s.length; i += 64) { md5cycle(state, md5blk(s.substring(i - 64, i))); }
    s = s.substring(i - 64); var tail = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
    for (i = 0; i < s.length; i++) tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
    tail[i >> 2] |= 0x80 << ((i % 4) << 3);
    if (i > 55) { md5cycle(state, tail); tail = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]; }
    tail[14] = n * 8; md5cycle(state, tail); return state;
  }
  function md5blk(s) { var md5blks = [], i; for (i = 0; i < 64; i += 4) { md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i+1) << 8) + (s.charCodeAt(i+2) << 16) + (s.charCodeAt(i+3) << 24); } return md5blks; }
  function rhex(n) { var s = '', j; for (j = 0; j < 4; j++) s += hex_chr[(n >> (j * 8 + 4)) & 0x0F] + hex_chr[(n >> (j * 8)) & 0x0F]; return s; }
  function hex(x) { for (var i = 0; i < x.length; i++) x[i] = rhex(x[i]); return x.join(''); }
  function add32(a, b) { return (a + b) & 0xFFFFFFFF; }
  var hex_chr = '0123456789abcdef'.split('');
  return function(s) { return hex(md51(s)); };
})();

/* ================= 通用工具 ================= */
function laThrow(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, context || {});
  throw new Error(String(message || "unknown error"));
}
function laStr(v) { return v === undefined || v === null ? "" : String(v); }
function laInt(v, fb) { var n = parseInt(v, 10); return isNaN(n) ? fb : n; }
function laPayload(p) { return (p && typeof p === "object") ? p : {}; }

async function laHttp(opts, errCode) {
  try {
    var req = { url: opts.url, method: opts.method || "GET", headers: opts.headers || {}, timeout: opts.timeout || 15 };
    if (opts.body !== undefined) req.body = opts.body;
    var res = await Host.http.request({ authMode: "none", followRedirects: false, request: req });
    return res;
  } catch (e) {
    laThrow(errCode || "NETWORK", "网络请求失败", { url: opts.url });
  }
}
async function laGetText(url, headers) {
  var res = await laHttp({ url: url, method: "GET", headers: headers || {} }, "NETWORK");
  return laStr(res && (res.bodyText !== undefined ? res.bodyText : res.body));
}
async function laGetJson(url, headers) {
  var t = await laGetText(url, headers);
  try { return JSON.parse(t || "{}"); } catch (e) { return {}; }
}
function laWithTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise(function(_, reject) { setTimeout(function() { reject(new Error("timeout")); }, ms); })
  ]);
}

/* ================= 体育直播 sports1 ================= */
var SP1 = {
  apiBase: "https://lzfs5tah9amkatbu4tb07.k8v4dh4.app",
  ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
  headers: function() {
    return { "User-Agent": this.ua, "Referer": this.apiBase, "Accept": "application/json" };
  },
  classes: [
    { id: "live", title: "正在直播" },
    { id: "all", title: "全部主播" },
    { id: "football", title: "⚽足球" },
    { id: "basketball", title: "🏀篮球" },
    { id: "match", title: "赛事直播" }
  ],
  getIndex: async function() {
    var url = this.apiBase + "/api/c5/business/livehouse/index?lang=zh&timestamp=" + Date.now();
    try {
      var d = await laGetJson(url, this.headers());
      if (d && d.success === true) return d.data || {};
    } catch (e) {}
    return {};
  },
  collect: function(data) {
    var result = [], seen = {};
    var lists = [data.ongoingLivestreams || [], data.anchorLivestreams || [], data.streamingAnchorRanking || []];
    (data.matchLivestreams || []).forEach(function(ml) {
      if (ml && ml.reservedAnchors) lists.push(ml.reservedAnchors);
    });
    lists.forEach(function(arr) {
      if (!Array.isArray(arr)) return;
      arr.forEach(function(item) {
        if (!item || typeof item !== "object") return;
        var hid = laStr(item.houseId);
        if (!hid || seen[hid]) return;
        seen[hid] = true;
        result.push(item);
      });
    });
    return result;
  },
  streamUrl: function(item) {
    var hls = laStr(item.playStreamAddress2), flv = laStr(item.playStreamAddress);
    if (hls && hls !== "www") return hls;
    if (flv && flv !== "www") return flv;
    return "";
  },
  fmtView: function(n) {
    n = laInt(n, 0);
    if (n >= 10000) return (n / 10000).toFixed(1) + "万";
    return String(n);
  },
  toRoom: function(item) {
    var hid = laStr(item.houseId);
    var hn = laStr(item.houseName || item.houseNameEn || ("ID:" + hid));
    var nn = laStr(item.nickName);
    var title = (nn ? nn + " - " : "") + hn;
    var cover = laStr(item.houseImage || item.loadingCover || item.userImage);
    var ls = laInt(item.liveStatus, 0);
    var remark = ls === 2 ? "👁" + this.fmtView(item.visitHistory) + "|直播中" : "回放";
    return {
      userName: title, roomTitle: remark, roomCover: cover, userHeadImg: cover,
      userId: hid, roomId: "sports1@" + hid, liveState: ls === 2 ? "1" : "0",
      liveWatchedCount: laInt(item.visitHistory, 0)
    };
  },
  getRooms: async function(tid, page, extend) {
    page = Math.max(1, parseInt(page) || 1);
    var _ps = (extend && extend.pageSize) ? Math.max(1, Math.min(100, parseInt(extend.pageSize) || 30)) : 30;
    var data = await this.getIndex();
    var all = this.collect(data);
    var self = this;
    var out = [];
    all.forEach(function(item) {
      var ls = laInt(item.liveStatus, 0), rt = laInt(item.raceTypeId, 0);
      var has = !!self.streamUrl(item);
      var keep = false;
      if (tid === "live") keep = ls === 2 && has;
      else if (tid === "all") keep = has && ls !== 3 && ls !== 4;
      else if (tid === "football") keep = rt === 1 && has;
      else if (tid === "basketball") keep = rt === 2 && has;
      else if (tid === "match") keep = (item.matchList || []).length > 0 && has;
      else keep = has;
      if (keep) out.push(self.toRoom(item));
    });
    var _start = (page - 1) * _ps;
    return out.slice(_start, _start + _ps);
  },
  getPlayback: async function(hid) {
    var data = await this.getIndex();
    var all = this.collect(data);
    for (var i = 0; i < all.length; i++) {
      if (laStr(all[i].houseId) === hid) {
        var url = this.streamUrl(all[i]);
        if (url) {
          return [{ cdn: "default", qualitys: [{
            roomId: "sports1@" + hid, title: "直播", qn: 0, url: url,
            liveCodeType: url.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
            liveType: "30", userAgent: this.ua,
            headers: { "Referer": this.apiBase }
          }]}];
        }
      }
    }
    laThrow("NOT_FOUND", "无可用播放流", { roomId: hid });
  },
  search: async function(key) {
    var data = await this.getIndex();
    var all = this.collect(data);
    var kw = laStr(key).toLowerCase().trim();
    var self = this, out = [];
    all.forEach(function(item) {
      if (!self.streamUrl(item)) return;
      var hn = laStr(item.houseName).toLowerCase(), nn = laStr(item.nickName).toLowerCase(), hid = laStr(item.houseId).toLowerCase();
      if (kw && (hn.indexOf(kw) >= 0 || nn.indexOf(kw) >= 0 || hid.indexOf(kw) >= 0)) out.push(self.toRoom(item));
    });
    return out;
  }
};

/* ================= 蜘蛛直播 sports2 ================= */
var SP2 = {
  apiBase: "https://ugcaamdqtywxlcnuucb01.k8v4dh4.app",
  referer: "https://zzzb93vip.app",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Safari/537.36",
  headers: function() {
    return { "User-Agent": this.ua, "Accept": "application/json, text/plain, */*", "Referer": this.referer, "Origin": this.referer };
  },
  classes: [
    { id: "live", title: "正在直播" },
    { id: "all", title: "全部主播" },
    { id: "football", title: "⚽足球" },
    { id: "basketball", title: "🏀篮球" },
    { id: "match", title: "赛事直播" }
  ],
  getIndex: async function() {
    var url = this.apiBase + "/api/c5/business/livehouse/index?lang=zh&timestamp=" + Date.now();
    try {
      var d = await laGetJson(url, this.headers());
      if (d && d.success) return d.data || {};
    } catch (e) {}
    return {};
  },
  collect: SP1.collect,
  streamUrl: SP1.streamUrl,
  fmtView: SP1.fmtView,
  toRoom: function(item) {
    var hid = laStr(item.houseId);
    var hn = laStr(item.houseName || item.houseNameEn || ("ID:" + hid));
    var nn = laStr(item.nickName);
    var title = (nn ? nn + " - " : "") + hn;
    var cover = laStr(item.houseImage || item.loadingCover || item.userImage);
    var ls = laInt(item.liveStatus, 0);
    var remark = "👁 " + SP1.fmtView(item.visitHistory) + " | " + (ls === 2 ? "直播中" : "回放");
    return {
      userName: title, roomTitle: remark, roomCover: cover, userHeadImg: cover,
      userId: hid, roomId: "sports2@" + hid, liveState: ls === 2 ? "1" : "0",
      liveWatchedCount: laInt(item.visitHistory, 0)
    };
  },
  getRooms: async function(tid, page, extend) {
    page = Math.max(1, parseInt(page) || 1);
    var _ps = (extend && extend.pageSize) ? Math.max(1, Math.min(100, parseInt(extend.pageSize) || 30)) : 30;
    var data = await this.getIndex();
    var all = this.collect(data);
    var self = this, out = [];
    all.forEach(function(item) {
      var ls = laInt(item.liveStatus, 0), rt = laInt(item.raceTypeId, 0);
      var has = !!self.streamUrl(item);
      var keep = false;
      if (tid === "live") keep = ls === 2 && has;
      else if (tid === "all") keep = has && ls !== 3 && ls !== 4;
      else if (tid === "football") keep = rt === 1 && has;
      else if (tid === "basketball") keep = rt === 2 && has;
      else if (tid === "match") keep = (item.matchList || []).length > 0 && has;
      else keep = has;
      if (keep) out.push(self.toRoom(item));
    });
    var _start = (page - 1) * _ps;
    return out.slice(_start, _start + _ps);
  },
  getPlayback: async function(hid) {
    var data = await this.getIndex();
    var all = this.collect(data);
    for (var i = 0; i < all.length; i++) {
      if (laStr(all[i].houseId) === hid) {
        var url = this.streamUrl(all[i]);
        if (url) {
          return [{ cdn: "default", qualitys: [{
            roomId: "sports2@" + hid, title: "直播", qn: 0, url: url,
            liveCodeType: url.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
            liveType: "30", userAgent: this.ua,
            headers: { "Referer": this.referer }
          }]}];
        }
      }
    }
    laThrow("NOT_FOUND", "无可用播放流", { roomId: hid });
  },
  search: SP1.search
};

/* ================= VV星球 vvxq ================= */
var VV = {
  apiBase: "https://h5p.vvxqiu.com",
  origin: "https://h5webcdn-pro.vvxqiu.com",
  ua: "ios/7.830 (ios 17.0; ; iPhone 15 (A2846/A3089/A3090/A3092))",
  imgBase: "https://image-app-pro.wasaixiu.com",
  headers: function() {
    return {
      "User-Agent": this.ua,
      "access-control-request-method": "GET",
      "origin": this.origin,
      "referer": this.origin + "/"
    };
  },
  classes: [
    { id: "all", title: "全部直播" },
    { id: "hot", title: "热门主播" },
    { id: "new", title: "新人主播" }
  ],
  fetchAll: async function() {
    var all = [], seen = {};
    for (var p = 0; p < 10; p++) {
      var start = p * 50, end = start + 50;
      var url = this.apiBase + "/room/video/getLiveRoomList.do?start=" + start + "&end=" + end;
      try {
        var d = await laGetJson(url, this.headers());
        var infos = (d && d.infos) || [];
        if (!infos.length) break;
        infos.forEach(function(it) {
          if (laStr(it.status) !== "100" || !it.playHfsUrl) return;
          var rid = laStr(it.roomId);
          if (!rid || seen[rid]) return;
          seen[rid] = true;
          all.push(it);
        });
      } catch (e) { break; }
    }
    all.sort(function(a, b) { return (b.online || 0) - (a.online || 0); });
    return all;
  },
  toRoom: function(it) {
    var rid = laStr(it.roomId);
    var nn = laStr(it.nickName), rn = laStr(it.roomName);
    var name = (rn && rn !== nn) ? nn + " - " + rn : nn;
    var pic = laStr(it.anchorLogo);
    if (pic && pic.indexOf("http") !== 0) pic = this.imgBase + pic;
    var remark = "在线" + (it.online || 0);
    if (it.location) remark = it.location + " | " + remark;
    return {
      userName: name, roomTitle: remark, roomCover: pic, userHeadImg: pic,
      userId: rid, roomId: "vvxq@" + rid + "@@" + laStr(it.playHfsUrl),
      liveState: "1", liveWatchedCount: laInt(it.online, 0)
    };
  },
  getRooms: async function(tid, page) {
    var all = await this.fetchAll();
    var ps = 20, start = (Math.max(1, page) - 1) * ps;
    var self = this;
    return all.slice(start, start + ps).map(function(it) { return self.toRoom(it); });
  },
  getPlayback: async function(vid) {
    // vid 格式: {roomId}@@{m3u8} 或纯 m3u8
    var url = vid;
    if (vid.indexOf("@@") >= 0) url = vid.split("@@")[1];
    if (!url) laThrow("NOT_FOUND", "无可用播放流", {});
    return [{ cdn: "default", qualitys: [{
      roomId: "vvxq@" + vid, title: "直播", qn: 0, url: url,
      liveCodeType: "m3u8", liveType: "30", userAgent: this.ua,
      headers: { "Origin": this.origin, "Referer": this.origin + "/" }
    }]}];
  },
  search: async function(key) {
    var all = await this.fetchAll();
    var kw = laStr(key).toLowerCase();
    var self = this, out = [];
    all.forEach(function(it) {
      var nn = laStr(it.nickName).toLowerCase(), rn = laStr(it.roomName).toLowerCase(), rid = laStr(it.roomId).toLowerCase();
      if (kw && (nn.indexOf(kw) >= 0 || rn.indexOf(kw) >= 0 || rid.indexOf(kw) >= 0)) out.push(self.toRoom(it));
    });
    return out;
  }
};

/* ================= 乐嗨 lehai ================= */
var LH = {
  site: "https://www.lehaitv.com",
  svc: "https://service.lehaitv.com/v2",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.0.0 Safari/537.36",
  accessToken: "7QO8G16+lIbTzFuB3UGAtG/6ev2KjsDc0XV5TPg53eeXkVRqPcaRlg==",
  tku: "66950839",
  salt: "1eha12h5",
  headers: function() {
    return {
      "User-Agent": this.ua, "Referer": this.site + "/",
      "Origin": this.site, "web_did": "bdc4ca1d-4e6f-47ae-ecc7-fcb1835c8a27"
    };
  },
  classes: [
    { id: "hot", title: "热门直播" },
    { id: "dancer", title: "热舞" }
  ],
  // 双重URL编码
  q2: function(v) {
    v = laStr(v).trim();
    return encodeURIComponent(encodeURIComponent(v));
  },
  sign: function(params) {
    var keys = Object.keys(params).filter(function(k) {
      var v = params[k];
      return v !== undefined && v !== null && laStr(v) !== "";
    });
    // accessToken/tku/_st1 优先固定顺序，其余字母序
    var order = { "accessToken": 0, "tku": 1, "_st1": 2 };
    keys.sort(function(a, b) {
      var oa = order.hasOwnProperty(a) ? order[a] : 99;
      var ob = order.hasOwnProperty(b) ? order[b] : 99;
      if (oa !== ob) return oa - ob;
      return a < b ? -1 : (a > b ? 1 : 0);
    });
    var chain = keys.map(function(k) { return k + "=" + this.q2(params[k]); }, this).join("&");
    return MD5(chain + this.salt);
  },
  signedGet: async function(path, query) {
    var st1 = String(Date.now());
    var params = { accessToken: this.accessToken, tku: this.tku, _st1: st1 };
    Object.keys(query || {}).forEach(function(k) { params[k] = query[k]; });
    var sign = this.sign(params);
    var qs = Object.keys(params).map(function(k) {
      return k + "=" + encodeURIComponent(laStr(params[k]));
    }).join("&");
    var url = this.svc + path + "?" + qs + "&_ajaxData1=" + sign + "&_=" + Math.floor(Date.now() / 1000);
    return await laGetJson(url, this.headers());
  },
  fetchRooms: async function() {
    var d = await laGetJson(this.site + "/json/commonrooms.json", this.headers());
    if (!d) laThrow("NETWORK", "乐嗨列表接口无响应", {});
    var list = (d && d.hotAnchorList) || [];
    if (list.length === 0) laThrow("EMPTY", "乐嗨列表为空", { keys: Object.keys(d || {}) });
    return list.filter(function(it) { return laInt(it.live_status, 0) === 1; });
  },
  toRoom: function(it) {
    var rid = laStr(it.roomid);
    var nn = laStr(it.nickname) || ("房间" + rid);
    var pic = laStr(it.avatar || it.coverW9H16);
    var remark = it.is_dancer ? "热舞" : ("在线:" + laStr(it.member_num));
    return {
      userName: nn, roomTitle: remark, roomCover: pic, userHeadImg: pic,
      userId: rid, roomId: "lehai@" + rid, liveState: "1",
      liveWatchedCount: laInt(it.member_num, 0)
    };
  },
  getRooms: async function(tid, page) {
    var all = await this.fetchRooms();
    if (tid === "dancer") all = all.filter(function(it) { return it.is_dancer; });
    var ps = 20, start = (Math.max(1, parseInt(page) || 1) - 1) * ps;
    var self = this;
    return all.slice(start, start + ps).map(function(it) { return self.toRoom(it); });
  },
  getPlayback: async function(rid) {
    // 从 id 提取房间号
    var m = laStr(rid).split("$").pop().split("|")[0].split("/").pop();
    var d = await this.signedGet("/room/" + m + "/media/advanceInfoRoom", {});
    var data = (d && d.data) || {};
    // 宽松解析：只要有 media_url 就用，不严格卡 statuscode
    var url = laStr(data.media_url_web) || laStr(data.media_url_app) || laStr(data.medial_url_app_for_h264) || laStr(data.media_url) || "";
    if (url) {
      return [{ cdn: "default", qualitys: [{
        roomId: "lehai@" + m, title: "直播", qn: 0, url: url,
        liveCodeType: url.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
        liveType: "30", userAgent: this.ua, headers: { "Referer": this.site + "/" }
      }]}];
    }
    laThrow("NOT_FOUND", "无可用播放流", { roomId: rid });
  },
  search: async function(key) {
    var all = await this.fetchRooms();
    var kw = laStr(key).toLowerCase();
    var self = this, out = [];
    all.forEach(function(it) {
      var nn = laStr(it.nickname).toLowerCase(), rt = laStr(it.roomTitle).toLowerCase(), rid = laStr(it.roomid).toLowerCase();
      if (kw && (nn.indexOf(kw) >= 0 || rt.indexOf(kw) >= 0 || rid.indexOf(kw) >= 0)) out.push(self.toRoom(it));
    });
    return out.slice(0, 30);
  }
};

/* ================= PandaTV panda ================= */
var PD = {
  host: "https://5721004.xyz",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  defPic: "https://tupian.li/images/2024/03/30/660769b1ba623.png",
  proxies: [
    "https://hubu.515355.xyz/proxy/?", "https://flank.515355.xyz/proxy/",
    "https://uae2.515355.xyz/proxy/", "https://pol.515355.xyz/proxy/",
    "https://f00.515355.xyz/proxy/", "https://ce2.515355.xyz/proxy/?"
  ],
  headers: function() {
    return { "User-Agent": this.ua, "Referer": "https://www.pandalive.co.kr/", "Origin": "https://www.pandalive.co.kr" };
  },
  classes: [{ id: "pandalive", title: "🐼 PandaTV" }],
  fetchList: async function() {
    try {
      var d = await laGetJson(this.host + "/player/list.json", this.headers());
      return (d && d.list) || [];
    } catch (e) { return []; }
  },
  toRoom: function(it) {
    var uid = laStr(it.userId);
    var name = "📺 " + laStr(it.userNick);
    var pic = laStr(it.thumbUrl) || this.defPic;
    var remark = "👤 " + laStr(it.user) + (it.isAdult ? " 🔞" : "");
    return {
      userName: name, roomTitle: remark, roomCover: pic, userHeadImg: pic,
      userId: uid, roomId: "panda@live_" + uid, liveState: "1",
      liveWatchedCount: laInt(it.user, 0),
      _isAdult: !!it.isAdult, _isPw: !!it.isPw, _type: laStr(it.type),
      _user_count: laInt(it.user, 0), _score: laInt(it.totalScoreCnt, 0), _bookmark: laInt(it.bookmarkCnt, 0)
    };
  },
  getRooms: async function(tid, page, extend) {
    var all = await this.fetchList();
    var ext = extend || {};
    var type = laStr(ext.type || "all"), sort = laStr(ext.sort || "user-desc");
    var self = this;
    var filtered = all.filter(function(it) {
      var r = self.toRoom(it);
      if (type === "adult" && !r._isAdult) return false;
      if (type === "pw" && !r._isPw) return false;
      if (type === "fan" && r._type !== "fan") return false;
      return true;
    }).map(function(it) { return self.toRoom(it); });
    filtered.sort(function(a, b) {
      if (sort === "totalScoreCnt-desc") return b._score - a._score;
      if (sort === "bookmarkCnt-desc") return b._bookmark - a._bookmark;
      return b._user_count - a._user_count;
    });
    var ps = 30, start = (Math.max(1, page) - 1) * ps;
    return filtered.slice(start, start + ps);
  },
  getPlayback: async function(vid) {
    // vid: live_{userId}，从 list.m3u 找流地址
    var uid = laStr(vid).replace(/^live_/, "");
    var text = await laGetText(this.host + "/player/list.m3u", this.headers());
    var lines = text.split("\n"), url = "";
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].indexOf("," + uid + ",") >= 0 && i + 1 < lines.length) {
        url = lines[i + 1].trim();
        break;
      }
    }
    if (!url) {
      for (var j = 0; j < lines.length; j++) {
        if (lines[j].indexOf(uid) >= 0 && j + 1 < lines.length) {
          url = lines[j + 1].trim();
          break;
        }
      }
    }
    if (!url) laThrow("NOT_FOUND", "无可用播放流", { roomId: vid });
    var self = this;
    var qualitys = [{
      roomId: "panda@" + vid, title: "直连", qn: 0, url: url,
      liveCodeType: "m3u8", liveType: "30", userAgent: this.ua, headers: this.headers()
    }];
    this.proxies.forEach(function(px, idx) {
      qualitys.push({
        roomId: "panda@" + vid, title: "代理" + (idx + 1), qn: 0, url: px + url,
        liveCodeType: "m3u8", liveType: "30", userAgent: self.ua, headers: self.headers()
      });
    });
    return [{ cdn: "default", qualitys: qualitys }];
  },
  search: async function(key) {
    var all = await this.fetchList();
    var kw = laStr(key).toLowerCase();
    var self = this, out = [];
    all.forEach(function(it) {
      var r = self.toRoom(it);
      var nm = laStr(it.userNick).toLowerCase(), au = laStr(it.userId).toLowerCase();
      if (kw && (nm.indexOf(kw) >= 0 || au.indexOf(kw) >= 0)) out.push(r);
    });
    return out.slice(0, 50);
  }
};

/* ================= 来秀 laixiu ================= */
var LX = {
  apiBase: "https://wapapi.imkktv.com",
  imgBase: "http://kkimg.imkktv.com",
  secret: "kk792f28d6ff1f34ec702c08626d454b39pro",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  imei: "",
  classes: [
    { id: "all", title: "全部直播" },
    { id: "hot", title: "热度排行" },
    { id: "dance", title: "舞蹈" },
    { id: "female", title: "女主播" },
    { id: "male", title: "男主播" }
  ],
  init: function() {
    if (!this.imei) {
      var s = "";
      for (var i = 0; i < 32; i++) s += Math.floor(Math.random() * 10);
      this.imei = s;
    }
  },
  headers: function() {
    this.init();
    var ts = String(Date.now()) + String(Math.floor(Math.random() * 900000) + 100000);
    var rid = MD5("web" + this.imei + ts + this.secret);
    return {
      "User-Agent": this.ua, "Referer": "https://www.imkktv.com/",
      "Origin": "https://www.imkktv.com",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "platform": "WEB", "version": "1.0.0", "versionCode": "10003",
      "imei": this.imei, "os": "web", "mobileModel": "web",
      "loginType": "2", "channel": "9",
      "timestamp": ts, "requestId": rid
    };
  },
  fixImg: function(p) {
    p = laStr(p);
    if (!p) return "";
    if (p.indexOf("//") === 0) return "http:" + p;
    if (p.charAt(0) === "/") return this.imgBase + p;
    return p.replace("https://", "http://");
  },
  extractFlv: function(item) {
    var ps = item.roomPlayStream || {};
    var info = ps.playStreamInfo || {};
    var cands = [info.urlPlayAcc, info.urlPlayFlv, info.urlPlayAccMix, info.urlPlayHls, item.urlPlayFlv, item.urlPlayHls];
    for (var i = 0; i < cands.length; i++) {
      var u = laStr(cands[i]);
      if (u) {
        if (u.indexOf("//") === 0) u = "http:" + u;
        return u.replace("https://", "http://");
      }
    }
    return "";
  },
  fetchAll: async function() {
    var all = [];
    for (var pg = 1; pg <= 10; pg++) {
      var url = this.apiBase + "/supplement/guest/image/banner/getBannerAndLiveHot/v2?currentPage=" + pg;
      try {
        var d = await laGetJson(url, this.headers());
        var list = (d && d.data && d.data.resLiveHotDtoList) || [];
        if (!list.length) break;
        all = all.concat(list);
      } catch (e) { break; }
    }
    return all;
  },
  toRoom: function(item) {
    var aid = laStr(item.anchorId);
    var pic = this.fixImg(item.livingImg || item.liveCoverUrl || item.avatar);
    return {
      userName: laStr(item.nickname), roomTitle: "👁" + laStr(item.audienceNum || ""),
      roomCover: pic, userHeadImg: pic, userId: aid, roomId: "laixiu@" + aid,
      liveState: "1", liveWatchedCount: laInt(item.audienceNum, 0),
      _sex: laInt(item.sex, 0), _item: item
    };
  },
  getRooms: async function(tid, page, extend) {
    var all = await this.fetchAll();
    var self = this;
    var sort = (extend && extend.sort) || "1";
    var filtered = all.filter(function(item) {
      var nn = laStr(item.nickname), ti = laStr(item.liveTitle || ""), tag = laStr(item.tag || "");
      if (tid === "dance") return /舞/.test(nn + ti + tag);
      if (tid === "female") return laInt(item.sex, 0) === 2;
      if (tid === "male") return laInt(item.sex, 0) === 1;
      return true;
    });
    filtered.sort(function(a, b) {
      if (sort === "2") return laInt(b.sunlight, 0) - laInt(a.sunlight, 0);
      return laInt(b.audienceNum, 0) - laInt(a.audienceNum, 0);
    });
    var ps = 30, start = (Math.max(1, page) - 1) * ps;
    return filtered.slice(start, start + ps).map(function(it) { return self.toRoom(it); });
  },
  getPlayback: async function(aid) {
    var id = laStr(aid).split("$").pop().split("|")[0].split("/").pop().replace(/\D/g, "");
    var url = this.apiBase + "/liveroom/guest/getPlayUrlGuest?anchorId=" + id;
    try {
      var d = await laGetJson(url, this.headers());
      var data = (d && d.data) || {};
      var u = laStr(data.urlPlayAcc || data.urlPlayFlv || data.urlPlayAccMix || data.urlPlayHls);
      if (u) {
        if (u.indexOf("//") === 0) u = "http:" + u;
        u = u.replace("https://", "http://");
        return [{ cdn: "default", qualitys: [{
          roomId: "laixiu@" + id, title: "直播", qn: 0, url: u,
          liveCodeType: u.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
          liveType: "30", userAgent: this.ua,
          headers: { "Referer": "https://www.imkktv.com/" }
        }]}];
      }
    } catch (e) {}
    laThrow("NOT_FOUND", "无可用播放流", { roomId: aid });
  },
  search: async function(key) {
    var all = await this.fetchAll();
    var kw = laStr(key).toLowerCase();
    var self = this, out = [];
    all.forEach(function(item) {
      var nn = laStr(item.nickname).toLowerCase(), ti = laStr(item.liveTitle || "").toLowerCase(), aid = laStr(item.anchorId).toLowerCase();
      if (kw && (nn.indexOf(kw) >= 0 || ti.indexOf(kw) >= 0 || aid.indexOf(kw) >= 0)) out.push(self.toRoom(item));
    });
    return out.slice(0, 30);
  }
};

/* ================= 畅聊 changliao ================= */
var CL = {
  tagApi: "https://show.336769.com/api/ApiServices/service/top/show/tag",
  roomApi: "https://show.336769.com/api/ApiServices/service/live/getLiveStreamInfo",
  photoBase: "https://photo.336769.com",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  headers: function() {
    return {
      "User-Agent": this.ua, "Referer": "https://show.336769.com/",
      "Origin": "https://show.336769.com", "Accept": "application/json, text/plain, */*"
    };
  },
  classes: [
    { id: "all", title: "全部" },
    { id: "online", title: "在线直播" },
    { id: "female", title: "女主播" },
    { id: "male", title: "男主播" },
    { id: "dance", title: "舞蹈" }
  ],
  fixImg: function(p) {
    p = laStr(p);
    if (!p) return "";
    if (p.indexOf("//") === 0) return "https:" + p;
    if (p.charAt(0) === "/") return this.photoBase + p;
    return p;
  },
  fetchPage: async function(pg) {
    var url = this.tagApi + "?pageIndex=" + pg + "&pageSize=100&tagid=45";
    try {
      var d = await laGetJson(url, this.headers());
      if (d && d.code === 100000) return d.data || [];
    } catch (e) {}
    return [];
  },
  toRoom: function(item) {
    var rid = laStr(item.roomnumber || item.roomId || item.anchorId);
    var pic = this.fixImg(item.showcover || item.avatar);
    var online = laInt(item.isonline, 0) === 1;
    var remark = online ? ("人气" + laStr(item.audienceSize || "直播中")) : "离线";
    return {
      userName: laStr(item.nickname), roomTitle: remark, roomCover: pic, userHeadImg: pic,
      userId: rid, roomId: "changliao@" + rid, liveState: online ? "1" : "0",
      liveWatchedCount: laInt(item.audienceSize, 0),
      _gender: laInt(item.gender, 0), _item: item, _videoUrl: laStr(item.videoUrl)
    };
  },
  getRooms: async function(tid, page, extend) {
    var self = this;
    var sort = (extend && extend.sort) || "1";
    var rooms = [];
    if (tid === "all") {
      var list = await this.fetchPage(Math.max(1, page));
      list.forEach(function(item) {
        if (laInt(item.isonline, 0) === 1) rooms.push(self.toRoom(item));
      });
      return rooms;
    }
    // 其他分类用缓存（前3页）
    var all = [];
    for (var pg = 1; pg <= 3; pg++) {
      var l = await this.fetchPage(pg);
      if (!l.length) break;
      all = all.concat(l);
    }
    var filtered = all.filter(function(item) {
      if (laInt(item.isonline, 0) !== 1) return false;
      if (tid === "female") return laInt(item.gender, 0) === 2;
      if (tid === "male") return laInt(item.gender, 0) === 1;
      if (tid === "online") return true;
      if (tid === "dance") {
        var labels = item.coverLabelList || [];
        for (var i = 0; i < labels.length; i++) {
          if (labels[i].dressingNameEn === "Meiwu_master") return true;
        }
        return /舞/.test(laStr(item.nickname));
      }
      return true;
    });
    filtered.sort(function(a, b) {
      if (sort === "2") return laStr(a.roomnumber).localeCompare(laStr(b.roomnumber));
      return laInt(b.audienceSize, 0) - laInt(a.audienceSize, 0);
    });
    var ps = 100, start = (Math.max(1, page) - 1) * ps;
    return filtered.slice(start, start + ps).map(function(it) { return self.toRoom(it); });
  },
  getPlayback: async function(rid) {
    var id = laStr(rid).split("$").pop().split("|")[0];
    // 先试列表缓存
    for (var pg = 1; pg <= 2; pg++) {
      var list = await this.fetchPage(pg);
      for (var i = 0; i < list.length; i++) {
        var rn = laStr(list[i].roomnumber);
        if (rn === id && list[i].videoUrl) {
          var u = laStr(list[i].videoUrl);
          return [{ cdn: "default", qualitys: [{
            roomId: "changliao@" + id, title: "直播", qn: 0, url: u,
            liveCodeType: u.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
            liveType: "30", userAgent: this.ua, headers: { "Referer": "https://show.336769.com/" }
          }]}];
        }
      }
      if (pg === 1 && list.length < 100) break;
    }
    // 调取流接口
    var url = this.roomApi + "?roomnumber=" + encodeURIComponent(id) + "&anchorId=" + encodeURIComponent(id);
    try {
      var d = await laGetJson(url, this.headers());
      if (d && d.code === 100000 && d.data) {
        var u2 = laStr(d.data.videoUrl || d.data.pullUrl || d.data.liveUrl);
        if (u2) {
          return [{ cdn: "default", qualitys: [{
            roomId: "changliao@" + id, title: "直播", qn: 0, url: u2,
            liveCodeType: u2.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
            liveType: "30", userAgent: this.ua, headers: { "Referer": "https://show.336769.com/" }
          }]}];
        }
      }
    } catch (e) {}
    laThrow("NOT_FOUND", "无可用播放流", { roomId: rid });
  },
  search: async function(key) {
    var all = [];
    for (var pg = 1; pg <= 3; pg++) {
      var l = await this.fetchPage(pg);
      if (!l.length) break;
      all = all.concat(l);
    }
    var kw = laStr(key).toLowerCase();
    var self = this, out = [];
    all.forEach(function(item) {
      var nn = laStr(item.nickname).toLowerCase(), loc = laStr(item.loca).toLowerCase(), rn = laStr(item.roomnumber).toLowerCase();
      if (kw && (nn.indexOf(kw) >= 0 || loc.indexOf(kw) >= 0 || rn.indexOf(kw) >= 0)) out.push(self.toRoom(item));
    });
    return out.slice(0, 30);
  }
};

/* ================= 流星 liuxing ================= */
var L2 = {
  listApi: "https://live.660807.com/api/default.ashx?v=1.0.1&Device=0&SourceDevice=-1",
  imgBase: "https://sr.660807.com",
  cdnBase: "http://txpull2.5see.com/live",
  ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  headers: function() {
    return {
      "User-Agent": this.ua, "Accept": "application/json, text/plain, */*",
      "Origin": "https://live.660807.com", "Referer": "https://live.660807.com/"
    };
  },
  classes: [
    { id: "all", title: "全部直播" },
    { id: "hot", title: "热度排行" },
    { id: "dance", title: "舞蹈" },
    { id: "sing", title: "唱歌" },
    { id: "lianmai", title: "连麦" }
  ],
  fixImg: function(p) {
    p = laStr(p);
    if (!p) return "";
    if (p.indexOf("//") === 0) return "https:" + p;
    if (p.charAt(0) === "/") return this.imgBase + p;
    return p.replace("http://sr.660807.com", "https://sr.660807.com");
  },
  fetchAll: async function() {
    var t = await laGetText(this.listApi, this.headers());
    t = t.replace(/^\ufeff/, "");
    var root = {};
    try { root = JSON.parse(t); } catch (e) { return []; }
    var seen = {}, out = [];
    function collect(arr) {
      (arr || []).forEach(function(item) {
        if (!item || typeof item !== "object") return;
        var idx = laStr(item.idx);
        if (!idx || seen[idx]) return;
        if (!item.nn && !item.ri && !item.lp) return;
        seen[idx] = true;
        out.push(item);
      });
    }
    collect(root.list);
    Object.keys(root).forEach(function(k) {
      if (k === "list") return;
      if (Array.isArray(root[k])) {
        var arr = root[k].filter(function(x) { return x && x.idx; });
        arr.sort(function(a, b) { return laInt(b.n, 0) - laInt(a.n, 0); });
        collect(arr);
      }
    });
    return out;
  },
  isLive: function(item) {
    return laInt(item.ls, 0) === 1 && !item.vodurl;
  },
  toRoom: function(item) {
    var idx = laStr(item.idx);
    var pic = this.fixImg(item.lp);
    var n = laInt(item.n, 0);
    var city = laStr(item.mycity);
    var remark = (city && city !== "火星" ? "[" + city + "] " : "") + (n ? "人气" + n : "直播中");
    return {
      userName: laStr(item.nn || item.nickname), roomTitle: remark,
      roomCover: pic, userHeadImg: pic, userId: idx, roomId: "liuxing@" + idx,
      liveState: "1", liveWatchedCount: n, _item: item
    };
  },
  getRooms: async function(tid, page, extend) {
    var all = (await this.fetchAll()).filter(function(it) { return L2.isLive(it); });
    var sort = (extend && extend.sort) || "1";
    var filtered = all.filter(function(item) {
      var nn = laStr(item.nn);
      if (tid === "dance") return /舞/.test(nn);
      if (tid === "sing") return /唱|歌|声/.test(nn);
      if (tid === "lianmai") return laInt(item.lianmaitype, 0) === 1;
      return true;
    });
    filtered.sort(function(a, b) {
      if (tid === "hot") return (laInt(b.starGift,0)*100 + laInt(b.dayStar,0)*50 + laInt(b.n,0)) - (laInt(a.starGift,0)*100 + laInt(a.dayStar,0)*50 + laInt(a.n,0));
      if (sort === "2") return laInt(b.startlivetime, 0) - laInt(a.startlivetime, 0);
      return laInt(b.n, 0) - laInt(a.n, 0);
    });
    var ps = 42, start = (Math.max(1, page) - 1) * ps;
    var self = this;
    return filtered.slice(start, start + ps).map(function(it) { return self.toRoom(it); });
  },
  // 北京时间 MMDDHHMMSS
  fmtTime: function(unixTs) {
    var d = new Date((unixTs + 8 * 3600) * 1000);
    function p2(n) { return (n < 10 ? "0" : "") + n; }
    return p2(d.getUTCMonth() + 1) + p2(d.getUTCDate()) + p2(d.getUTCHours()) + p2(d.getUTCMinutes()) + p2(d.getUTCSeconds());
  },
  getPlayback: async function(aid) {
    var id = laStr(aid).split("$").pop().split("|")[0];
    var all = await this.fetchAll();
    var target = null;
    for (var i = 0; i < all.length; i++) {
      if (laStr(all[i].idx) === id || laStr(all[i].ri) === id) { target = all[i]; break; }
    }
    if (!target) laThrow("NOT_FOUND", "房间不存在", { roomId: aid });
    var idx = laStr(target.idx);
    var ts = laInt(target.startlivetime, 0) || laInt(target.ts, 0) || Math.floor(Date.now() / 1000);
    var offsets = [-5, -4, -6, -3, -7];
    var self = this;
    for (var oi = 0; oi < offsets.length; oi++) {
      var tstr = self.fmtTime(ts + offsets[oi]);
      var url = self.cdnBase + "/" + idx + "/" + idx + tstr + ".flv";
      try {
        var res = await laHttp({
          url: url, method: "GET",
          headers: { "User-Agent": self.ua, "Referer": "https://live.660807.com/", "Range": "bytes=0-3" },
          timeout: 1
        }, "PROBE");
        var body = res && res.body;
        // 检查前3字节是否为 FLV（body 可能是 ArrayBuffer 或字符串）
        var ok = false;
        if (typeof body === "string" && body.substr(0, 3) === "FLV") ok = true;
        if (ok) {
          return [{ cdn: "default", qualitys: [{
            roomId: "liuxing@" + id, title: "直播", qn: 0, url: url,
            liveCodeType: "flv", liveType: "30", userAgent: self.ua,
            headers: { "Referer": "https://live.660807.com/" }
          }]}];
        }
      } catch (e) {}
    }
    // 兜底用偏移-5
    var fb = self.cdnBase + "/" + idx + "/" + idx + self.fmtTime(ts - 5) + ".flv";
    return [{ cdn: "default", qualitys: [{
      roomId: "liuxing@" + id, title: "直播", qn: 0, url: fb,
      liveCodeType: "flv", liveType: "30", userAgent: self.ua,
      headers: { "Referer": "https://live.660807.com/" }
    }]}];
  },
  search: async function(key) {
    var all = await this.fetchAll();
    var kw = laStr(key).toLowerCase();
    var self = this, out = [];
    all.forEach(function(item) {
      if (!self.isLive(item)) return;
      var idx = laStr(item.idx).toLowerCase(), nn = laStr(item.nn).toLowerCase();
      var rn = laStr(item.categoryName || "").toLowerCase(), loc = laStr(item.location || "").toLowerCase();
      if (kw && (idx.indexOf(kw) >= 0 || nn.indexOf(kw) >= 0 || rn.indexOf(kw) >= 0 || loc.indexOf(kw) >= 0)) out.push(self.toRoom(item));
    });
    return out.slice(0, 30);
  }
};

/* ================= Stripchat stripchat (from 1.1.1) ================= */

var SC_API_BASE = "https://stripchat.com/api/front";
var SC_SITE = "https://stripchat.com";
var SC_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var SC_HLS_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0";
var SC_DOPPIOCDN = "doppiocdn.org";

/* ---------- 基础工具 ---------- */

function scThrow(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw new Error(String(message || "unknown error"));
}

function scStr(v) { return v === undefined || v === null ? "" : String(v); }
function scInt(v, fb) { var n = parseInt(v, 10); return isNaN(n) ? fb : n; }

function scRuntimePayload(p) {
  return (p && typeof p === "object") ? p : {};
}

async function scHttpRequest(opts, errCode) {
  try {
    var req = {
      url: opts.url,
      method: opts.method || "GET",
      headers: opts.headers || {},
      timeout: opts.timeout || 20
    };
    if (opts.body !== undefined) req.body = opts.body;
    var res = await Host.http.request({
      authMode: "none",
      followRedirects: false,
      request: req
    });
    return res;
  } catch (e) {
    scThrow(errCode || "NETWORK", "网络请求失败", { url: opts.url });
  }
}

async function scGetText(url, headers) {
  var res = await scHttpRequest({
    url: url,
    method: "GET",
    headers: Object.assign(
      { "User-Agent": SC_UA, "Referer": SC_SITE + "/", "Accept": "application/json, text/plain, */*" },
      headers || {}
    )
  }, "NETWORK");
  var body = res && (res.bodyText !== undefined ? res.bodyText : res.body);
  return scStr(body);
}

async function scGetJson(url, headers) {
  var text = await scGetText(url, headers);
  try { return JSON.parse(text || "{}"); } catch (e) { return {}; }
}

/* ---------- 国旗/状态 ---------- */

function scCountryFlag(code) {
  code = scStr(code).toUpperCase();
  if (!/^[A-Z]{2}$/.test(code)) return "";
  var out = "";
  for (var i = 0; i < 2; i++) {
    out += String.fromCodePoint(code.charCodeAt(i) - 65 + 0x1F1E6);
  }
  return out;
}

function scParseStatus(status, viewers) {
  status = scStr(status).toLowerCase();
  var st;
  if (status === "public") st = "🔴直播中";
  else if (status === "groupshow") st = "🎫门票房";
  else if (status === "ticket") st = "🎫购票房";
  else if (status === "off") st = "⚫已下播";
  else st = "🎫" + status;
  if (viewers) st += " 👤" + viewers + "人";
  return st;
}

function scLiveState(status) {
  status = scStr(status).toLowerCase();
  if (status === "public") return "1";
  if (status === "off") return "0";
  return "2";
}

/* ---------- 数据映射 ---------- */

function scModelToRoom(raw) {
  if (!raw || typeof raw !== "object") return null;
  var username = scStr(raw.username).trim();
  var mid = scStr(raw.id).trim();
  var stream = scStr(raw.streamName).trim();
  if (!username && !mid) return null;

  var status = scStr(raw.status || "off").toLowerCase();
  var viewers = raw.viewersCount || 0;
  var country = scStr(raw.country || "").toUpperCase();
  var flag = scCountryFlag(country);

  var snapTs = raw.snapshotTimestamp || "";
  var pic = "";
  if (mid && snapTs) {
    pic = "https://img." + SC_DOPPIOCDN + "/snapshot/" + mid + "/" + snapTs;
  }

  var roomId = stream && /^\d+$/.test(stream) ? stream : mid;
  if (!roomId) roomId = username;

  return {
    userName: flag ? flag + username : username,
    roomTitle: scParseStatus(status, viewers),
    roomCover: pic,
    userHeadImg: pic,
    userId: mid || username,
    roomId: roomId,
    liveState: scLiveState(status),
    liveWatchedCount: viewers,
    _username: username,
    _status: status
  };
}

/* ---------- 分类定义 (与 Hawk 版一致) ---------- */

var SC_CLASSES = [
  { id: "girls", title: "女主播" },
  { id: "couples", title: "情侣" },
  { id: "men", title: "男主播" },
  { id: "trans", title: "跨性别" }
];

var SC_TAGS = [
  { v: "autoTagNew", n: "新主播" },
  { v: "recommended", n: "推荐" },
  { v: "fuckMachine", n: "炮机" },
  { v: "ageTeen", n: "青年" },
  { v: "autoTagVr", n: "VR" },
  { v: "ethnicityAsian", n: "亚洲人" },
  { v: "tagLanguageChinese", n: "🇨🇳中国" },
  { v: "tagLanguageJapanese", n: "🇯🇵日本" },
  { v: "tagLanguageKorean", n: "🇰🇷韩国" },
  { v: "tagLanguageVietnamese", n: "🇻🇳越南" },
  { v: "tagLanguageUkrainian", n: "🇺🇦乌克兰" },
  { v: "tagLanguageRussianSpeaking", n: "🇷🇺俄罗斯" },
  { v: "tagLanguageUSModels", n: "🇺🇸美国" },
  { v: "tagLanguageColombian", n: "🇨🇴哥伦比亚" },
  { v: "tagLanguageGermanSpeaking", n: "🇩🇪德国" },
  { v: "tagLanguageFrench", n: "🇫🇷法国" },
  { v: "tagLanguageUKModels", n: "🇬🇧英国" },
  { v: "tagLanguageCanadian", n: "🇨🇦加拿大" },
  { v: "tagLanguageMexican", n: "🇲🇽墨西哥" },
  { v: "ethnicityIndian", n: "🇮🇳印度" },
  { v: "tagLanguageVenezuelan", n: "🇻🇪委内瑞拉" },
  { v: "tagLanguageRomanian", n: "🇷🇴罗马尼亚" },
  { v: "tagLanguageAfrican", n: "🌍非洲" },
  { v: "tagLanguageSpanishSpeaking", n: "🇪🇸西班牙" },
  { v: "ethnicityMiddleEastern", n: "🇸🇦🇦🇪阿拉伯" },
  { v: "tagLanguageKenyan", n: "🇰🇪肯尼亚" },
  { v: "tagLanguageSouthAfrican", n: "🇿🇦南非" },
  { v: "tagLanguageBrazilian", n: "🇧🇷巴西" },
  { v: "tagLanguageThai", n: "🇹🇭泰国" },
  { v: "tagLanguageItalian", n: "🇮🇹意大利" },
  { v: "ethnicityWhite", n: "白人" },
  { v: "ethnicityLatino", n: "拉丁" },
  { v: "ethnicityMultiracial", n: "混血" },
  { v: "ethnicityEbony", n: "黑人" },
  { v: "ageYoung", n: "鲜嫩青年22+" },
  { v: "subcultureStudent", n: "学生" },
  { v: "doBlowjob", n: "口交" },
  { v: "doDeepThroat", n: "深喉" },
  { v: "doFootFetish", n: "恋足" },
  { v: "autoTagInteractiveToy", n: "互动玩具" },
  { v: "doMasturbation", n: "自慰" },
  { v: "doAnal", n: "肛交" },
  { v: "doSquirt", n: "潮吹" },
  { v: "doDoggyStyle", n: "狗式" },
  { v: "doCosplay", n: "Cosplay" },
  { v: "doRolePlay", n: "RolePlay" }
];

var SC_TAGS_MEN = [
  { v: "sexGayCouples", n: "情侣" },
  { v: "orientationStraight", n: "直男" }
];

/* ---------- m3u8 解析 ---------- */

function scJoinUrl(base, rel) {
  if (!rel) return "";
  if (/^https?:\/\//i.test(rel)) return rel;
  var b = scStr(base).replace(/\/+$/, "");
  if (rel.charAt(0) === "/") {
    var m = b.match(/^(https?:\/\/[^\/]+)/i);
    return (m ? m[1] : b) + rel;
  }
  return b + "/" + rel;
}

function scExtractShards(variants) {
  var shards = {};
  for (var i = 0; i < variants.length; i++) {
    var m = scStr(variants[i].url).match(/b-hls-(\d+)/i);
    if (m) shards[m[1]] = true;
  }
  var keys = Object.keys(shards);
  if (keys.length === 0) {
    return ["10", "11", "12", "13", "14", "15", "16", "20", "24", "25", "30", "32"];
  }
  return keys;
}

var SC_GROW_SUFFIXES = ["", "_source", "_orig", "_1600p", "_1080p", "_720p", "_480p", "_360p", "_240p"];

async function scIsPlayable(url) {
  try {
    var text = await scGetText(url, {
      "User-Agent": SC_HLS_UA,
      "Referer": SC_SITE + "/"
    });
    if (!text || text.length < 12) return false;
    if (text.indexOf("#EXT-X-MOUFLON-ADVERT") >= 0) return false;
    if (text.indexOf("cpa/v2/") >= 0) return false;
    if (text.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") >= 0) return false;
    return text.indexOf("#EXTINF") >= 0;
  } catch (e) {
    return false;
  }
}

function scParseVariants(text, baseUrl) {
  var lines = scStr(text).split("\n");
  var out = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    var bwM = line.match(/BANDWIDTH=(\d+)/i);
    var nameM = line.match(/NAME="([^"]+)"/i);
    var resM = line.match(/RESOLUTION=(\d+)x(\d+)/i);
    var next = (lines[i + 1] || "").trim();
    if (!next || next.charAt(0) === "#") continue;
    var name = nameM ? nameM[1] : "";
    if (/blurred/i.test(name)) continue;
    out.push({
      bandwidth: bwM ? parseInt(bwM[1], 10) : 0,
      name: name,
      height: resM ? parseInt(resM[2], 10) : 0,
      url: scJoinUrl(baseUrl, next)
    });
  }
  return out;
}

function scVariantScore(v) {
  var h = v.height || 0;
  var n = scStr(v.name).toLowerCase();
  if (n === "source" || n === "orig" || n === "original") h = Math.max(h, 2160);
  return h * 1e9 + (v.bandwidth || 0);
}

function scQualityTitle(v) {
  var n = scStr(v.name).toLowerCase();
  if (n === "source" || n === "orig" || n === "original") return "原画";
  var h = v.height || 0;
  if (h >= 1600) return "原画";
  if (h >= 1000) return "1080p";
  if (h >= 700) return "720p";
  if (h >= 460) return "480p";
  if (h > 0) return h + "p";
  if (/1080/.test(n)) return "1080p";
  if (/720/.test(n)) return "720p";
  if (/480/.test(n)) return "480p";
  return n || "自动";
}

async function scResolveStreamId(username) {
  username = scStr(username).trim().replace(/^\/+|\/+$/g, "").split("/").pop();
  if (/^\d+$/.test(username)) return username;
  try {
    var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(username));
    var id = data && (data.id || (data.model && data.model.id));
    if (id && /^\d+$/.test(String(id))) return String(id);
  } catch (e) {}
  return "";
}

/* ---------- 插件主体 ---------- */



var SC = {
  classes: [
    { id: "girls", title: "女主播" },
    { id: "couples", title: "情侣" },
    { id: "men", title: "男主播" },
    { id: "trans", title: "跨性别" }
  ],
  getCategories: async function() {
    return SC_CLASSES.map(function(c) {
      var tags = c.id === "men" ? SC_TAGS_MEN.concat(SC_TAGS) : SC_TAGS;
      return {
        id: "stripchat_" + c.id, title: c.title, icon: "", biz: "",
        subList: tags.map(function(t) {
          return { id: t.v, parentId: "stripchat_" + c.id, title: t.n, icon: "", biz: t.v };
        })
      };
    });
  },
  getRooms: async function(catId, tag, page, pageSize) {
    var categoryId = laStr(catId).replace(/^stripchat_/, "") || "girls";
    var validIds = ["girls", "couples", "men", "trans"];
    if (validIds.indexOf(categoryId) < 0) categoryId = "girls";
    var ts = Date.now();
    var url = SC_API_BASE + "/v2/models?primaryTag=" + encodeURIComponent(categoryId) +
      "&limit=" + (pageSize + 1) + "&offset=" + ((page - 1) * pageSize) + "&sortBy=stripRanking&_t=" + ts;
    if (tag) url += "&filterGroupTags=" + encodeURIComponent('[["' + tag + '"]]');
    var data = await scGetJson(url);
    var models = [];
    if (data && Array.isArray(data.models)) models = data.models;
    else if (data && Array.isArray(data.blocks)) {
      data.blocks.forEach(function(b) { if (b && Array.isArray(b.models)) models = models.concat(b.models); });
    }
    // 标签过滤无数据时回退到无过滤
    if (models.length === 0 && tag) {
      var url2 = SC_API_BASE + "/v2/models?primaryTag=" + encodeURIComponent(categoryId) +
        "&limit=" + (pageSize + 1) + "&offset=" + ((page - 1) * pageSize) + "&sortBy=stripRanking&_t=" + ts;
      var data2 = await scGetJson(url2);
      if (data2 && Array.isArray(data2.models)) models = data2.models;
      else if (data2 && Array.isArray(data2.blocks)) {
        data2.blocks.forEach(function(b) { if (b && Array.isArray(b.models)) models = models.concat(b.models); });
      }
    }
    var rooms = [];
    for (var i = 0; i < Math.min(models.length, pageSize); i++) {
      var r = scModelToRoom(models[i]);
      if (r) { r.roomId = "stripchat@" + r.roomId; r.userId = "stripchat@" + r.userId; rooms.push(r); }
    }
    return rooms;
  },
};

/* Stripchat getPlayback/search (移植自 1.1.1，liveType 改 30) */
SC.getPlayback = async function(rawId) {
  rawId = laStr(rawId).replace(/^stripchat@/, "").trim();
  if (!rawId) laThrow("INVALID_ARGS", "roomId is required", {});
  var streamId = await scResolveStreamId(rawId);
  if (!streamId) laThrow("NOT_FOUND", "无法解析主播流ID", { roomId: rawId });

  var masters = [
    "https://edge-hls.doppiocdn.org/hls/" + streamId + "/master/" + streamId + "_auto.m3u8",
    "https://edge-hls.doppiocdn.com/hls/" + streamId + "/master/" + streamId + "_auto.m3u8",
    "https://edge-hls.growcdnssedge.com/hls/" + streamId + "/master/" + streamId + "_auto.m3u8"
  ];
  var seen = {};
  for (var mi = 0; mi < masters.length; mi++) {
    var text = await scGetText(masters[mi], { "User-Agent": SC_HLS_UA, "Referer": SC_SITE + "/" });
    var t = scStr(text).trim();
    if (!t || t.indexOf("#EXTM3U") !== 0) continue;
    if (t.indexOf("#EXT-X-MOUFLON-ADVERT") >= 0 && t.indexOf("#EXT-X-STREAM-INF") < 0) continue;
    if (t.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") >= 0) continue;
    var base = masters[mi].substring(0, masters[mi].lastIndexOf("/") + 1);
    var variants = scParseVariants(t, base);
    for (var vi = 0; vi < variants.length; vi++) {
      var v = variants[vi];
      if (!v.url) continue;
      var path = v.url.replace(/^https?:\/\/[^\/]+/i, "");
      var key = v.height + "|" + path;
      if (!seen[key] || scVariantScore(v) > scVariantScore(seen[key])) seen[key] = v;
    }
    if (Object.keys(seen).length > 0) break;
  }
  var sorted = Object.keys(seen).map(function(k) { return seen[k]; })
    .sort(function(a, b) { return scVariantScore(b) - scVariantScore(a); });

  // 分片直连
  var shards = scExtractShards(sorted);
  var shard = shards[0] || "22";
  var qualityDefs = [
    { title: "原画", suffixes: ["_source", "_orig", ""] },
    { title: "1080p", suffixes: ["_1080p"] },
    { title: "720p", suffixes: ["_720p"] },
    { title: "480p", suffixes: ["_480p"] },
    { title: "360p", suffixes: ["_360p"] },
    { title: "240p", suffixes: ["_240p"] }
  ];
  var directUrls = [];
  for (var qi2 = 0; qi2 < qualityDefs.length; qi2++) {
    var qd = qualityDefs[qi2], found = null;
    for (var gi = 0; gi < qd.suffixes.length && !found; gi++) {
      var gurl = "https://media-hls.growcdnssedge.com/b-hls-" + shard + "/" + streamId + "/" + streamId + qd.suffixes[gi] + ".m3u8";
      if (await scIsPlayable(gurl)) found = gurl;
    }
    if (!found) {
      for (var di = 0; di < qd.suffixes.length && !found; di++) {
        var durl = "https://media-hls.doppiocdn.org/b-hls-" + shard + "/" + streamId + "/" + streamId + qd.suffixes[di] + ".m3u8";
        if (await scIsPlayable(durl)) found = durl;
      }
    }
    if (found) directUrls.push({ url: found, title: qd.title });
  }
  var finalVariants = directUrls.length > 0 ? directUrls : sorted;
  var headers = { "Referer": SC_SITE + "/" };
  var qualitys = [], usedTitles = {};
  for (var qi = 0; qi < finalVariants.length; qi++) {
    var vv = finalVariants[qi];
    var title = vv.title || scQualityTitle(vv);
    if (usedTitles[title]) title = title + " " + (vv.height ? vv.height + "p" : vv.bandwidth);
    usedTitles[title] = true;
    qualitys.push({
      roomId: "stripchat@" + streamId, title: title, qn: vv.height || 0, url: vv.url,
      liveCodeType: "m3u8", liveType: "30", userAgent: SC_HLS_UA, headers: headers
    });
  }
  if (qualitys.length === 0) laThrow("NOT_FOUND", "无可用播放流", { roomId: rawId });
  return [{ cdn: "default", qualitys: qualitys }];
};

SC.search = async function(keyword) {
  keyword = laStr(keyword).trim();
  if (!keyword) return [];
  var ts = Date.now(), seen = {}, out = [];
  var tags = ["girls", "couples", "men", "trans"];
  for (var ti = 0; ti < tags.length; ti++) {
    try {
      var url = SC_API_BASE + "/v4/models/search/group/username?query=" +
        encodeURIComponent(keyword) + "&limit=50&primaryTag=" + tags[ti] + "&_t=" + ts;
      var data = await scGetJson(url);
      var models = (data && Array.isArray(data.models)) ? data.models : [];
      for (var i = 0; i < models.length; i++) {
        var r = scModelToRoom(models[i]);
        if (r && !seen[r.roomId]) {
          seen[r.roomId] = true;
          r.roomId = "stripchat@" + r.roomId;
          r.userId = "stripchat@" + r.userId;
          out.push(r);
        }
      }
    } catch (e) {}
  }
  return out;
};

/* ================= 平台注册表 ================= */
var PLATS = ["laixiu", "changliao", "liuxing", "vvxq", "lehai", "panda", "stripchat", "sports1", "sports2"];
var PLAT_NAMES = {
  "laixiu": "🎤来秀直播", "changliao": "💬畅聊直播", "liuxing": "🌠流星直播",
  "vvxq": "🪐VV星球", "lehai": "🎪乐嗨直播", "panda": "🐼PandaTV",
  "stripchat": "🌍Stripchat", "sports1": "⚽体育直播", "sports2": "🕷蜘蛛直播"
};
var PLAT_MOD = {
  "laixiu": LX, "changliao": CL, "liuxing": L2, "vvxq": VV, "lehai": LH,
  "panda": PD, "stripchat": SC, "sports1": SP1, "sports2": SP2
};

function laSplitRoomId(roomId) {
  var s = laStr(roomId);
  var at = s.indexOf("@");
  if (at > 0) {
    var p = s.substring(0, at);
    if (PLATS.indexOf(p) >= 0) return { plat: p, id: s.substring(at + 1) };
  }
  return { plat: "", id: s };
}

/* ================= 主插件 ================= */
globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async getCategories(payload) {
    var out = [];
    // 9个顶级分类，每个平台一个
    out.push({ id: "laixiu", title: "🎤来秀直播", icon: "", biz: "", subList: LX.classes.map(function(c) {
      return { id: "laixiu_" + c.id, parentId: "laixiu", title: c.title, icon: "", biz: c.id };
    })});
    out.push({ id: "changliao", title: "💬畅聊直播", icon: "", biz: "", subList: CL.classes.map(function(c) {
      return { id: "changliao_" + c.id, parentId: "changliao", title: c.title, icon: "", biz: c.id };
    })});
    out.push({ id: "liuxing", title: "🌠流星直播", icon: "", biz: "", subList: L2.classes.map(function(c) {
      return { id: "liuxing_" + c.id, parentId: "liuxing", title: c.title, icon: "", biz: c.id };
    })});
    out.push({ id: "vvxq", title: "🪐VV星球", icon: "", biz: "", subList: VV.classes.map(function(c) {
      return { id: "vvxq_" + c.id, parentId: "vvxq", title: c.title, icon: "", biz: c.id };
    })});
    out.push({ id: "lehai", title: "🎪乐嗨直播", icon: "", biz: "", subList: LH.classes.map(function(c) {
      return { id: "lehai_" + c.id, parentId: "lehai", title: c.title, icon: "", biz: c.id };
    })});
    out.push({ id: "panda", title: "🐼PandaTV", icon: "", biz: "", subList: PD.classes.map(function(c) {
      return { id: "panda_" + c.id, parentId: "panda", title: c.title, icon: "", biz: c.id };
    })});
    // stripchat 用自己的 getCategories（带标签），直接作为顶级分类
    var scCats = await SC.getCategories();
    scCats.forEach(function(c) {
      out.push({
        id: c.id, title: "🌍" + c.title, icon: "", biz: "",
        subList: (c.subList || []).map(function(t) {
          return { id: t.id, parentId: c.id, title: t.title, icon: "", biz: t.biz };
        })
      });
    });
    out.push({ id: "sports1", title: "⚽体育直播", icon: "", biz: "", subList: SP1.classes.map(function(c) {
      return { id: "sports1_" + c.id, parentId: "sports1", title: c.title, icon: "", biz: c.id };
    })});
    out.push({ id: "sports2", title: "🕷蜘蛛直播", icon: "", biz: "", subList: SP2.classes.map(function(c) {
      return { id: "sports2_" + c.id, parentId: "sports2", title: c.title, icon: "", biz: c.id };
    })});
    return out;
  },

  async getRooms(payload) {
    var p = laPayload(payload);
    var rawId = laStr(p.id);
    var parentId = laStr(p.parentId);
    var tag = laStr(p.tag || p.biz);
    var page = 1; // 测试版：强制第一页
    var pageSize = laInt(p.pageSize, 20);
    if (!(pageSize >= 1)) pageSize = 20;
    if (pageSize > 50) pageSize = 50;

    // 解析平台和分类
    var plat = "", catId = "";
    // 格式1: {plat}_{cat} (如 laixiu_all)
    var m1 = rawId.match(/^(laixiu|changliao|liuxing|vvxq|lehai|panda|stripchat|sports1|sports2)_(.+)$/);
    if (m1) { plat = m1[1]; catId = m1[2]; }
    // 格式2: 纯平台ID (如 laixiu)
    else if (PLATS.indexOf(rawId) >= 0) { plat = rawId; }
    // 格式3: stripchat 标签 (parentId 是 stripchat_xxx)
    else {
      var pm = parentId.match(/^stripchat_(.+)$/);
      if (pm) { plat = "stripchat"; catId = pm[1]; tag = rawId; }
      else {
        // 尝试从 parentId 解析平台
        var pm2 = parentId.match(/^(laixiu|changliao|liuxing|vvxq|lehai|panda|sports1|sports2)_/);
        if (pm2) { plat = pm2[1]; catId = rawId; }
      }
    }
    if (!plat || !PLAT_MOD[plat]) laThrow("INVALID_ARGS", "未知平台", { id: rawId });

    var mod = PLAT_MOD[plat];
    var extend = { pageSize: pageSize };
    if (tag && tag !== catId) extend.tag = tag;

    if (plat === "stripchat") {
      return await mod.getRooms(catId || "girls", tag, page, pageSize);
    } else if (plat === "panda") {
      return await mod.getRooms(catId || "pandalive", page, extend);
    } else {
      return await mod.getRooms(catId || mod.classes[0].id, page, extend);
    }
  },

  async getPlayback(payload) {
    var p = laPayload(payload);
    var r = laSplitRoomId(p.roomId || p.userId);
    if (!r.plat || !PLAT_MOD[r.plat]) laThrow("INVALID_ARGS", "无法识别平台", { roomId: p.roomId });
    var mod = PLAT_MOD[r.plat];
    // vvxq 的 roomId 包含 @@m3u8，需要完整传入
    var vid = (r.plat === "vvxq") ? laStr(p.roomId).replace(/^vvxq@/, "") : r.id;
    return await mod.getPlayback(vid);
  },

  async search(payload) {
    var p = laPayload(payload);
    var keyword = laStr(p.keyword).trim();
    if (!keyword) return [];
    var self = this;
    // 并发搜9个平台，单个超时8秒不阻塞
    var tasks = PLATS.map(function(plat) {
      var mod = PLAT_MOD[plat];
      return laWithTimeout(
        (async function() {
          try {
            var rooms = await mod.search(keyword);
            // 标注平台
            rooms.forEach(function(r) {
              r.roomTitle = "[" + PLAT_NAMES[plat] + "] " + (r.roomTitle || "");
            });
            return rooms;
          } catch (e) { return []; }
        })(),
        8000
      ).catch(function() { return []; });
    });
    var results = await Promise.all(tasks);
    var out = [];
    results.forEach(function(arr) { out = out.concat(arr); });
    return out.slice(0, 100);
  },

  async getRoomDetail(payload) {
    var p = laPayload(payload);
    var r = laSplitRoomId(p.roomId || p.userId);
    if (!r.plat) laThrow("INVALID_ARGS", "无法识别平台", {});
    // 复用 getRooms 的第一条，或返回基本信息
    return {
      userName: r.id, roomTitle: PLAT_NAMES[r.plat] || "",
      roomCover: "", userHeadImg: "", userId: r.id,
      roomId: p.roomId, liveState: "1"
    };
  },

  async getLiveState(payload) {
    var p = laPayload(payload);
    var r = laSplitRoomId(p.roomId || p.userId);
    if (r.plat === "stripchat") {
      try {
        var streamId = await scResolveStreamId(r.id);
        return { liveState: streamId ? "1" : "0" };
      } catch (e) { return { liveState: "0" }; }
    }
    return { liveState: "1" };
  },

  async resolveShare(payload) {
    var p = laPayload(payload);
    var text = laStr(p.shareCode || p.shareUrl || p.url).trim();
    if (!text) laThrow("INVALID_ARGS", "shareCode required", {});
    // 尝试匹配 stripchat 分享链接
    var m = text.match(/stripchat\.com\/([A-Za-z0-9_]+)/i);
    if (m) {
      var streamId = await scResolveStreamId(m[1]);
      return {
        userName: m[1], roomTitle: "", roomCover: "", userHeadImg: "",
        userId: streamId, roomId: "stripchat@" + streamId, liveState: "1"
      };
    }
    laThrow("INVALID_ARGS", "无法解析分享链接", {});
  },

  async getDanmaku(payload) {
    return { args: {}, headers: null };
  }
};
