const _sc_loginPlatformId = "stripchat";
const _sc_loginUA = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

const _sc_loginRuntime = {
  credentialSynced: false,
  credentialStatus: {
    state: "missing",
    expireAt: 0,
    userId: "",
    userName: "",
    message: ""
  }
};

function _sc_loginTrim(value) {
  return value === undefined || value === null ? "" : String(value).trim();
}

function _sc_loginBuildCredentialStatus(status) {
  var source = status && typeof status === "object" ? status : {};
  return {
    state: _sc_loginTrim(source.state) || "unknown",
    expireAt: (source.expireAt || 0),
    userId: _sc_loginTrim(source.userId),
    userName: _sc_loginTrim(source.userName),
    message: _sc_loginTrim(source.message)
  };
}

function _sc_loginSetCredentialStatus(status) {
  _sc_loginRuntime.credentialStatus = _sc_loginBuildCredentialStatus(status);
  return _sc_loginGetCredentialStatusSnapshot();
}

function _sc_loginGetCredentialStatusSnapshot() {
  return _sc_loginBuildCredentialStatus(_sc_loginRuntime.credentialStatus);
}

function _sc_loginMarkSynced(message) {
  _sc_loginRuntime.credentialSynced = true;
  return _sc_loginSetCredentialStatus({
    state: "unknown",
    expireAt: 0,
    userId: "",
    userName: "",
    message: _sc_loginTrim(message) || "credential synced; validation pending"
  });
}

function _sc_loginMarkCleared() {
  _sc_loginRuntime.credentialSynced = false;
  return _sc_loginSetCredentialStatus({
    state: "missing",
    expireAt: 0,
    userId: "",
    userName: "",
    message: ""
  });
}

async function _sc_loginRequest(request, authMode) {
  return await Host.http.request({
    platformId: _sc_loginPlatformId,
    authMode: authMode || "none",
    request: request || {}
  });
}

function _sc_loginReadCookieHeader() {
  if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") {
    return _sc_loginTrim(Host.session.getCookieHeader(_sc_loginPlatformId));
  }
  return "";
}

function _sc_loginReadCookieValue(cookieHeader, name) {
  var cookie = _sc_loginTrim(cookieHeader);
  var target = _sc_loginTrim(name);
  if (!cookie || !target) return "";
  var parts = cookie.split(";");
  for (var i = 0; i < parts.length; i++) {
    var segment = _sc_loginTrim(parts[i]);
    if (!segment) continue;
    var index = segment.indexOf("=");
    var key = index >= 0 ? segment.slice(0, index).trim() : segment;
    var value = index >= 0 ? segment.slice(index + 1).trim() : "";
    if (key === target) return value;
  }
  return "";
}

function _sc_loginHasSignalCookie(cookieHeader) {
  // StripChat 登录后的标识 cookie
  var isLogged = _sc_loginReadCookieValue(cookieHeader, "isLogged");
  var sessionId = _sc_loginReadCookieValue(cookieHeader, "stripchat_com_sessionId");
  var moeUuid = _sc_loginReadCookieValue(cookieHeader, "moe_uuid");
  return !!(isLogged === "1" || sessionId || moeUuid);
}

function _sc_loginHasGuestCookie(cookieHeader) {
  return !!(
    _sc_loginReadCookieValue(cookieHeader, "stripchat_com_guestId") ||
    _sc_loginReadCookieValue(cookieHeader, "cf_clearance") ||
    _sc_loginReadCookieValue(cookieHeader, "sCashGuestId")
  );
}

async function _sc_loginValidateCredential() {
  var hasCredential = !!_sc_loginRuntime.credentialSynced;
  var cookieHeader = _sc_loginReadCookieHeader();

  // guest cookie 不算有效登录凭证
  if (!_sc_loginHasSignalCookie(cookieHeader)) {
    if (_sc_loginHasGuestCookie(cookieHeader)) {
      return _sc_loginSetCredentialStatus({
        state: "missing",
        expireAt: 0,
        userId: "",
        userName: "",
        message: "仅有访客 Cookie，请使用账号密码登录"
      });
    }
    return _sc_loginSetCredentialStatus({
      state: "missing",
      expireAt: 0,
      userId: "",
      userName: "",
      message: "stripchat cookie not present in host vault"
    });
  }

  try {
    var resp = await _sc_loginRequest({
      url: "https://go.mavrtracktor.com/api/models?tag=girls/popular&forceClient=1&stripcashR=0&limit=1&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai",
      method: "GET",
      headers: {
        "User-Agent": _sc_loginUA,
        "Referer": "https://zh.stripchat.com/"
      },
      timeout: 15
    }, "platform_cookie");

    var httpCode = resp && (resp.statusCode || resp.status) || 0;
    var bodyText = resp && (resp.bodyText || resp.body || "");
    var obj = null;
    try { obj = JSON.parse(bodyText); } catch (e) { obj = null; }

    if (httpCode < 200 || httpCode >= 300 || !obj) {
      return _sc_loginSetCredentialStatus({
        state: hasCredential ? "expired" : "missing",
        expireAt: 0,
        userId: "",
        userName: "",
        message: "HTTP " + httpCode
      });
    }

    // 通过 API 返回的 isUser 和 userType 判断是否真正登录
    var isUser = obj.isUser === true || obj.isUser === "true";
    var userType = _sc_loginTrim(obj.userType);

    if (!isUser && userType !== "user") {
      return _sc_loginSetCredentialStatus({
        state: "missing",
        expireAt: 0,
        userId: "",
        userName: "",
        message: "仅有访客身份，请使用账号密码登录以获取高画质"
      });
    }

    return _sc_loginSetCredentialStatus({
      state: "valid",
      expireAt: 0,
      userId: userType === "user" ? "stripchat_user" : "",
      userName: userType === "user" ? "StripChat 用户" : userType,
      message: ""
    });
  } catch (e) {
    return _sc_loginSetCredentialStatus({
      state: "error",
      expireAt: 0,
      userId: "",
      userName: "",
      message: String(e.message || e)
    });
  }
}

async function _sc_loginSetCookie() {
  _sc_loginMarkSynced("cookie synced from host");
  return { ok: true };
}

async function _sc_loginClearCookie() {
  _sc_loginMarkCleared();
  return { ok: true };
}

async function _sc_loginSetCredential() {
  var status = _sc_loginMarkSynced("credential synced from host");
  return Object.assign({ ok: true }, status);
}

async function _sc_loginClearCredential() {
  var status = _sc_loginMarkCleared();
  return Object.assign({ ok: true }, status);
}

async function _sc_loginGetCredentialStatus() {
  return _sc_loginGetCredentialStatusSnapshot();
}

globalThis.__lp_plugin_stripchat_login = {
  request: _sc_loginRequest,
  setCookie: _sc_loginSetCookie,
  clearCookie: _sc_loginClearCookie,
  setCredential: _sc_loginSetCredential,
  clearCredential: _sc_loginClearCredential,
  getCredentialStatus: _sc_loginGetCredentialStatus,
  validateCredential: _sc_loginValidateCredential
};
