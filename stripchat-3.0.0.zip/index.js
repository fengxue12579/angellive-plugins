// ============================================================
// StripChat AngelLive Plugin v3.0.0
// 多CDN探测 + 画质阶梯 + 广告过滤 + Cookie认证
// 基于 forward v5.2.1 直播源提取方案优化
// ============================================================

// ============================================================
// SECTION 1: Login Credential Management
// ============================================================

var _sc_loginPlatformId = "stripchat";
var _sc_loginRuntime = { credentialSynced: false, credentialStatus: { state: "missing", expireAt: 0, userId: "", userName: "", message: "" } };

function _sc_loginTrim(v) { return v === undefined || v === null ? "" : String(v).trim(); }

function _sc_loginBuildStatus(s) {
  var src = s && typeof s === "object" ? s : {};
  return {
    state: _sc_loginTrim(src.state) || "unknown",
    expireAt: src.expireAt || 0,
    userId: _sc_loginTrim(src.userId),
    userName: _sc_loginTrim(src.userName),
    message: _sc_loginTrim(src.message)
  };
}

function _sc_loginSetStatus(s) {
  _sc_loginRuntime.credentialStatus = _sc_loginBuildStatus(s);
  return _sc_loginBuildStatus(_sc_loginRuntime.credentialStatus);
}

function _sc_loginMarkSynced(msg) {
  _sc_loginRuntime.credentialSynced = true;
  return _sc_loginSetStatus({ state: "unknown", expireAt: 0, userId: "", userName: "", message: _sc_loginTrim(msg) || "credential synced" });
}

function _sc_loginMarkCleared() {
  _sc_loginRuntime.credentialSynced = false;
  return _sc_loginSetStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "" });
}

function _sc_loginReadCookieHeader() {
  if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") {
    return _sc_loginTrim(Host.session.getCookieHeader(_sc_loginPlatformId));
  }
  return "";
}

function _sc_loginReadCookieValue(hdr, name) {
  var cookie = _sc_loginTrim(hdr), target = _sc_loginTrim(name);
  if (!cookie || !target) return "";
  var parts = cookie.split(";");
  for (var i = 0; i < parts.length; i++) {
    var seg = _sc_loginTrim(parts[i]);
    if (!seg) continue;
    var idx = seg.indexOf("=");
    var key = idx >= 0 ? seg.slice(0, idx).trim() : seg;
    var val = idx >= 0 ? seg.slice(idx + 1).trim() : "";
    if (key === target) return val;
  }
  return "";
}

function _sc_loginIsLoggedIn(hdr) {
  return _sc_loginReadCookieValue(hdr, "isLogged") === "1";
}

function _sc_loginCheckCredential() {
  var hdr = _sc_loginReadCookieHeader();
  if (!hdr) return _sc_loginSetStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未检测到 Cookie" });
  if (!_sc_loginIsLoggedIn(hdr)) return _sc_loginSetStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未登录，请使用账号密码登录" });
  var uuid = _sc_loginReadCookieValue(hdr, "moe_uuid") || _sc_loginReadCookieValue(hdr, "stripchat_com_sessionId") || "stripchat_user";
  return _sc_loginSetStatus({ state: "valid", expireAt: 0, userId: uuid, userName: "StripChat 用户", message: "" });
}

// ============================================================
// SECTION 2: Constants
// ============================================================

var _SC_BASE_URL = "https://go.mavrtracktor.com";
var _SC_PAGE_URL = "https://zh.stripchat.global";
var _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

// CDN 常量
var _SC_DOPPIO_EDGE_ORG = "https://edge-hls.doppiocdn.org";
var _SC_DOPPIO_EDGE_COM = "https://edge-hls.doppiocdn.com";
var _SC_GROW_EDGE = "https://edge-hls.growcdnssedge.com";
var _SC_GROW_MEDIA = "https://media-hls.growcdnssedge.com";

// API 请求头
var _SC_API_HEADERS = {
  "User-Agent": _SC_USER_AGENT,
  "Referer": _SC_PAGE_URL + "/",
  "Accept": "application/json, text/plain, */*",
  "Accept-Language": "zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7"
};

// HLS 请求头（用于 CDN 探测）
var _SC_HLS_HEADERS = {
  "User-Agent": _SC_USER_AGENT,
  "Referer": "https://stripchat.com/",
  "Accept-Language": "en,zh-CN;q=0.9,zh;q=0.8"
};

// 图片代理
var _SC_IMG_PROXY = "https://stripchat-proxy.fengxue556.ccwu.cc";

// growcdn media 画质后缀列表
// 无后缀(bare)通常是真正的源流 H.264 1080p
// _1080p 可能是 AV1 编码，优先 bare/source 以兼容 ffmpeg remux
var _SC_GROW_SUFFIXES = [
  "",          // source / best h264
  "_source",
  "_orig",
  "_1600p",
  "_1080p",
  "_720p",
  "_480p",
  "_360p",
  "_240p",
  "_160p"
];

// 性别标签
var _SC_GENDER_LABELS = {
  "female": "♀️女性",
  "male": "♂️男性",
  "maleFemale": "男女",
  "femaleTranny": "女性变性人",
  "maleTranny": "男性变性人",
  "group": "群体",
  "tranny": "变性人",
  "trannies": "多个变性人"
};

// ============================================================
// SECTION 3: Utility Functions
// ============================================================

function _sc_makeError(code, message, ctx) {
  if (globalThis.Host && typeof Host.makeError === "function") return Host.makeError(code || "UNKNOWN", message || "", ctx || {});
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({ code: String(code || "UNKNOWN"), message: String(message || ""), context: ctx || {} }));
}

function _sc_throw(code, message, ctx) {
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, ctx || {});
  throw _sc_makeError(code, message, ctx);
}

// 图片代理
function _sc_imgProxy(url) {
  if (!_SC_IMG_PROXY || !url) return url;
  var s = url.replace(/^https?:\/\//, ""), si = s.indexOf("/");
  return si < 0 ? url : _SC_IMG_PROXY + "/scimg/" + s;
}

// 画质数值排序：original->9999, 1080p60->1080, 720p->720
function _sc_qn(key) {
  if (key === "original" || key === "source" || key === "orig") return 9999;
  var m = String(key).match(/(\d+)/);
  return m ? parseInt(m[1], 10) : 0;
}

// 构建带 Cookie 的 HLS 请求头
function _sc_hlsHeaders() {
  var h = {};
  for (var k in _SC_HLS_HEADERS) h[k] = _SC_HLS_HEADERS[k];
  var cookie = _sc_loginReadCookieHeader();
  if (cookie) h["Cookie"] = cookie;
  return h;
}

// 构建带 Cookie 的 API 请求头
function _sc_apiHeaders() {
  var h = {};
  for (var k in _SC_API_HEADERS) h[k] = _SC_API_HEADERS[k];
  var cookie = _sc_loginReadCookieHeader();
  if (cookie) h["Cookie"] = cookie;
  return h;
}

// ============================================================
// SECTION 4: HTTP Helpers
// ============================================================

// API 请求（带平台 Cookie 自动注入）
function _sc_httpGet(url, timeout) {
  return Host.http.request({
    platformId: "stripchat",
    authMode: "platform_cookie",
    request: { url: url, method: "GET", headers: _SC_API_HEADERS, timeout: timeout || 20 }
  }).then(function (r) {
    if (r.status >= 500) throw _sc_makeError("NETWORK", "HTTP " + r.status);
    return r;
  });
}

// HLS/CDN 请求（手动注入 Cookie，用于 CDN 探测）
function _sc_hlsGet(url, timeout) {
  return Host.http.request({
    method: "GET",
    url: url,
    headers: _sc_hlsHeaders(),
    timeout: timeout || 15
  }).then(function (r) {
    return r;
  });
}

// ============================================================
// SECTION 5: Categories (expanded from forward v5.2.1)
// ============================================================

function _sc_getCategories() {
  return Promise.resolve([
    {
      id: "girls", parentId: "", title: "女主播", icon: "", biz: "girls", subList: [
        { id: "girls/chinese", parentId: "girls", title: "中国女孩", icon: "", biz: "girls/chinese" },
        { id: "girls/japanese", parentId: "girls", title: "日本女孩", icon: "", biz: "girls/japanese" },
        { id: "girls/korean", parentId: "girls", title: "韩国女孩", icon: "", biz: "girls/korean" },
        { id: "girls/vietnamese", parentId: "girls", title: "越南女孩", icon: "", biz: "girls/vietnamese" },
        { id: "girls/ukrainian", parentId: "girls", title: "乌克兰女孩", icon: "", biz: "girls/ukrainian" },
        { id: "girls/russian", parentId: "girls", title: "俄罗斯女孩", icon: "", biz: "girls/russian" },
        { id: "girls/american", parentId: "girls", title: "美国女孩", icon: "", biz: "girls/american" },
        { id: "girls/colombian", parentId: "girls", title: "哥伦比亚女孩", icon: "", biz: "girls/colombian" },
        { id: "girls/german", parentId: "girls", title: "德国女孩", icon: "", biz: "girls/german" },
        { id: "girls/french", parentId: "girls", title: "法国女孩", icon: "", biz: "girls/french" },
        { id: "girls/thai", parentId: "girls", title: "泰国女孩", icon: "", biz: "girls/thai" },
        { id: "girls/brazilian", parentId: "girls", title: "巴西女孩", icon: "", biz: "girls/brazilian" },
        { id: "girls/asian", parentId: "girls", title: "亚洲人", icon: "", biz: "girls/asian" },
        { id: "girls/latin", parentId: "girls", title: "拉丁人", icon: "", biz: "girls/latin" },
        { id: "girls/ebony", parentId: "girls", title: "黑珍珠", icon: "", biz: "girls/ebony" },
        { id: "girls/teens", parentId: "girls", title: "少女18+", icon: "", biz: "girls/teens" },
        { id: "girls/milfs", parentId: "girls", title: "熟女", icon: "", biz: "girls/milfs" },
        { id: "girls/new", parentId: "girls", title: "最新女主播", icon: "", biz: "girls/new" },
        { id: "girls/popular", parentId: "girls", title: "全部热门", icon: "", biz: "girls/popular" },
        { id: "girls/recommended", parentId: "girls", title: "全部推荐", icon: "", biz: "girls/recommended" },
        { id: "girls", parentId: "girls", title: "全部女主播", icon: "", biz: "girls" }
      ]
    },
    {
      id: "couples", parentId: "", title: "情侣", icon: "", biz: "couples", subList: [
        { id: "couples/chinese", parentId: "couples", title: "中国情侣", icon: "", biz: "couples/chinese" },
        { id: "couples/popular", parentId: "couples", title: "热门情侣", icon: "", biz: "couples/popular" },
        { id: "couples/new", parentId: "couples", title: "最新情侣", icon: "", biz: "couples/new" },
        { id: "couples/group-sex", parentId: "couples", title: "群交直播", icon: "", biz: "couples/group-sex" },
        { id: "couples/lesbians", parentId: "couples", title: "女同", icon: "", biz: "couples/lesbians" },
        { id: "couples", parentId: "couples", title: "全部情侣", icon: "", biz: "couples" }
      ]
    },
    {
      id: "men", parentId: "", title: "男主播", icon: "", biz: "men", subList: [
        { id: "men/popular", parentId: "men", title: "最受欢迎", icon: "", biz: "men/popular" },
        { id: "men/gay-couples", parentId: "men", title: "男同伴侣", icon: "", biz: "men/gay-couples" },
        { id: "men/gays", parentId: "men", title: "男同聊天", icon: "", biz: "men/gays" },
        { id: "men/straight", parentId: "men", title: "直男", icon: "", biz: "men/straight" },
        { id: "men", parentId: "men", title: "全部男主播", icon: "", biz: "men" }
      ]
    },
    {
      id: "trans", parentId: "", title: "变性人", icon: "", biz: "trans", subList: [
        { id: "trans/popular", parentId: "trans", title: "全部变性人", icon: "", biz: "trans/popular" }
      ]
    },
    {
      id: "vr", parentId: "", title: "VR", icon: "", biz: "vr", subList: [
        { id: "girls/vr", parentId: "vr", title: "全部VR", icon: "", biz: "girls/vr" }
      ]
    }
  ]);
}

// ============================================================
// SECTION 6: Room List
// ============================================================

function _sc_fetchModels(cateId, page, searchKeyword) {
  var limit = 200;
  var offset = ((page - 1) * limit);
  var url = _SC_BASE_URL + "/api/models?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1&stripcashR=0&limit=" + limit + "&offset=" + offset
    + "&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";
  if (searchKeyword) {
    url += "&search=" + encodeURIComponent(searchKeyword);
  }
  return _sc_httpGet(url, 20).then(function (r) {
    return JSON.parse(r.bodyText || "{}").models || [];
  });
}

function _sc_modelToRoom(m) {
  var genderLabel = _SC_GENDER_LABELS[m.gender] || "";
  var title = String(m.username || "");
  if (genderLabel) title = title + " " + genderLabel;
  return {
    roomId: String(m.id || ""),
    userId: String(m.id || ""),
    userName: String(m.username || ""),
    roomTitle: title,
    roomCover: _sc_imgProxy(String(m.snapshotUrl || m.previewUrlThumbBig || "")),
    userHeadImg: _sc_imgProxy(String(m.avatarUrl || m.snapshotUrl || "")),
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: String(m.viewersCount || "0")
  };
}

function _sc_getRooms(cateId, page) {
  return _sc_fetchModels(cateId, page).then(function (models) {
    return models.map(_sc_modelToRoom);
  });
}

// ============================================================
// SECTION 7: Multi-CDN Playback Resolution
// (移植自 forward v5.2.1, 适配 AngelLive Host API)
// ============================================================

// --- 7.1: 构建多CDN master m3u8 URL列表 ---
// doppiocdn masters 列出完整画质阶梯(含source/1080p)
// growcdnssedge masters 常仅广告240p/480p，但media可提供完整源流
function _sc_buildMasterUrls(roomId) {
  var id = String(roomId);
  return [
    _SC_DOPPIO_EDGE_ORG + "/hls/" + id + "/master/" + id + "_auto.m3u8",
    _SC_DOPPIO_EDGE_COM + "/hls/" + id + "/master/" + id + "_auto.m3u8",
    _SC_DOPPIO_EDGE_ORG + "/hls/" + id + "/master/" + id + ".m3u8",
    _SC_DOPPIO_EDGE_COM + "/hls/" + id + "/master/" + id + ".m3u8",
    _SC_GROW_EDGE + "/hls/" + id + "/master/" + id + "_auto.m3u8",
    _SC_GROW_EDGE + "/hls/" + id + "/master/" + id + ".m3u8"
  ];
}

// --- 7.2: URL拼接 ---
function _sc_joinUrl(baseUrl, relative) {
  if (!relative) return relative;
  if (relative.indexOf("http://") === 0 || relative.indexOf("https://") === 0) return relative;
  var base = baseUrl.charAt(baseUrl.length - 1) === "/" ? baseUrl : baseUrl + "/";
  return base + relative;
}

// --- 7.3: 解析master m3u8变体流 ---
// 过滤掉 blurred（模糊）变体
function _sc_parseMasterVariants(m3u8Text, baseUrl) {
  var lines = String(m3u8Text || "").split(/\r?\n/);
  var variants = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;

    var bwMatch = line.match(/BANDWIDTH=(\d+)/i);
    var nameMatch = line.match(/NAME="([^"]+)"/i);
    var resMatch = line.match(/RESOLUTION=(\d+)x(\d+)/i);

    // 找下一行作为 URI
    var next = i + 1 < lines.length ? lines[i + 1].trim() : "";
    if (!next || next.charAt(0) === "#") continue;

    var name = nameMatch ? nameMatch[1] : "";
    // 跳过模糊变体
    if (/blurred/i.test(name)) continue;

    var width = resMatch ? parseInt(resMatch[1], 10) : 0;
    var height = resMatch ? parseInt(resMatch[2], 10) : 0;

    variants.push({
      bandwidth: bwMatch ? parseInt(bwMatch[1], 10) : 0,
      name: name,
      width: width,
      height: height,
      url: _sc_joinUrl(baseUrl, next)
    });
  }
  return variants;
}

// --- 7.4: 变体评分 ---
// 分辨率高度优先，source/orig 视为最高画质，其次带宽
function _sc_variantScore(v) {
  var h = Number(v.height) || 0;
  if (!h && v.name) {
    var m = String(v.name).match(/(\d+)\s*p/i);
    if (m) h = parseInt(m[1], 10);
  }
  // source/orig/original 是全分辨率编码
  if (/^(source|orig|original)$/i.test(String(v.name || "").trim())) {
    h = Math.max(h, 2160);
  }
  var bw = Number(v.bandwidth) || 0;
  return h * 1000000000 + bw;
}

// --- 7.5: CDN URL重写 ---
// 将 doppiocdn media URL 重写为 growcdnssedge media URL
// doppiocdn media 常返回广告，growcdnssedge media 是可播放的画质阶梯
function _sc_toGrowMediaUrl(input) {
  if (!input) return null;
  var s = String(input).trim();
  s = s.replace(
    /https?:\/\/media-hls\.doppiocdn\.(?:org|com|net)\/b-hls-\d+\//i,
    _SC_GROW_MEDIA + "/b-hls-10/"
  );
  return s;
}

// --- 7.6: 构建 growcdn media 候选URL列表 ---
// 1. 先按画质阶梯探测（masters常遗漏720p/1080p）
// 2. 再加入master中列出的变体URL（重写至growcdn）
function _sc_buildGrowMediaCandidates(roomId, masterVariants) {
  var id = String(roomId);
  var base = _SC_GROW_MEDIA + "/b-hls-10/" + id + "/" + id;
  var out = [];
  var seen = {};

  function push(u) {
    if (!u || seen[u]) return;
    seen[u] = true;
    out.push(u);
  }

  // 1) 画质阶梯探测
  for (var i = 0; i < _SC_GROW_SUFFIXES.length; i++) {
    push(base + _SC_GROW_SUFFIXES[i] + ".m3u8");
  }

  // 2) master变体重写至growcdn
  var ranked = masterVariants.slice().sort(function (a, b) {
    return _sc_variantScore(b) - _sc_variantScore(a);
  });
  for (var j = 0; j < ranked.length; j++) {
    var grow = _sc_toGrowMediaUrl(ranked[j].url);
    if (grow && /media-hls\.growcdnssedge\.com/i.test(grow)) push(grow);
  }

  return out;
}

// --- 7.7: 验证URL是否为真实直播media playlist ---
// 过滤广告(#EXT-X-MOUFLON-ADVERT / cpa/v2/)、VOD、无媒体段的空playlist
function _sc_isLiveMediaPlaylist(url) {
  return _sc_hlsGet(url, 10).then(function (res) {
    var text = res.bodyText || "";
    if (!text) return false;
    // 广告流
    if (/#EXT-X-MOUFLON-ADVERT|cpa\/v2\//i.test(text)) return false;
    // VOD（录播）
    if (/#EXT-X-PLAYLIST-TYPE:\s*VOD/i.test(text)) return false;
    // 需要有真实媒体段
    if (!/#EXTINF/i.test(text)) return false;
    return true;
  }).catch(function () {
    return false;
  });
}

// --- 7.8: 提取Mouflon pkey ---
function _sc_extractMouflonPkey(m3u8Doc) {
  var pkey = "";
  var needle = "#EXT-X-MOUFLON:PSCH:v2:";
  var idx = 0;
  while (true) {
    idx = m3u8Doc.indexOf(needle, idx);
    if (idx === -1) break;
    var lineEnd = m3u8Doc.indexOf("\n", idx);
    var end = lineEnd === -1 ? m3u8Doc.length : lineEnd;
    var line = m3u8Doc.substring(idx, end).trim();
    var pkeyStart = line.lastIndexOf(":");
    if (pkeyStart !== -1) {
      pkey = line.substring(pkeyStart + 1);
      break;
    }
    idx += needle.length;
  }
  return pkey;
}

// --- 7.9: 构建画质对象 ---
function _sc_buildQuality(roomId, title, qn, url) {
  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: "m3u8",
    liveType: "stripchat",
    userAgent: _SC_USER_AGENT,
    headers: { "Referer": "https://stripchat.com/" },
    playbackHints: { streamFormat: "hlsLive", selectionBehavior: "direct" }
  };
}

// --- 7.10: 从master变体构建画质列表 ---
function _sc_buildQualitysFromVariants(roomId, variants, pkey) {
  var qualitys = [];
  var seen = {};

  // 按评分降序排列
  var ranked = variants.slice().sort(function (a, b) {
    return _sc_variantScore(b) - _sc_variantScore(a);
  });

  for (var i = 0; i < ranked.length; i++) {
    var v = ranked[i];
    var segUrl = v.url;

    // 重写至growcdn（doppiocdn media常含广告）
    var growUrl = _sc_toGrowMediaUrl(segUrl);
    if (growUrl) segUrl = growUrl;

    // 附加pkey
    if (pkey && segUrl.indexOf("pkey=") === -1) {
      var sep = segUrl.indexOf("?") !== -1 ? "&" : "?";
      segUrl += sep + "playlistType=lowLatency&psch=v2&pkey=" + pkey;
    } else if (pkey === "" && segUrl.indexOf("playlistType") === -1) {
      segUrl += (segUrl.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency";
    }

    // 去重
    if (seen[segUrl]) continue;
    seen[segUrl] = true;

    // 构建标签
    var qnVal = 0;
    var label = v.name || "";
    var resLabel = "";
    if (v.width && v.height) {
      resLabel = v.height + "p";
      qnVal = v.height;
    }
    if (label && resLabel) {
      label = label + " (" + resLabel + ")";
    } else if (resLabel) {
      label = resLabel;
    } else if (!label) {
      if (v.bandwidth > 1000000) {
        label = Math.round(v.bandwidth / 1000) + "kbps";
      } else {
        label = "流畅";
      }
    }

    qualitys.push(_sc_buildQuality(roomId, label, qnVal, segUrl));
  }

  return qualitys;
}

// --- 7.11: 核心解析函数 - 多CDN探测 + 画质阶梯 + 广告过滤 ---
//
// 流程:
// 1. 依次请求所有CDN的master m3u8，收集变体信息
// 2. 提取Mouflon pkey
// 3. 构建growcdn media候选URL（画质阶梯 + master变体重写）
// 4. 逐个探测候选URL，找到第一个真实直播流
// 5. 返回所有可用画质（验证通过的media + master变体）
function _sc_resolveMasterStreams(roomId) {
  var id = String(roomId);
  var allVariants = [];
  var pkey = "";
  var masterUrls = _sc_buildMasterUrls(id);

  // Step 1: 依次请求所有CDN master
  var masterChain = Promise.resolve();
  for (var mi = 0; mi < masterUrls.length; mi++) {
    (function (masterUrl) {
      masterChain = masterChain.then(function () {
        return _sc_hlsGet(masterUrl, 10).then(function (res) {
          var m3u8Doc = res.bodyText || "";
          if (!m3u8Doc) return;

          // 提取pkey（只需找到一个即可）
          if (!pkey) {
            pkey = _sc_extractMouflonPkey(m3u8Doc);
          }

          // 解析变体
          var baseUrl = masterUrl.replace(/\/[^/]*$/, "/");
          var variants = _sc_parseMasterVariants(m3u8Doc, baseUrl);
          for (var vi = 0; vi < variants.length; vi++) {
            allVariants.push(variants[vi]);
          }
        }).catch(function () {
          // 尝试下一个CDN
        });
      });
    })(masterUrls[mi]);
  }

  return masterChain.then(function () {
    // Step 2: 从master变体构建画质列表
    var qualitys = [];
    if (allVariants.length > 0) {
      qualitys = _sc_buildQualitysFromVariants(id, allVariants, pkey);
    }

    // Step 3: 探测growcdn media画质阶梯
    var mediaCandidates = _sc_buildGrowMediaCandidates(id, allVariants);

    // 逐个探测候选URL
    var probeChain = Promise.resolve(null);
    for (var ci = 0; ci < mediaCandidates.length; ci++) {
      (function (candidateUrl) {
        probeChain = probeChain.then(function (verifiedResult) {
          if (verifiedResult) return verifiedResult; // 已找到，跳过

          // 附加pkey
          var probeUrl = candidateUrl;
          if (pkey && probeUrl.indexOf("pkey=") === -1) {
            probeUrl += (probeUrl.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency&psch=v2&pkey=" + pkey;
          }

          return _sc_isLiveMediaPlaylist(probeUrl).then(function (isLive) {
            if (isLive) {
              // 从URL提取画质标签
              var suffixMatch = candidateUrl.match(/_([^/]+?)\.m3u8/);
              var suffix = suffixMatch ? suffixMatch[1] : "source";
              return { url: probeUrl, suffix: suffix };
            }
            return null;
          });
        });
      })(mediaCandidates[ci]);
    }

    return probeChain.then(function (verifiedMedia) {
      // Step 4: 如果media探测成功，将其作为最高优先画质插入
      if (verifiedMedia) {
        var mediaLabel = "";
        var mediaQn = 9999;
        switch (verifiedMedia.suffix) {
          case "": case "source": case "orig": case "original":
            mediaLabel = "原画源流"; mediaQn = 9999; break;
          case "1600p": mediaLabel = "1600p"; mediaQn = 1600; break;
          case "1080p": mediaLabel = "1080p"; mediaQn = 1080; break;
          case "720p": mediaLabel = "720p"; mediaQn = 720; break;
          case "480p": mediaLabel = "480p"; mediaQn = 480; break;
          case "360p": mediaLabel = "360p"; mediaQn = 360; break;
          case "240p": mediaLabel = "240p"; mediaQn = 240; break;
          case "160p": mediaLabel = "160p"; mediaQn = 160; break;
          default: mediaLabel = verifiedMedia.suffix; mediaQn = _sc_qn(verifiedMedia.suffix);
        }

        // 检查是否已有相同URL
        var alreadyExists = false;
        for (var si = 0; si < qualitys.length; si++) {
          if (qualitys[si].url === verifiedMedia.url) {
            alreadyExists = true;
            break;
          }
        }

        if (!alreadyExists) {
          qualitys.unshift(_sc_buildQuality(id, mediaLabel + " (已验证)", mediaQn, verifiedMedia.url));
        }
      }

      return qualitys;
    });
  });
}

// --- 7.12: getPlayback 主函数 ---
function _sc_getPlayback(roomId) {
  var id = String(roomId);

  // Step 1: 多CDN探测 + 画质阶梯 + 广告过滤
  return _sc_resolveMasterStreams(id).then(function (qualitys) {
    if (qualitys.length > 0) {
      return [{ cdn: "multi-cdn", displayName: "多CDN探测", qualitys: qualitys }];
    }

    // Step 2: fallback - 通过API获取流地址
    console.log("[StripChat] master探测失败，尝试API fallback");
    return _sc_getPlaybackApiFallback(id);
  }).catch(function (e) {
    console.error("[StripChat] 多CDN探测异常:", e.message || e);
    return _sc_getPlaybackApiFallback(id);
  });
}

// --- 7.13: API fallback ---
function _sc_getPlaybackApiFallback(roomId) {
  var id = String(roomId);
  var apiUrl = _SC_BASE_URL + "/api/models?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  return _sc_httpGet(apiUrl, 20).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === id) { found = models[i]; break; }
    }

    var qualitys = [];
    if (found && found.stream && found.stream.urls) {
      var streamUrls = found.stream.urls;
      var qualityNames = {
        "original": "原画", "1080p": "1080p", "720p": "720p",
        "480p": "480p", "240p": "240p"
      };
      var added = {};
      for (var quality in streamUrls) {
        var url = streamUrls[quality];
        if (!url || added[url]) continue;
        added[url] = true;
        // 重写至growcdn
        var growUrl = _sc_toGrowMediaUrl(url);
        if (growUrl) url = growUrl;
        if (url.indexOf("playlistType") === -1) {
          url += (url.indexOf("?") !== -1 ? "&" : "?") + "playlistType=lowLatency";
        }
        qualitys.push(_sc_buildQuality(id, qualityNames[quality] || quality, _sc_qn(quality), url));
      }
    }

    // Step 3: 最终fallback - 直接构建growcdn URL
    if (qualitys.length === 0) {
      console.log("[StripChat] 所有探测失败，使用默认growcdn URL");
      var cdnBase = _SC_GROW_EDGE + "/hls/" + id + "/master/";
      qualitys.push(_sc_buildQuality(id, "自动画质", 0, cdnBase + id + "_auto.m3u8?playlistType=lowLatency"));
      qualitys.push(_sc_buildQuality(id, "原画", 9999, cdnBase + id + ".m3u8?playlistType=lowLatency"));
    }

    return [{ cdn: "api-fallback", displayName: "API回退", qualitys: qualitys }];
  }).catch(function (e) {
    // 网络异常时的最终兜底
    var cdnBase = _SC_GROW_EDGE + "/hls/" + id + "/master/";
    var qualitys = [
      _sc_buildQuality(id, "自动画质", 0, cdnBase + id + "_auto.m3u8?playlistType=lowLatency"),
      _sc_buildQuality(id, "原画", 9999, cdnBase + id + ".m3u8?playlistType=lowLatency")
    ];
    return [{ cdn: "default", displayName: "默认线路", qualitys: qualitys }];
  });
}

// --- 7.14: refreshPlayback ---
function _sc_refreshPlayback(roomId, cdnId) {
  // 重新走多CDN探测，返回最高画质
  return _sc_resolveMasterStreams(String(roomId)).then(function (qualitys) {
    if (qualitys.length > 0) {
      return qualitys[0]; // 返回最高画质
    }
    // fallback
    var id = String(roomId);
    var cdnBase = _SC_GROW_EDGE + "/hls/" + id + "/master/";
    return _sc_buildQuality(id, "自动画质", 0, cdnBase + id + "_auto.m3u8?playlistType=lowLatency");
  }).catch(function () {
    var id = String(roomId);
    var cdnBase = _SC_GROW_EDGE + "/hls/" + id + "/master/";
    return _sc_buildQuality(id, "自动画质", 0, cdnBase + id + "_auto.m3u8?playlistType=lowLatency");
  });
}

// ============================================================
// SECTION 8: Search
// ============================================================

function _sc_search(keyword) {
  return _sc_fetchModels("girls", 1, keyword).then(function (models) {
    return models.map(_sc_modelToRoom);
  });
}

// ============================================================
// SECTION 9: Room Detail
// ============================================================

function _sc_getRoomDetail(roomId) {
  // 先尝试搜索API查找
  return _sc_fetchModels("girls/popular", 1).then(function (models) {
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) return _sc_modelToRoom(models[i]);
    }
    // 在 popular 列表中未找到，尝试搜索
    return _sc_fetchModels("girls", 1, String(roomId)).then(function (searchModels) {
      for (var j = 0; j < searchModels.length; j++) {
        if (String(searchModels[j].id) === String(roomId)) return _sc_modelToRoom(searchModels[j]);
      }
      // 仍未找到，返回基本信息
      return {
        roomId: String(roomId),
        userId: String(roomId),
        userName: String(roomId),
        roomTitle: String(roomId),
        roomCover: "",
        userHeadImg: "",
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: "0"
      };
    });
  });
}

// ============================================================
// SECTION 10: Live State
// ============================================================

function _sc_getLiveState(roomId) {
  // Stripchat API 不直接提供状态查询，通过探测 master m3u8 是否可用来判断
  var id = String(roomId);
  var masterUrl = _SC_GROW_EDGE + "/hls/" + id + "/master/" + id + "_auto.m3u8";

  return _sc_hlsGet(masterUrl, 8).then(function (res) {
    var text = res.bodyText || "";
    if (!text) return { liveState: "0" };
    // 检查是否为有效直播流（非广告/非空）
    if (/#EXT-X-MOUFLON-ADVERT|cpa\/v2\//i.test(text) && !/#EXT-X-STREAM-INF/i.test(text)) {
      return { liveState: "0" };
    }
    return { liveState: "1" };
  }).catch(function () {
    return { liveState: "0" };
  });
}

// ============================================================
// SECTION 11: Share Resolve
// ============================================================

function _sc_resolveShare(shareCode) {
  var input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  var username = "";
  // 匹配 stripchat.global/xxx 或 stripchat.com/xxx
  var m = input.match(/stripchat\.(?:global|com)\/([\w]+)/);
  if (m && m[1]) {
    username = m[1];
  } else if (/^[a-zA-Z0-9_]+$/.test(input)) {
    // 纯用户名
    username = input;
  }

  if (!username) {
    _sc_throw("NOT_FOUND", "cannot extract username", { shareCode: input });
  }

  // 尝试通过API查找roomId
  return _sc_fetchModels("girls", 1, username).then(function (models) {
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].username) === username) {
        return _sc_modelToRoom(models[i]);
      }
    }
    // 未找到，返回基本信息
    return {
      roomId: username,
      userId: username,
      userName: username,
      roomTitle: username,
      roomCover: "",
      userHeadImg: "",
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: "0"
    };
  }).catch(function () {
    return {
      roomId: username,
      userId: username,
      userName: username,
      roomTitle: username,
      roomCover: "",
      userHeadImg: "",
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: "0"
    };
  });
}

// ============================================================
// SECTION 12: Plugin Export
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  // 分类列表
  getCategories: function () {
    return _sc_getCategories();
  },

  // 房间列表
  getRooms: function (payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _sc_getRooms(id, page);
  },

  // 播放地址（多CDN探测 + 画质阶梯 + 广告过滤）
  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getPlayback(roomId);
  },

  // 刷新播放地址
  refreshPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    var cdn = String((payload && payload.cdn) || "");
    var quality = (payload && payload.quality) || {};
    var ctx = quality.requestContext || {};
    var cdnId = String(ctx.cdn || cdn || "multi-cdn");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_refreshPlayback(roomId, cdnId);
  },

  // 房间详情
  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getRoomDetail(roomId);
  },

  // 直播状态
  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getLiveState(roomId);
  },

  // 搜索
  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _sc_search(keyword);
  },

  // 分享解析
  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _sc_resolveShare(shareCode);
  },

  // 凭证管理
  clearCredential: function () {
    return Promise.resolve(_sc_loginMarkCleared());
  },

  setCredential: function () {
    return Promise.resolve(Object.assign({ ok: true }, _sc_loginMarkSynced("credential synced")));
  },

  getCredentialStatus: function () {
    return Promise.resolve(_sc_loginCheckCredential());
  },

  validateCredential: function () {
    return Promise.resolve(_sc_loginCheckCredential());
  }
};
