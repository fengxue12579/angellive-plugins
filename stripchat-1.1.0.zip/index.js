// ============================================================
// Stripchat AngelLive (LiveParse) Plugin v1.1.0
// 基于 Python 高画质版 + 通用弹幕版重构
// Cloudflare Worker 代理: 多域名轮询 / Mouflon 解密 / 弹幕 SSE
// v1.1.0: 新增细分分类，按热度（观看人数）从高到低排序
// ============================================================

// ==================== Config ====================

var _SC_PLATFORM  = "stripchat";
var _SC_UA        = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:153.0) Gecko/20100101 Firefox/153.0";
var _SC_DOPPIO    = "doppiocdn.org";

var _SC_PROXY_BASE = "https://stripchat.fengxue556.ccwu.cc";

// ==================== Utility ====================

function _sc_trim(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function _sc_str(v, def) { return v != null ? String(v) : (def || ""); }
function _sc_num(v, def) { var n = Number(v); return isNaN(n) ? (def || 0) : n; }

function _sc_throw(code, message, ctx) {
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, ctx || {});
  throw new Error("LP_PLUGIN_ERROR:" + JSON.stringify({ code: code, message: message, context: ctx || {} }));
}

function _sc_flag(code) {
  code = _sc_trim(code).toUpperCase();
  if (code.length === 2 && /^[A-Z]{2}$/.test(code)) {
    return String.fromCharCode(code.charCodeAt(0) - 65 + 0x1F1E6) +
           String.fromCharCode(code.charCodeAt(1) - 65 + 0x1F1E6);
  }
  return "";
}

// ==================== HTTP ====================

function _sc_http(path) {
  var url = _SC_PROXY_BASE + path;
  return Host.http.request({
    platformId: _SC_PLATFORM,
    authMode: "none",
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_UA,
      "Accept": "application/json, text/plain, */*"
    },
    timeout: 15
  });
}

// ==================== Data Helpers ====================

function _sc_normalizeRoom(v) {
  var username = _sc_str(v.username || "");
  if (!username) return null;
  var isLive = !!v.isLive;
  var status = _sc_str(v.status, "off");
  var viewers = _sc_num(v.viewersCount || 0, 0);
  var uid = _sc_str(v.id || "");
  var country = _sc_str(v.country || "");
  var flag = _sc_flag(country);
  var snapshotTs = _sc_str(v.snapshotTimestamp || "");
  var cover = uid && snapshotTs
    ? "https://img." + _SC_DOPPIO + "/snapshot/" + uid + "/" + snapshotTs
    : (_sc_str(v.avatarUrl || ""));

  return {
    roomId:            username,
    userId:            username,
    userName:          flag + username,
    roomTitle:         _sc_str(v.topic || v.status || "Stripchat"),
    roomCover:         cover,
    userHeadImg:       _sc_str(v.avatarUrl || cover),
    liveType:          "stripchat",
    liveState:         isLive ? (status === "public" ? "public" : status) : "off",
    liveWatchedCount:  String(viewers)
  };
}

// ==================== Categories ====================
// 细分标签：主分类 + 热门标签组合

var _SC_SUB_TAGS = {
  girls: [
    { id: "asian",     title: "亚洲" },
    { id: "latina",    title: "拉丁" },
    { id: "ebony",     title: "黑人" },
    { id: "mature",    title: "熟女" },
    { id: "teen",      title: "少女" },
    { id: "bigtits",   title: "巨乳" },
    { id: "bigass",    title: "肥臀" },
    { id: "squirt",    title: "潮吹" },
    { id: "anal",      title: "后庭" },
    { id: "feet",      title: "美足" },
    { id: "mistress",  title: "女王" },
    { id: "cosplay",   title: "COS" },
    { id: "hairy",     title: "毛茸茸" },
    { id: "pregnant",  title: "孕妇" },
    { id: "shaved",    title: "白虎" },
    { id: "solo",      title: "单人" },
    { id: "new",       title: "新人" },
    { id: "hd",        title: "高清" }
  ],
  couples: [
    { id: "asian",     title: "亚洲情侣" },
    { id: "latina",    title: "拉丁情侣" },
    { id: "ebony",     title: "黑人情侣" },
    { id: "mature",    title: "熟女情侣" },
    { id: "teen",      title: "年轻情侣" },
    { id: "bigtits",   title: "巨乳情侣" },
    { id: "bigass",    title: "肥臀情侣" },
    { id: "anal",      title: "后庭情侣" },
    { id: "group",     title: "群交" },
    { id: "squirt",    title: "潮吹情侣" },
    { id: "cosplay",   title: "COS情侣" },
    { id: "hd",        title: "高清情侣" }
  ],
  men: [
    { id: "asian",     title: "亚洲男" },
    { id: "latino",    title: "拉丁男" },
    { id: "ebony",     title: "黑人男" },
    { id: "mature",    title: "熟男" },
    { id: "twink",     title: "正太" },
    { id: "muscle",    title: "肌肉" },
    { id: "bigdick",   title: "巨根" },
    { id: "hairy",     title: "毛茸茸" },
    { id: "bear",      title: "熊" },
    { id: "hd",        title: "高清男" }
  ],
  trans: [
    { id: "asian",     title: "亚洲TS" },
    { id: "latina",    title: "拉丁TS" },
    { id: "ebony",     title: "黑人TS" },
    { id: "bigtits",   title: "巨乳TS" },
    { id: "bigdick",   title: "巨根TS" },
    { id: "mature",    title: "熟女TS" },
    { id: "teen",      title: "年轻TS" },
    { id: "cosplay",   title: "COS TS" },
    { id: "hd",        title: "高清TS" }
  ]
};

function _sc_getCategories() {
  var cats = [
    { id: "girls",   parentId: "", title: "女主播",   icon: "", biz: "girls" },
    { id: "couples", parentId: "", title: "情侣",     icon: "", biz: "couples" },
    { id: "men",     parentId: "", title: "男主播",   icon: "", biz: "men" },
    { id: "trans",   parentId: "", title: "跨性别",   icon: "", biz: "trans" }
  ];

  for (var i = 0; i < cats.length; i++) {
    var parent = cats[i];
    var sub = [];
    sub.push({ id: parent.id + ":all", parentId: parent.id, title: "全部" + parent.title, icon: "", biz: parent.id + ":all" });
    var tags = _SC_SUB_TAGS[parent.id] || [];
    for (var j = 0; j < tags.length; j++) {
      var t = tags[j];
      sub.push({
        id: parent.id + ":" + t.id,
        parentId: parent.id,
        title: t.title,
        icon: "",
        biz: parent.id + ":" + t.id
      });
    }
    parent.subList = sub;
  }

  return Promise.resolve(cats);
}

// ==================== Rooms ====================

function _sc_parseCate(cateId) {
  // 格式: primaryTag:tag  或  primaryTag:all  或  primaryTag
  var parts = String(cateId || "").split(":");
  var primaryTag = parts[0] || "girls";
  var tag = parts.length > 1 ? parts[1] : "all";
  if (tag === "all") tag = "";
  return { primaryTag: primaryTag, tag: tag };
}

function _sc_getRooms(cateId, page) {
  page = page || 1;
  var limit = 60;
  var offset = limit * (page - 1);
  var parsed = _sc_parseCate(cateId);

  var path = "/api/front/models?improveTs=false&removeShows=false&limit=" + limit +
             "&offset=" + offset + "&primaryTag=" + encodeURIComponent(parsed.primaryTag) +
             "&sortBy=stripRanking&rcmGrp=A&rbCnGr=true&prxCnGr=false&nic=false";
  if (parsed.tag) {
    path += "&tag=" + encodeURIComponent(parsed.tag);
  }

  return _sc_http("/sc" + path).then(function (resp) {
    if (resp.status >= 500) _sc_throw("NETWORK", "HTTP " + resp.status, {});
    var data = JSON.parse(resp.bodyText || "{}");
    var models = data.models || [];

    // 按观看人数（热度）从高到低排序
    models.sort(function (a, b) {
      var va = Number(a.viewersCount || 0);
      var vb = Number(b.viewersCount || 0);
      return vb - va;
    });

    var rooms = [];
    for (var i = 0; i < models.length; i++) {
      var r = _sc_normalizeRoom(models[i]);
      if (r) rooms.push(r);
    }
    return rooms;
  });
}

// ==================== Room Detail ====================

function _sc_getRoomDetail(roomId) {
  var path = "/api/front/v2/models/username/" + encodeURIComponent(roomId) + "/cam";
  return _sc_http("/sc" + path).then(function (resp) {
    if (resp.status >= 500) _sc_throw("NETWORK", "HTTP " + resp.status, {});
    var data = JSON.parse(resp.bodyText || "{}");
    if (!data.cam) _sc_throw("NOT_FOUND", "房间不存在", { roomId: roomId });
    var cam = data.cam;
    var user = (data.user && data.user.user) ? data.user.user : {};
    var uid = _sc_str(user.id || "");
    var isLive = !!user.isLive;
    var country = _sc_str(user.country || "");
    var flag = _sc_flag(country);
    var username = _sc_str(user.username || roomId);
    var status = _sc_str(user.status, "off");

    return {
      roomId:           username,
      userId:           username,
      userName:         flag + username,
      roomTitle:        _sc_str(cam.topic || "Stripchat"),
      roomCover:        _sc_str(user.avatarUrl || ""),
      userHeadImg:      _sc_str(user.avatarUrl || ""),
      liveType:         "stripchat",
      liveState:        isLive ? (status === "public" ? "public" : status) : "off",
      liveWatchedCount: String(_sc_num(cam.viewersCount || 0, 0))
    };
  });
}

// ==================== Playback ====================

function _sc_getPlayback(roomId) {
  // 先取房间详情拿 uid
  var detailPath = "/api/front/v2/models/username/" + encodeURIComponent(roomId) + "/cam";
  return _sc_http("/sc" + detailPath).then(function (resp) {
    var data = JSON.parse(resp.bodyText || "{}");
    if (!data.cam) _sc_throw("NOT_FOUND", "房间不存在", { roomId: roomId });
    var user = (data.user && data.user.user) ? data.user.user : {};
    var uid = _sc_str(user.id || "");
    var isLive = !!user.isLive;
    if (!isLive) _sc_throw("OFFLINE", "主播已下播", { roomId: roomId });
    if (!uid) _sc_throw("NO_STREAM", "未获取到主播ID", { roomId: roomId });

    // 三条线路
    var lines = [
      {
        cdn: "doppiocdn",
        displayName: "飞鱼高清",
        m3u8Url: _SC_PROXY_BASE + "/m3u8/doppio/" + uid + "/master.m3u8"
      },
      {
        cdn: "growcdn",
        displayName: "备用线路二",
        m3u8Url: _SC_PROXY_BASE + "/m3u8/grow/" + uid + "/master.m3u8"
      },
      {
        cdn: "sacfedge",
        displayName: "备用线路三",
        m3u8Url: _SC_PROXY_BASE + "/m3u8/sacf/" + uid + "/master.m3u8"
      }
    ];

    var qualitys = [];
    for (var i = 0; i < lines.length; i++) {
      var line = lines[i];
      qualitys.push({
        roomId:       uid,
        title:        line.displayName,
        qn:           10000 - i * 1000,
        url:          line.m3u8Url,
        liveCodeType: "hls",
        liveType:     "stripchat",
        userAgent:    _SC_UA,
        headers:      { "Referer": "https://stripchat.com/" }
      });
    }

    return [{
      cdn: "default",
      displayName: "Stripchat",
      qualitys: qualitys
    }];
  });
}

// ==================== Search ====================

function _sc_search(keyword, page) {
  // 搜索所有分类
  var tags = ["girls", "couples", "men", "trans"];
  var promises = [];
  for (var i = 0; i < tags.length; i++) {
    var path = "/api/front/v4/models/search/group/username?query=" +
               encodeURIComponent(keyword) + "&limit=900&primaryTag=" + tags[i];
    promises.push(_sc_http("/sc" + path));
  }

  return Promise.all(promises).then(function (resps) {
    var seen = {};
    var rooms = [];
    for (var i = 0; i < resps.length; i++) {
      try {
        var data = JSON.parse(resps[i].bodyText || "{}");
        var models = data.models || [];
        for (var j = 0; j < models.length; j++) {
          var m = models[j];
          var uname = _sc_str(m.username || "");
          if (!uname || seen[uname]) continue;
          if (!m.isLive) continue;
          seen[uname] = true;
          var r = _sc_normalizeRoom(m);
          if (r) rooms.push(r);
        }
      } catch (e) { /* ignore */ }
    }
    return rooms;
  });
}

// ==================== Live State ====================

function _sc_getLiveState(roomId) {
  var path = "/api/front/v2/models/username/" + encodeURIComponent(roomId) + "/cam";
  return _sc_http("/sc" + path).then(function (resp) {
    try {
      var data = JSON.parse(resp.bodyText || "{}");
      var user = (data.user && data.user.user) ? data.user.user : {};
      var isLive = !!user.isLive;
      var status = _sc_str(user.status, "off");
      return { liveState: isLive ? (status === "public" ? "public" : status) : "off" };
    } catch (e) {
      return { liveState: "0" };
    }
  }).catch(function () {
    return { liveState: "0" };
  });
}

// ==================== Share Resolve ====================

function _sc_resolveShare(shareCode) {
  var input = _sc_trim(shareCode);
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", {});

  var roomId = "";
  var m = input.match(/stripchat\.(com|global|org|com)\/([a-zA-Z0-9_-]+)/i);
  if (m && m[2]) {
    roomId = m[2];
  } else if (/^[a-zA-Z0-9_-]{3,}$/.test(input)) {
    roomId = input;
  }
  if (!roomId) {
    _sc_throw("NOT_FOUND", "无法解析主播ID", { shareCode: input });
  }
  return _sc_getRoomDetail(roomId);
}

// ==================== Danmaku ====================

function _sc_getDanmaku(payload) {
  var roomId = String(payload && payload.roomId ? payload.roomId : "");
  if (!roomId) return { args: {}, headers: null };

  // 弹幕走 Worker SSE 端点
  // 先拿 uid
  return _sc_http("/sc/api/front/v2/models/username/" + encodeURIComponent(roomId) + "/cam")
    .then(function (resp) {
      var uid = "";
      try {
        var data = JSON.parse(resp.bodyText || "{}");
        var user = (data.user && data.user.user) ? data.user.user : {};
        uid = _sc_str(user.id || "");
      } catch (e) {}

      var sseUrl = _SC_PROXY_BASE + "/danmaku/" + (uid || roomId);
      return {
        args: {
          roomId: uid || roomId,
          url: sseUrl
        },
        headers: {
          "User-Agent": _SC_UA,
          "Accept": "text/event-stream"
        }
      };
    })
    .catch(function () {
      return { args: { roomId: roomId }, headers: null };
    });
}

// ==================== Auth Stubs ====================

function _sc_setCredential(payload) { return Promise.resolve(true); }
function _sc_clearCredential(payload) { return Promise.resolve(true); }
function _sc_getCredentialStatus(payload) {
  return Promise.resolve({ isLoggedIn: false, username: "" });
}

// ============================================================
// Plugin Export
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function () {
    return _sc_getCategories();
  },

  getRooms: function (payload) {
    var id = String(payload && payload.id ? payload.id : "girls");
    var page = payload && payload.page ? Number(payload.page) : 1;
    return _sc_getRooms(id, page);
  },

  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", {});
    return _sc_getPlayback(roomId);
  },

  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", {});
    var page = payload && payload.page ? Number(payload.page) : 1;
    return _sc_search(keyword, page);
  },

  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", {});
    return _sc_getRoomDetail(roomId);
  },

  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", {});
    return _sc_getLiveState(roomId);
  },

  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", {});
    return _sc_resolveShare(shareCode);
  },

  getDanmaku: function (payload) {
    return _sc_getDanmaku(payload);
  },

  setCredential: function (payload) {
    return _sc_setCredential(payload);
  },

  clearCredential: function (payload) {
    return _sc_clearCredential(payload);
  },

  getCredentialStatus: function (payload) {
    return _sc_getCredentialStatus(payload);
  }
};