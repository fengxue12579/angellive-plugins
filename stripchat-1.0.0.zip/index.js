// ============================================================
// StripChat AngelLive Plugin v1.0.0
// 基于 OK 影视 StripChat 源转换
// ============================================================

const _SC_BASE_URL = "https://go.mavrtracktor.com";
const _SC_PAGE_URL = "https://zh.stripchat.global";
const _SC_EDGE_CDN = "https://edge-hls.growcdnssedge.com";
const _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

// ============================================================
// 工具函数
// ============================================================

function _sc_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  throw new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

function _sc_genderLabel(gender) {
  const map = {
    "females": "♀️女性",
    "maleFemale": "男女",
    "males": "♂️男性",
    "femaleTranny": "女性变性人",
    "maleTranny": "男性变性人",
    "female": "♀️女性",
    "group": "群体",
    "male": "♂️男性",
    "tranny": "变性人",
    "trannies": "多个变性人"
  };
  return map[gender] || gender || "";
}

// ============================================================
// 分类定义
// ============================================================

function _sc_getCategoryDefinitions() {
  return [
    {
      id: "girls/chinese",
      parentId: "",
      title: "女主播",
      icon: "",
      biz: "girls/chinese",
      subList: [
        { id: "girls/chinese", parentId: "girls/chinese", title: "🇨🇳中国女孩", icon: "", biz: "girls/chinese" },
        { id: "girls/japanese", parentId: "girls/chinese", title: "🇯🇵日本女孩", icon: "", biz: "girls/japanese" },
        { id: "girls/korean", parentId: "girls/chinese", title: "🇰🇷韩国女孩", icon: "", biz: "girls/korean" },
        { id: "girls/vietnamese", parentId: "girls/chinese", title: "🇻🇳越南女孩", icon: "", biz: "girls/vietnamese" },
        { id: "girls/ukrainian", parentId: "girls/chinese", title: "🇺🇦乌克兰女孩", icon: "", biz: "girls/ukrainian" },
        { id: "girls/russian", parentId: "girls/chinese", title: "🇷🇺俄罗斯女孩", icon: "", biz: "girls/russian" },
        { id: "girls/american", parentId: "girls/chinese", title: "🇺🇸美国女孩", icon: "", biz: "girls/american" },
        { id: "girls/colombian", parentId: "girls/chinese", title: "🇨🇴哥伦比亚女孩", icon: "", biz: "girls/colombian" },
        { id: "girls/german", parentId: "girls/chinese", title: "🇩🇪德国女孩", icon: "", biz: "girls/german" },
        { id: "girls/french", parentId: "girls/chinese", title: "🇫🇷法国女孩", icon: "", biz: "girls/french" },
        { id: "girls/uk-models", parentId: "girls/chinese", title: "🇬🇧英国女孩", icon: "", biz: "girls/uk-models" },
        { id: "girls/canadian", parentId: "girls/chinese", title: "🇨🇦加拿大女孩", icon: "", biz: "girls/canadian" },
        { id: "girls/mexican", parentId: "girls/chinese", title: "🇲🇽墨西哥女孩", icon: "", biz: "girls/mexican" },
        { id: "girls/indian", parentId: "girls/chinese", title: "🇮🇳印度女孩", icon: "", biz: "girls/indian" },
        { id: "girls/venezuelan", parentId: "girls/chinese", title: "🇻🇪委内瑞拉女孩", icon: "", biz: "girls/venezuelan" },
        { id: "girls/romanian", parentId: "girls/chinese", title: "🇷🇴罗马尼亚女孩", icon: "", biz: "girls/romanian" },
        { id: "girls/african", parentId: "girls/chinese", title: "🌍非洲女孩", icon: "", biz: "girls/african" },
        { id: "girls/spanish-speaking", parentId: "girls/chinese", title: "🇪🇸西班牙女孩", icon: "", biz: "girls/spanish-speaking" },
        { id: "girls/arab", parentId: "girls/chinese", title: "🇸🇦🇦🇪阿拉伯女孩", icon: "", biz: "girls/arab" },
        { id: "girls/kenyan", parentId: "girls/chinese", title: "🇰🇪肯尼亚女孩", icon: "", biz: "girls/kenyan" },
        { id: "girls/south-african", parentId: "girls/chinese", title: "🇿🇦南非女孩", icon: "", biz: "girls/south-african" },
        { id: "girls/brazilian", parentId: "girls/chinese", title: "🇧🇷巴西女孩", icon: "", biz: "girls/brazilian" },
        { id: "girls/thai", parentId: "girls/chinese", title: "🇹🇭泰国女孩", icon: "", biz: "girls/thai" },
        { id: "girls/italian", parentId: "girls/chinese", title: "🇮🇹意大利女孩", icon: "", biz: "girls/italian" },
        { id: "girls/teens", parentId: "girls/chinese", title: "少女18+", icon: "", biz: "girls/teens" },
        { id: "girls/young", parentId: "girls/chinese", title: "鲜嫩青年22+", icon: "", biz: "girls/young" },
        { id: "girls/milfs", parentId: "girls/chinese", title: "熟女", icon: "", biz: "girls/milfs" },
        { id: "girls/mature", parentId: "girls/chinese", title: "成熟", icon: "", biz: "girls/mature" },
        { id: "girls/grannies", parentId: "girls/chinese", title: "老奶奶", icon: "", biz: "girls/grannies" },
        { id: "girls/white", parentId: "girls/chinese", title: "白人", icon: "", biz: "girls/white" },
        { id: "girls/asian", parentId: "girls/chinese", title: "亚洲人", icon: "", biz: "girls/asian" },
        { id: "girls/latin", parentId: "girls/chinese", title: "拉丁人", icon: "", biz: "girls/latin" },
        { id: "girls/ebony", parentId: "girls/chinese", title: "黑珍珠", icon: "", biz: "girls/ebony" },
        { id: "girls/indian", parentId: "girls/chinese", title: "印度人", icon: "", biz: "girls/indian" },
        { id: "girls/new", parentId: "girls/chinese", title: "最新女主播", icon: "", biz: "girls/new" },
        { id: "girls", parentId: "girls/chinese", title: "全部女主播", icon: "", biz: "girls" }
      ]
    },
    {
      id: "couples/chinese",
      parentId: "",
      title: "情侣",
      icon: "",
      biz: "couples/chinese",
      subList: [
        { id: "couples/chinese", parentId: "couples/chinese", title: "中国情侣", icon: "", biz: "couples/chinese" },
        { id: "couples/popular", parentId: "couples/chinese", title: "热门情侣", icon: "", biz: "couples/popular" },
        { id: "couples/new", parentId: "couples/chinese", title: "最新情侣", icon: "", biz: "couples/new" },
        { id: "couples", parentId: "couples/chinese", title: "全部情侣", icon: "", biz: "couples" }
      ]
    },
    {
      id: "men/popular",
      parentId: "",
      title: "男主播",
      icon: "",
      biz: "men/popular",
      subList: [
        { id: "men/popular", parentId: "men/popular", title: "最受欢迎", icon: "", biz: "men/popular" },
        { id: "men/gay-couples", parentId: "men/popular", title: "男同伴侣", icon: "", biz: "men/gay-couples" },
        { id: "men/gays", parentId: "men/popular", title: "男同聊天", icon: "", biz: "men/gays" },
        { id: "men/straight", parentId: "men/popular", title: "直男", icon: "", biz: "men/straight" },
        { id: "men", parentId: "men/popular", title: "全部男主播", icon: "", biz: "men" }
      ]
    },
    {
      id: "girls/recommended",
      parentId: "",
      title: "推荐",
      icon: "",
      biz: "girls/recommended",
      subList: []
    },
    {
      id: "girls/popular",
      parentId: "",
      title: "免费性爱",
      icon: "",
      biz: "girls/popular",
      subList: []
    },
    {
      id: "couples/group-sex",
      parentId: "",
      title: "群交直播",
      icon: "",
      biz: "couples/group-sex",
      subList: []
    },
    {
      id: "couples/lesbians",
      parentId: "",
      title: "女同",
      icon: "",
      biz: "couples/lesbians",
      subList: []
    },
    {
      id: "girls/vr",
      parentId: "",
      title: "VR",
      icon: "",
      biz: "girls/vr",
      subList: []
    },
    {
      id: "trans/popular",
      parentId: "",
      title: "变性人",
      icon: "",
      biz: "trans/popular",
      subList: []
    },
    {
      id: "girls/new",
      parentId: "",
      title: "新主播",
      icon: "",
      biz: "girls/new",
      subList: []
    }
  ];
}

// ============================================================
// API 请求
// ============================================================

async function _sc_fetchModels(cateId, page) {
  const limit = 200;
  const offset = (page - 1) * limit;
  const url = _SC_BASE_URL + "/api/models"
    + "?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=" + limit
    + "&offset=" + offset
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  const resp = await Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  });

  if (resp.status !== 200) {
    _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
  }

  const obj = JSON.parse(resp.bodyText || "{}");
  const models = obj.models || [];
  return models;
}

// ============================================================
// 核心功能实现
// ============================================================

async function _sc_getCategories() {
  return _sc_getCategoryDefinitions();
}

async function _sc_getRooms(cateId, page) {
  const models = await _sc_fetchModels(cateId, page);

  return models.map(function (m) {
    return {
      roomId: String(m.id || ""),
      userId: String(m.id || ""),
      userName: String(m.username || ""),
      roomTitle: String(m.username || ""),
      roomCover: String(m.snapshotUrl || ""),
      userHeadImg: String(m.snapshotUrl || ""),
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: String(m.viewersCount || "0")
    };
  });
}

async function _sc_getRoomDetail(roomId) {
  // StripChat API 不提供单个主播详情接口
  // 通过搜索列表模拟
  const models = await _sc_fetchModels("girls/popular", 1);
  const found = models.find(function (m) {
    return String(m.id) === String(roomId);
  });

  if (!found) {
    _sc_throw("NOT_FOUND", "room not found", { roomId: String(roomId) });
  }

  return {
    roomId: String(found.id || ""),
    userId: String(found.id || ""),
    userName: String(found.username || ""),
    roomTitle: String(found.username || ""),
    roomCover: String(found.snapshotUrl || ""),
    userHeadImg: String(found.snapshotUrl || ""),
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: String(found.viewersCount || "0")
  };
}

async function _sc_getPlayback(roomId) {
  // 构造 HLS 播放地址
  const playUrl = _SC_EDGE_CDN + "/hls/"
    + encodeURIComponent(String(roomId))
    + "/master/"
    + encodeURIComponent(String(roomId))
    + "_auto.m3u8?playlistType=lowLatency";

  return [
    {
      cdn: "default",
      displayName: "默认线路",
      qualitys: [
        {
          roomId: String(roomId),
          title: "自动",
          qn: 0,
          url: playUrl,
          liveCodeType: "m3u8",
          liveType: "stripchat",
          headers: {
            "User-Agent": _SC_USER_AGENT,
            "Referer": _SC_PAGE_URL + "/"
          },
          playbackHints: {
            streamFormat: "hlsLive",
            selectionBehavior: "direct"
          }
        }
      ]
    }
  ];
}

async function _sc_resolveShare(shareCode) {
  const input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  // 尝试从URL中提取用户名
  let username = "";
  const patterns = [
    /stripchat\.(?:global|com)\/([\w]+)/,
    /\/([\w]+)$/
  ];

  for (const p of patterns) {
    const m = input.match(p);
    if (m && m[1]) {
      username = m[1];
      break;
    }
  }

  // 如果输入本身就是用户名
  if (!username && /^[a-zA-Z0-9_]+$/.test(input)) {
    username = input;
  }

  if (!username) {
    _sc_throw("NOT_FOUND", "cannot extract username from shareCode", { shareCode: input });
  }

  // 返回以用户名作为 roomId 的详情
  return {
    roomId: username,
    userId: username,
    userName: username,
    roomTitle: username,
    roomCover: "",
    userHeadImg: "",
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: "0"
  };
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async getCategories() {
    return await _sc_getCategories();
  },

  async getRooms(payload) {
    const id = String(payload && payload.id ? payload.id : "");
    const page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return await _sc_getRooms(id, page);
  },

  async getPlayback(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return await _sc_getPlayback(roomId);
  },

  async getRoomDetail(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return await _sc_getRoomDetail(roomId);
  },

  async getLiveState(payload) {
    const roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    // StripChat 列表中的主播默认都在直播
    return { liveState: "1" };
  },

  async resolveShare(payload) {
    const shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return await _sc_resolveShare(shareCode);
  }
};
