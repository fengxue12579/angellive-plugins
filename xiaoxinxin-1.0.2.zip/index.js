// ============================================================
// 小心心 AngelLive Plugin v1.0.0
// 支持房间列表、WebView登录、声网RTC播放
// ============================================================

var _XX_BASE_URL = "https://stripchat-proxy.fengxue556.ccwu.cc/xiaoxinxin";
var _XX_IMG_URL = "https://stripchat-proxy.fengxue556.ccwu.cc/xiaoxinxin-img";
var _XX_PAGE_URL = "https://h5.xiaoxinxin.com";
var _XX_USER_AGENT = "XiaoXinXin/1.3.6 (iPhone; iOS 27.0; Scale/3.00)";

// ---- Login Credential Management ----
var _xx_loginPlatformId = "xiaoxinxin";
var _xx_loginRuntime = {
  credentialSynced: false,
  credentialStatus: { state: "missing", expireAt: 0, userId: "", userName: "", message: "" }
};
function _xx_loginTrim(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function _xx_loginBuildCredentialStatus(s) {
  var src = s && typeof s === "object" ? s : {};
  return { state: _xx_loginTrim(src.state) || "unknown", expireAt: src.expireAt || 0, userId: _xx_loginTrim(src.userId), userName: _xx_loginTrim(src.userName), message: _xx_loginTrim(src.message) };
}
function _xx_loginSetCredentialStatus(s) { _xx_loginRuntime.credentialStatus = _xx_loginBuildCredentialStatus(s); return _xx_loginBuildCredentialStatus(_xx_loginRuntime.credentialStatus); }
function _xx_loginMarkSynced(msg) { _xx_loginRuntime.credentialSynced = true; return _xx_loginSetCredentialStatus({ state: "unknown", expireAt: 0, userId: "", userName: "", message: _xx_loginTrim(msg) || "credential synced" }); }
function _xx_loginMarkCleared() { _xx_loginRuntime.credentialSynced = false; return _xx_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "" }); }
function _xx_loginReadCookieHeader() { if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") { return _xx_loginTrim(Host.session.getCookieHeader(_xx_loginPlatformId)); } return ""; }
function _xx_loginReadCookieValue(hdr, name) {
  var cookie = _xx_loginTrim(hdr), target = _xx_loginTrim(name);
  if (!cookie || !target) return "";
  var parts = cookie.split(";"); for (var i = 0; i < parts.length; i++) { var seg = _xx_loginTrim(parts[i]); if (!seg) continue; var idx = seg.indexOf("="); var key = idx >= 0 ? seg.slice(0, idx).trim() : seg; var val = idx >= 0 ? seg.slice(idx + 1).trim() : ""; if (key === target) return val; } return "";
}
function _xx_loginIsLoggedIn(hdr) { return !!_xx_loginReadCookieValue(hdr, "Authorization"); }

// ---- HTTP Helper ----
function _xx_httpGet(url, headers, timeout) {
  var h = headers || {};
  h["User-Agent"] = h["User-Agent"] || _XX_USER_AGENT;
  return Host.http.request({
    platformId: "xiaoxinxin",
    authMode: "platform_cookie",
    request: { url: url, method: "GET", headers: h, timeout: timeout || 20 }
  }).then(function (resp) {
    if (resp.statusCode >= 200 && resp.statusCode < 300) return resp;
    throw new Error("HTTP " + resp.statusCode);
  });
}

// ---- Build Auth Headers from Cookie ----
function _xx_buildAuthHeaders() {
  var cookieHeader = _xx_loginReadCookieHeader();
  var auth = _xx_loginReadCookieValue(cookieHeader, "Authorization");
  var deviceId = _xx_loginReadCookieValue(cookieHeader, "deviceid") || "F888B90A-CD67-49DA-9822-56CFC5A440FB";
  var uid = _xx_loginReadCookieValue(cookieHeader, "uid") || "700445";
  var headers = {
    "User-Agent": _XX_USER_AGENT,
    "Referer": _XX_PAGE_URL + "/",
    "Origin": _XX_PAGE_URL,
    "Accept": "*/*",
    "Accept-Language": "zh-Hans-CN;q=1",
    "Accept-Encoding": "gzip, deflate, br",
    "channel": "appstore",
    "api-calling-platform": "iOS",
    "platform": "iOS",
    "version_name": "1.3.6.69",
    "deviceid": deviceId
  };
  if (auth) {
    headers["authorization"] = "Bearer " + auth;
    headers["cookie"] = "Authorization=" + auth;
  }
  return { headers: headers, auth: auth, uid: uid, deviceId: deviceId };
}

// ---- API: Get Room List ----
function _xx_getRooms(pageNum, pageSize) {
  var authInfo = _xx_buildAuthHeaders();
  var url = _XX_BASE_URL + "/smallheart-app/other/broadcast/page-weight-new?liveType=1&newVersion=2&pageNum=" + (pageNum || 1) + "&pageSize=" + (pageSize || 20);
  return _xx_httpGet(url, authInfo.headers, 20).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    if (!obj.success) throw new Error(obj.message || "API error");
    return obj.data || {};
  });
}

// ---- API: Get Room Detail ----
function _xx_getRoomDetail(liveId, anchorUserId) {
  var authInfo = _xx_buildAuthHeaders();
  var url = _XX_BASE_URL + "/smallheart-app/other/broadcast/homeDetail?anchorFlag=0&anchorUserId=" + encodeURIComponent(anchorUserId) + "&appType=2&liveId=" + encodeURIComponent(liveId);
  return _xx_httpGet(url, authInfo.headers, 20).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    if (!obj.success) throw new Error(obj.message || "API error");
    return obj.data || {};
  });
}

// ---- API: Get RTC Token ----
function _xx_getRtcToken(anchorUserId, type) {
  var authInfo = _xx_buildAuthHeaders();
  var url = _XX_BASE_URL + "/smallheart-app/other/shengwang/rtc_token?anchorUserId=" + encodeURIComponent(anchorUserId || "") + "&type=" + (type || 2) + "&uid=" + authInfo.uid;
  return _xx_httpGet(url, authInfo.headers, 20).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    if (!obj.success) throw new Error(obj.message || "API error");
    return obj.data || "";
  });
}

// ---- Build Category ----
function _xx_buildCategory(id, name, icon) {
  return { id: String(id), name: String(name), icon: icon || "", parentId: "", children: [] };
}

// ---- Build Room ----
function _xx_buildRoom(item) {
  var coverUrl = item.coverImg ? (item.coverImg.startsWith("http") ? item.coverImg : _XX_IMG_URL + "/static.xiaoxinxin.com/" + item.coverImg) : "";
  var avatarUrl = item.avatar ? (item.avatar.startsWith("http") ? item.avatar : _XX_IMG_URL + "/static.xiaoxinxin.com/" + item.avatar) : "";
  return {
    roomId: String(item.liveId),
    title: String(item.title || item.nickname || ""),
    userName: String(item.nickname || ""),
    cover: coverUrl,
    avatar: avatarUrl,
    onlineCount: item.liveOnlinePeople || 0,
    categoryId: String(item.categoryId || ""),
    liveState: item.status === 1 ? "1" : "0",
    anchorUserId: String(item.anchorUserId || ""),
    roomIdStr: String(item.roomId || ""),
    extra: item
  };
}

// ---- Build Playback ----
function _xx_buildPlayback(roomId, title, token, channelName) {
  return [{
    cdn: "agora",
    displayName: "声网RTC",
    qualitys: [{
      quality: "RTC",
      qualityName: "RTC直播",
      url: "agora://" + channelName + "?token=" + encodeURIComponent(token),
      headers: {}
    }]
  }];
}

// ============================================================
// AngelLive Plugin Interface
// ============================================================
module.exports = {
  getCategories: function () {
    return Promise.resolve([
      _xx_buildCategory("all", "全部"),
      _xx_buildCategory("283240478374260736", "舞蹈"),
      _xx_buildCategory("282567613643714560", "音乐"),
      _xx_buildCategory("282567613643714561", "脱口秀"),
      _xx_buildCategory("282567613643714562", "颜值")
    ]);
  },

  getRooms: function (payload) {
    var categoryId = payload && payload.categoryId ? payload.categoryId : "";
    var pageNum = payload && payload.page ? payload.page : 1;
    return _xx_getRooms(pageNum, 20).then(function (data) {
      var records = data.records || [];
      var rooms = [];
      for (var i = 0; i < records.length; i++) {
        var room = _xx_buildRoom(records[i]);
        if (!categoryId || categoryId === "all" || room.categoryId === categoryId) {
          rooms.push(room);
        }
      }
      return { rooms: rooms, hasMore: records.length >= 20 };
    }).catch(function (e) {
      return { rooms: [], hasMore: false };
    });
  },

  getRoomDetail: function (payload) {
    var roomId = payload && payload.roomId ? payload.roomId : "";
    return _xx_getRooms(1, 50).then(function (data) {
      var records = data.records || [];
      for (var i = 0; i < records.length; i++) {
        if (String(records[i].liveId) === String(roomId)) {
          return _xx_buildRoom(records[i]);
        }
      }
      throw new Error("Room not found");
    });
  },

  getPlayback: function (payload) {
    var roomId = payload && payload.roomId ? payload.roomId : "";
    return _xx_getRooms(1, 50).then(function (data) {
      var records = data.records || [];
      var found = null;
      for (var i = 0; i < records.length; i++) {
        if (String(records[i].liveId) === String(roomId)) {
          found = records[i];
          break;
        }
      }
      if (!found) throw new Error("Room not found");
      return _xx_getRtcToken(found.anchorUserId, 2).then(function (token) {
        return _xx_buildPlayback(roomId, found.title || found.nickname, token, found.roomId || "room_" + roomId);
      });
    });
  },

  getLiveState: function (payload) {
    var roomId = payload && payload.roomId ? payload.roomId : "";
    return _xx_getRooms(1, 50).then(function (data) {
      var records = data.records || [];
      for (var i = 0; i < records.length; i++) {
        if (String(records[i].liveId) === String(roomId)) {
          return { liveState: records[i].status === 1 ? "1" : "0" };
        }
      }
      return { liveState: "0" };
    }).catch(function () {
      return { liveState: "0" };
    });
  },

  resolveShare: function (payload) {
    var url = payload && payload.url ? payload.url : "";
    var match = url.match(/[?&]id=(\d+)/);
    if (match) {
      return Promise.resolve({ roomId: match[1] });
    }
    return Promise.reject(new Error("Invalid share URL"));
  },

  clearCredential: function () {
    return Promise.resolve(_xx_loginMarkCleared());
  },

  setCredential: function () {
    return Promise.resolve(Object.assign({ ok: true }, _xx_loginMarkSynced("credential synced")));
  },

  getCredentialStatus: async function (payload) {
    var cookieHeader = _xx_loginReadCookieHeader();
    if (!cookieHeader) {
      return _xx_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未检测到 Cookie" });
    }
    var auth = _xx_loginReadCookieValue(cookieHeader, "Authorization");
    if (!auth) {
      return _xx_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未登录" });
    }
    var uid = _xx_loginReadCookieValue(cookieHeader, "uid") || "user";
    return _xx_loginSetCredentialStatus({ state: "valid", expireAt: 0, userId: uid, userName: "小心心用户", message: "" });
  },

  validateCredential: async function (payload) {
    var cookieHeader = _xx_loginReadCookieHeader();
    if (!cookieHeader) {
      return _xx_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未检测到 Cookie" });
    }
    var auth = _xx_loginReadCookieValue(cookieHeader, "Authorization");
    if (!auth) {
      return _xx_loginSetCredentialStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未登录" });
    }
    var uid = _xx_loginReadCookieValue(cookieHeader, "uid") || "user";
    return _xx_loginSetCredentialStatus({ state: "valid", expireAt: 0, userId: uid, userName: "小心心用户", message: "" });
  }
};
