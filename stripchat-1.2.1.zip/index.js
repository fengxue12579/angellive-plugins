// ============================================================
// StripChat AngelLive Plugin v1.2.1
// 新增：Cloudflare Worker 代理加速线路支持
// 修复：画质从API动态获取、CDN仅保留可用线路、分类结构优化
// ============================================================

var _SC_BASE_URL = "https://go.mavrtracktor.com";
var _SC_PAGE_URL = "https://zh.stripchat.global";
var _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

var _SC_CDN_URL = "https://edge-hls.growcdnssedge.com";

// Cloudflare Worker 代理地址
// 部署步骤：
// 1. 将 stripchat-cf-worker.js 部署到 Cloudflare Workers
// 2. 把下面的占位符替换为你的 Worker 地址
// 例如: var _SC_CF_WORKER_URL = "https://stripchat-proxy.你的子域名.workers.dev";
var _SC_CF_WORKER_URL = "";

// ============================================================
// 工具函数
// ============================================================

function _sc_makeError(code, message, context) {
  if (globalThis.Host && typeof Host.makeError === "function") {
    return Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

function _sc_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw _sc_makeError(code, message, context);
}

// 将原始 CDN URL 转换为 CF Worker 代理 URL
// 不使用 new URL()，兼容 JavaScriptCore
function _sc_convertToProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL) return originalUrl;
  if (!originalUrl || typeof originalUrl !== "string") return originalUrl;

  // 提取协议后的部分
  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  // 找到第一个 / 分割 hostname 和 path
  var slashIndex = withoutProtocol.indexOf("/");
  var hostname = "";
  var pathAndQuery = "";
  if (slashIndex === -1) {
    hostname = withoutProtocol;
    pathAndQuery = "";
  } else {
    hostname = withoutProtocol.substring(0, slashIndex);
    pathAndQuery = withoutProtocol.substring(slashIndex);
  }

  if (!hostname) return originalUrl;

  return _SC_CF_WORKER_URL + "/proxy/" + hostname + pathAndQuery;
}

// ============================================================
// 分类定义
// ============================================================

function _sc_getCategoryDefinitions() {
  return [
    {
      id: "girls/chinese",
      parentId: "",
      title: "女主播",
      icon: "",
      biz: "girls/chinese",
      subList: [
        { id: "girls/chinese", parentId: "girls/chinese", title: "中国女孩", icon: "", biz: "girls/chinese" },
        { id: "girls/japanese", parentId: "girls/chinese", title: "日本女孩", icon: "", biz: "girls/japanese" },
        { id: "girls/korean", parentId: "girls/chinese", title: "韩国女孩", icon: "", biz: "girls/korean" },
        { id: "girls/american", parentId: "girls/chinese", title: "美国女孩", icon: "", biz: "girls/american" },
        { id: "girls/russian", parentId: "girls/chinese", title: "俄罗斯女孩", icon: "", biz: "girls/russian" },
        { id: "girls/new", parentId: "girls/chinese", title: "最新女主播", icon: "", biz: "girls/new" }
      ]
    },
    {
      id: "couples/chinese",
      parentId: "",
      title: "情侣",
      icon: "",
      biz: "couples/chinese",
      subList: [
        { id: "couples/chinese", parentId: "couples/chinese", title: "中国情侣", icon: "", biz: "couples/chinese" },
        { id: "couples/popular", parentId: "couples/chinese", title: "热门情侣", icon: "", biz: "couples/popular" }
      ]
    },
    {
      id: "men/popular",
      parentId: "",
      title: "男主播",
      icon: "",
      biz: "men/popular",
      subList: [
        { id: "men/popular", parentId: "men/popular", title: "最受欢迎", icon: "", biz: "men/popular" },
        { id: "men/gays", parentId: "men/popular", title: "男同聊天", icon: "", biz: "men/gays" }
      ]
    },
    {
      id: "girls/recommended",
      parentId: "",
      title: "推荐",
      icon: "",
      biz: "girls/recommended",
      subList: [
        { id: "girls/recommended", parentId: "girls/recommended", title: "全部推荐", icon: "", biz: "girls/recommended" }
      ]
    },
    {
      id: "girls/popular",
      parentId: "",
      title: "热门",
      icon: "",
      biz: "girls/popular",
      subList: [
        { id: "girls/popular", parentId: "girls/popular", title: "全部热门", icon: "", biz: "girls/popular" }
      ]
    },
    {
      id: "couples/group-sex",
      parentId: "",
      title: "群交直播",
      icon: "",
      biz: "couples/group-sex",
      subList: [
        { id: "couples/group-sex", parentId: "couples/group-sex", title: "全部群交", icon: "", biz: "couples/group-sex" }
      ]
    },
    {
      id: "couples/lesbians",
      parentId: "",
      title: "女同",
      icon: "",
      biz: "couples/lesbians",
      subList: [
        { id: "couples/lesbians", parentId: "couples/lesbians", title: "全部女同", icon: "", biz: "couples/lesbians" }
      ]
    },
    {
      id: "girls/vr",
      parentId: "",
      title: "VR",
      icon: "",
      biz: "girls/vr",
      subList: [
        { id: "girls/vr", parentId: "girls/vr", title: "全部VR", icon: "", biz: "girls/vr" }
      ]
    },
    {
      id: "trans/popular",
      parentId: "",
      title: "变性人",
      icon: "",
      biz: "trans/popular",
      subList: [
        { id: "trans/popular", parentId: "trans/popular", title: "全部变性人", icon: "", biz: "trans/popular" }
      ]
    },
    {
      id: "girls/new",
      parentId: "",
      title: "新主播",
      icon: "",
      biz: "girls/new",
      subList: [
        { id: "girls/new", parentId: "girls/new", title: "全部新主播", icon: "", biz: "girls/new" }
      ]
    }
  ];
}

// ============================================================
// API 请求 - 使用 Promise 链式调用
// ============================================================

function _sc_fetchModels(cateId, page) {
  var limit = 200;
  var offset = (page - 1) * limit;
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=" + limit
    + "&offset=" + offset
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

function _sc_searchModels(keyword) {
  var url = _SC_BASE_URL + "/api/models"
    + "?q=" + encodeURIComponent(keyword)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=200"
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

// ============================================================
// 核心功能 - 全部使用 Promise
// ============================================================

function _sc_getCategories() {
  return Promise.resolve(_sc_getCategoryDefinitions());
}

function _sc_getRooms(cateId, page) {
  return _sc_fetchModels(cateId, page).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: String(m.snapshotUrl || ""),
        userHeadImg: String(m.avatarUrl || m.snapshotUrl || ""),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_getRoomDetail(roomId) {
  return _sc_fetchModels("girls/popular", 1).then(function (models) {
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }
    if (!found) {
      _sc_throw("NOT_FOUND", "room not found", { roomId: String(roomId) });
    }
    return {
      roomId: String(found.id || ""),
      userId: String(found.id || ""),
      userName: String(found.username || ""),
      roomTitle: String(found.username || ""),
      roomCover: String(found.snapshotUrl || ""),
      userHeadImg: String(found.avatarUrl || found.snapshotUrl || ""),
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: String(found.viewersCount || "0")
    };
  });
}

function _sc_getPlayback(roomId) {
  // 先请求API获取该主播的真实画质列表
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  return Host.http.request({
    url: url,
    method: "GET",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    timeout: 30
  }).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    var found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) {
        found = models[i];
        break;
      }
    }

    // 从API获取真实画质URL
    var streamUrls = {};
    if (found && found.stream && found.stream.urls) {
      streamUrls = found.stream.urls;
    }

    // 构建默认线路画质列表
    var defaultQualitys = [];
    var proxyQualitys = [];
    var urlKeys = Object.keys(streamUrls);
    if (urlKeys.length > 0) {
      for (var k = 0; k < urlKeys.length; k++) {
        var key = urlKeys[k];
        var playUrl = streamUrls[key];
        if (playUrl) {
          var title = key === "original" ? "原画" : key.toUpperCase();
          defaultQualitys.push({
            roomId: String(roomId),
            title: title,
            qn: k,
            url: playUrl,
            liveCodeType: "m3u8",
            liveType: "stripchat",
            headers: {
              "User-Agent": _SC_USER_AGENT,
              "Referer": _SC_PAGE_URL + "/"
            },
            playbackHints: {
              streamFormat: "hlsLive",
              selectionBehavior: "direct"
            }
          });
          // CF 代理线路
          var proxyUrl = _sc_convertToProxyUrl(playUrl);
          if (proxyUrl !== playUrl) {
            proxyQualitys.push({
              roomId: String(roomId),
              title: title,
              qn: k,
              url: proxyUrl,
              liveCodeType: "m3u8",
              liveType: "stripchat",
              headers: {
                "User-Agent": _SC_USER_AGENT,
                "Referer": _SC_PAGE_URL + "/"
              },
              playbackHints: {
                streamFormat: "hlsLive",
                selectionBehavior: "direct"
              }
            });
          }
        }
      }
    }

    // 如果API没返回画质（比如通过分享码进入），使用默认画质
    if (defaultQualitys.length === 0) {
      var defaultUrl = _SC_CDN_URL + "/hls/"
        + encodeURIComponent(String(roomId))
        + "/master/"
        + encodeURIComponent(String(roomId))
        + "_480p.m3u8?playlistType=lowLatency";
      defaultQualitys.push({
        roomId: String(roomId),
        title: "480P",
        qn: 0,
        url: defaultUrl,
        liveCodeType: "m3u8",
        liveType: "stripchat",
        headers: {
          "User-Agent": _SC_USER_AGENT,
          "Referer": _SC_PAGE_URL + "/"
        },
        playbackHints: {
          streamFormat: "hlsLive",
          selectionBehavior: "direct"
        }
      });
      var proxyFallbackUrl = _sc_convertToProxyUrl(defaultUrl);
      if (proxyFallbackUrl !== defaultUrl) {
        proxyQualitys.push({
          roomId: String(roomId),
          title: "480P",
          qn: 0,
          url: proxyFallbackUrl,
          liveCodeType: "m3u8",
          liveType: "stripchat",
          headers: {
            "User-Agent": _SC_USER_AGENT,
            "Referer": _SC_PAGE_URL + "/"
          },
          playbackHints: {
            streamFormat: "hlsLive",
            selectionBehavior: "direct"
          }
        });
      }
    }

    var results = [{
      cdn: "growcdn",
      displayName: "默认线路",
      qualitys: defaultQualitys
    }];

    // 如果配置了 CF Worker，添加代理线路
    if (proxyQualitys.length > 0) {
      results.push({
        cdn: "cfproxy",
        displayName: "CF加速",
        qualitys: proxyQualitys
      });
    }

    return results;
  });
}

function _sc_refreshPlayback(roomId, cdnId, qn) {
  var isProxy = String(cdnId) === "cfproxy";
  var playUrl = _SC_CDN_URL + "/hls/"
    + encodeURIComponent(String(roomId))
    + "/master/"
    + encodeURIComponent(String(roomId))
    + "_480p.m3u8?playlistType=lowLatency";

  // 如果选择了 CF 代理线路，转换 URL
  if (isProxy) {
    playUrl = _sc_convertToProxyUrl(playUrl);
  }

  return Promise.resolve({
    roomId: String(roomId),
    title: "480P",
    qn: 0,
    url: playUrl,
    liveCodeType: "m3u8",
    liveType: "stripchat",
    headers: {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    },
    playbackHints: {
      streamFormat: "hlsLive",
      selectionBehavior: "direct"
    }
  });
}

function _sc_search(keyword) {
  return _sc_searchModels(keyword).then(function (models) {
    return models.map(function (m) {
      return {
        roomId: String(m.id || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: String(m.snapshotUrl || ""),
        userHeadImg: String(m.avatarUrl || m.snapshotUrl || ""),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_resolveShare(shareCode) {
  var input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  var username = "";
  var patterns = [
    /stripchat\.(?:global|com)\/([\w]+)/,
    /\/([\w]+)$/
  ];

  for (var p = 0; p < patterns.length; p++) {
    var m = input.match(patterns[p]);
    if (m && m[1]) {
      username = m[1];
      break;
    }
  }

  if (!username && /^[a-zA-Z0-9_]+$/.test(input)) {
    username = input;
  }

  if (!username) {
    _sc_throw("NOT_FOUND", "cannot extract username from shareCode", { shareCode: input });
  }

  return Promise.resolve({
    roomId: username,
    userId: username,
    userName: username,
    roomTitle: username,
    roomCover: "",
    userHeadImg: "",
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: "0"
  });
}

// ============================================================
// 插件导出 - 纯 function，无 async
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function () {
    return _sc_getCategories();
  },

  getRooms: function (payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _sc_getRooms(id, page);
  },

  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getPlayback(roomId);
  },

  refreshPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    var cdn = String((payload && payload.cdn) || "");
    var quality = (payload && payload.quality) || {};
    var qualityContext = quality.requestContext || {};
    var qn = Number(qualityContext.qn !== undefined ? qualityContext.qn : quality.qn || 0);
    var cdnId = String(qualityContext.cdn || cdn || "growcdn");

    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_refreshPlayback(roomId, cdnId, qn);
  },

  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getRoomDetail(roomId);
  },

  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return Promise.resolve({ liveState: "1" });
  },

  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _sc_search(keyword);
  },

  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _sc_resolveShare(shareCode);
  },

  clearCredential: function () {
    return Promise.resolve({ ok: true });
  },

  setCredential: function () {
    return Promise.resolve({ ok: true });
  }
};
