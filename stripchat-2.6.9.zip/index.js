// ============================================================
// StripChat AngelLive Plugin v2.6.9
// 适配 Worker v6.6（新增 /stripchat/<username>.m3u 路由）
// - CF 代理线路使用 /stripchat/<username>.m3u，Worker 内部处理所有逻辑
// - 直连线路使用 API 返回的单独画质 URL
// - 图片走 /scimg/
// - API 走 /scapi/
// ============================================================

var _SC_CF_WORKER_URL = "https://stripchat-proxy.fengxue556.ccwu.cc";
var _SC_BASE_URL = _SC_CF_WORKER_URL + "/scapi";
var _SC_PAGE_URL = "https://zh.stripchat.global";
var _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";

var _SC_CDN_URL = "https://edge-hls.growcdnssedge.com";

// ============================================================
// 工具函数
// ============================================================

function _sc_makeError(code, message, context) {
  if (globalThis.Host && typeof Host.makeError === "function") {
    return Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({
    code: String(code || "UNKNOWN"),
    message: String(message || ""),
    context: context || {}
  }));
}

function _sc_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw _sc_makeError(code, message, context);
}

// 将图片 URL 转换为 CF Worker 代理 URL（走 /scimg/）
function _sc_convertToImgProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL || !originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  if (slashIndex === -1) return originalUrl;

  var hostname = withoutProtocol.substring(0, slashIndex);
  var pathAndQuery = withoutProtocol.substring(slashIndex);

  return _SC_CF_WORKER_URL + "/scimg/" + hostname + pathAndQuery;
}

// 将原始 CDN URL 转换为 CF Worker 代理 URL
// m3u8 → /m3u8/（Worker 会做 MOUFLON 解密 + PSCH/PKEY 处理，带 Origin/Referer）
// ts/其他 → /proxy/（Worker 不带 Origin/Referer）
function _sc_convertToProxyUrl(originalUrl) {
  if (!_SC_CF_WORKER_URL) return originalUrl;
  if (!originalUrl || typeof originalUrl !== "string") return originalUrl;

  var withoutProtocol = originalUrl;
  if (originalUrl.indexOf("https://") === 0) {
    withoutProtocol = originalUrl.substring(8);
  } else if (originalUrl.indexOf("http://") === 0) {
    withoutProtocol = originalUrl.substring(7);
  }

  var slashIndex = withoutProtocol.indexOf("/");
  var hostname = "";
  var pathAndQuery = "";
  if (slashIndex === -1) {
    hostname = withoutProtocol;
    pathAndQuery = "";
  } else {
    hostname = withoutProtocol.substring(0, slashIndex);
    pathAndQuery = withoutProtocol.substring(slashIndex);
  }

  if (!hostname) return originalUrl;

  // m3u8 文件走 /m3u8/ 路由（Worker 会做 MOUFLON 解密）
  if (pathAndQuery.indexOf(".m3u8") !== -1) {
    return _SC_CF_WORKER_URL + "/m3u8/" + hostname + pathAndQuery;
  }
  // 其他（ts、key 等）走 /proxy/ 路由
  return _SC_CF_WORKER_URL + "/proxy/" + hostname + pathAndQuery;
}

// 从画质 key 提取分辨率数值
function _sc_qualityValue(key) {
  if (key === "original") return 9999;
  var match = String(key).match(/(\d+)/);
  return match ? parseInt(match[1], 10) : 0;
}

// 画质排序：从高到低
function _sc_sortQualitys(qualitys) {
  return qualitys.sort(function(a, b) {
    return b.qn - a.qn;
  });
}

// ============================================================
// 网络请求封装（带重试和错误处理）
// ============================================================

function _sc_httpRequest(url, headers, timeout, retries) {
  retries = retries || 2;
  timeout = timeout || 30;

  function attempt(remain) {
    return Host.http.request({
      url: url,
      method: "GET",
      headers: headers,
      timeout: timeout
    }).then(function(resp) {
      if (resp.status >= 500 && remain > 0) {
        return attempt(remain - 1);
      }
      return resp;
    }).then(null, function(err) {
      if (remain > 0) {
        return attempt(remain - 1);
      }
      throw err;
    });
  }

  return attempt(retries);
}

// ============================================================
// 分类定义
// ============================================================

function _sc_getCategoryDefinitions() {
  return [
    {
      id: "girls/chinese",
      parentId: "",
      title: "女主播",
      icon: "",
      biz: "girls/chinese",
      subList: [
        { id: "girls/chinese", parentId: "girls/chinese", title: "中国女孩", icon: "", biz: "girls/chinese" },
        { id: "girls/japanese", parentId: "girls/chinese", title: "日本女孩", icon: "", biz: "girls/japanese" },
        { id: "girls/korean", parentId: "girls/chinese", title: "韩国女孩", icon: "", biz: "girls/korean" },
        { id: "girls/american", parentId: "girls/chinese", title: "美国女孩", icon: "", biz: "girls/american" },
        { id: "girls/russian", parentId: "girls/chinese", title: "俄罗斯女孩", icon: "", biz: "girls/russian" },
        { id: "girls/new", parentId: "girls/chinese", title: "最新女主播", icon: "", biz: "girls/new" }
      ]
    },
    {
      id: "couples/chinese",
      parentId: "",
      title: "情侣",
      icon: "",
      biz: "couples/chinese",
      subList: [
        { id: "couples/chinese", parentId: "couples/chinese", title: "中国情侣", icon: "", biz: "couples/chinese" },
        { id: "couples/popular", parentId: "couples/chinese", title: "热门情侣", icon: "", biz: "couples/popular" }
      ]
    },
    {
      id: "men/popular",
      parentId: "",
      title: "男主播",
      icon: "",
      biz: "men/popular",
      subList: [
        { id: "men/popular", parentId: "men/popular", title: "最受欢迎", icon: "", biz: "men/popular" },
        { id: "men/gays", parentId: "men/popular", title: "男同聊天", icon: "", biz: "men/gays" }
      ]
    },
    {
      id: "girls/recommended",
      parentId: "",
      title: "推荐",
      icon: "",
      biz: "girls/recommended",
      subList: [
        { id: "girls/recommended", parentId: "girls/recommended", title: "全部推荐", icon: "", biz: "girls/recommended" }
      ]
    },
    {
      id: "girls/popular",
      parentId: "",
      title: "热门",
      icon: "",
      biz: "girls/popular",
      subList: [
        { id: "girls/popular", parentId: "girls/popular", title: "全部热门", icon: "", biz: "girls/popular" }
      ]
    },
    {
      id: "couples/group-sex",
      parentId: "",
      title: "群交直播",
      icon: "",
      biz: "couples/group-sex",
      subList: [
        { id: "couples/group-sex", parentId: "couples/group-sex", title: "全部群交", icon: "", biz: "couples/group-sex" }
      ]
    },
    {
      id: "couples/lesbians",
      parentId: "",
      title: "女同",
      icon: "",
      biz: "couples/lesbians",
      subList: [
        { id: "couples/lesbians", parentId: "couples/lesbians", title: "全部女同", icon: "", biz: "couples/lesbians" }
      ]
    },
    {
      id: "girls/vr",
      parentId: "",
      title: "VR",
      icon: "",
      biz: "girls/vr",
      subList: [
        { id: "girls/vr", parentId: "girls/vr", title: "全部VR", icon: "", biz: "girls/vr" }
      ]
    },
    {
      id: "trans/popular",
      parentId: "",
      title: "变性人",
      icon: "",
      biz: "trans/popular",
      subList: [
        { id: "trans/popular", parentId: "trans/popular", title: "全部变性人", icon: "", biz: "trans/popular" }
      ]
    },
    {
      id: "girls/new",
      parentId: "",
      title: "新主播",
      icon: "",
      biz: "girls/new",
      subList: [
        { id: "girls/new", parentId: "girls/new", title: "全部新主播", icon: "", biz: "girls/new" }
      ]
    }
  ];
}

// ============================================================
// API 请求
// ============================================================

function _sc_fetchModels(cateId, page) {
  var limit = 200;
  var offset = (page - 1) * limit;
  var url = _SC_BASE_URL + "/api/models"
    + "?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=" + limit
    + "&offset=" + offset
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return _sc_httpRequest(url, {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  }, 30, 2).then(function(resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

// 通过 username 获取单个主播的详细数据（含 stream URL）
function _sc_fetchModelByUsername(username) {
  var url = _SC_BASE_URL + "/api/models"
    + "?q=" + encodeURIComponent(username)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=5"
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return _sc_httpRequest(url, {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  }, 30, 2).then(function(resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [];
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].username || "").toLowerCase() === String(username).toLowerCase()) {
        return models[i];
      }
    }
    return null;
  });
}

function _sc_searchModels(keyword) {
  var url = _SC_BASE_URL + "/api/models"
    + "?q=" + encodeURIComponent(keyword)
    + "&forceClient=1"
    + "&stripcashR=0"
    + "&limit=200"
    + "&usePreroll"
    + "&webp=1"
    + "&type=popular"
    + "&timezone=Asia/Shanghai";

  return _sc_httpRequest(url, {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  }, 30, 2).then(function(resp) {
    if (resp.status !== 200) {
      _sc_throw("NETWORK", "HTTP " + resp.status, { status: resp.status, url: url });
    }
    var obj = JSON.parse(resp.bodyText || "{}");
    return obj.models || [];
  });
}

// ============================================================
// 核心功能
// ============================================================

function _sc_getCategories() {
  return Promise.resolve(_sc_getCategoryDefinitions());
}

function _sc_getRooms(cateId, page) {
  return _sc_fetchModels(cateId, page).then(function(models) {
    return models.map(function(m) {
      return {
        roomId: String(m.username || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: _sc_convertToImgProxyUrl(String(m.snapshotUrl || "")),
        userHeadImg: _sc_convertToImgProxyUrl(String(m.avatarUrl || m.snapshotUrl || "")),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_getRoomDetail(roomId) {
  return _sc_fetchModelByUsername(roomId).then(function(found) {
    if (!found) {
      _sc_throw("NOT_FOUND", "room not found", { roomId: String(roomId) });
    }
    return {
      roomId: String(found.username || ""),
      userId: String(found.id || ""),
      userName: String(found.username || ""),
      roomTitle: String(found.username || ""),
      roomCover: _sc_convertToImgProxyUrl(String(found.snapshotUrl || "")),
      userHeadImg: _sc_convertToImgProxyUrl(String(found.avatarUrl || found.snapshotUrl || "")),
      liveType: "stripchat",
      liveState: "1",
      liveWatchedCount: String(found.viewersCount || "0")
    };
  });
}

// 构建单个画质对象
// v2.6.3：CF 代理线路不携带 headers（Worker 会设置正确的 Host/Referer/Origin）
function _sc_buildQuality(roomId, title, qn, url, headers, isProxy) {
  var ua = "";
  var cleanHeaders = {};
  if (headers && !isProxy) {
    // 直连线路才携带 headers
    for (var key in headers) {
      if (headers.hasOwnProperty(key)) {
        if (key.toLowerCase() === "user-agent") {
          ua = String(headers[key]);
        } else {
          cleanHeaders[key] = headers[key];
        }
      }
    }
  }

  return {
    roomId: String(roomId),
    title: title,
    qn: qn,
    url: url,
    liveCodeType: "m3u8",
    liveType: "stripchat",
    userAgent: ua || _SC_USER_AGENT,
    headers: cleanHeaders,
    playbackHints: {
      streamFormat: "hlsLive",
      selectionBehavior: "direct"
    }
  };
}

// 从 stream.urls 构建画质列表
function _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers, isProxy) {
  var qualitys = [];
  var urlKeys = Object.keys(streamUrls);

  for (var k = 0; k < urlKeys.length; k++) {
    var key = urlKeys[k];
    var playUrl = streamUrls[key];
    if (!playUrl) continue;

    var qnValue = _sc_qualityValue(key);
    var title = key === "original" ? "原画" : key.toUpperCase();

    qualitys.push(_sc_buildQuality(roomId, title, qnValue, playUrl, headers, isProxy));
  }

  return _sc_sortQualitys(qualitys);
}

// ============================================================
// 播放获取（v2.6.8：直接通过 API 查询，CF 代理线路不携带 headers）
// ============================================================

function _sc_getPlayback(roomId) {
  // roomId 在本插件中是 username
  var username = String(roomId);

  var headers = {
    "User-Agent": _SC_USER_AGENT,
    "Referer": _SC_PAGE_URL + "/"
  };

  return _sc_fetchModelByUsername(username).then(function(found) {
    var streamUrls = {};
    if (found && found.stream && found.stream.urls) {
      streamUrls = found.stream.urls;
    }
    return _sc_buildPlaybackResult(roomId, username, streamUrls, headers);
  });
}

// 构建播放结果（支持 CF 代理和直连两条线路）
// CF 代理线路：使用 /stripchat/<username>.m3u，Worker 内部处理所有逻辑
// 直连线路：发送单独画质 URL（携带 headers）
function _sc_buildPlaybackResult(roomId, username, streamUrls, headers) {
  var directQualitys = [];
  var proxyQualitys = [];

  // CF 代理线路：使用新的 /stripchat/<username>.m3u8 端点
  // Worker 内部完成：获取 master → 提取 PSCH/PKEY → 注入 → MOUFLON 解密 → URL 重写
  var stripchatM3uUrl = _SC_CF_WORKER_URL + "/stripchat/" + encodeURIComponent(username) + ".m3u8";

  if (Object.keys(streamUrls).length > 0) {
    // 直连线路画质（携带 headers，使用 API 返回的单独画质 URL）
    directQualitys = _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers, false);

    // CF 代理线路：只提供一个 URL，Worker 内部处理所有画质
    proxyQualitys.push(_sc_buildQuality(roomId, "Auto", 0, stripchatM3uUrl, null, true));
  }

  // 如果没有 streamUrls，使用 master playlist 兜底
  if (directQualitys.length === 0) {
    var fallbackMasterUrl = _SC_CDN_URL + "/hls/"
      + encodeURIComponent(username)
      + "/master/"
      + encodeURIComponent(username)
      + "_480p.m3u8?playlistType=lowLatency";

    directQualitys.push(_sc_buildQuality(roomId, "Auto", 0, fallbackMasterUrl, headers, false));

    if (proxyQualitys.length === 0) {
      proxyQualitys.push(_sc_buildQuality(roomId, "Auto", 0, stripchatM3uUrl, null, true));
    }
  }

  var results = [];

  // 线路1：growcdn 直连（默认线路，携带 headers）
  results.push({
    cdn: "growcdn",
    displayName: "直连",
    qualitys: directQualitys
  });

  // 线路2：CF Worker 代理（备选，不携带 headers）
  results.push({
    cdn: "cfproxy",
    displayName: "CF加速",
    qualitys: proxyQualitys.length > 0 ? proxyQualitys : directQualitys
  });

  return results;
}

function _sc_refreshPlayback(roomId, cdnId, qn) {
  var cdn = String(cdnId || "growcdn");
  var username = String(roomId);

  return _sc_fetchModelByUsername(username).then(function(found) {
    var streamUrls = {};
    if (found && found.stream && found.stream.urls) {
      streamUrls = found.stream.urls;
    }

    var headers = {
      "User-Agent": _SC_USER_AGENT,
      "Referer": _SC_PAGE_URL + "/"
    };

    var allQualitys = [];
    if (Object.keys(streamUrls).length > 0) {
      allQualitys = _sc_buildQualitysFromStreamUrls(roomId, streamUrls, headers, false);
    }

    if (allQualitys.length > 0) {
      var best = allQualitys[0];
      var playUrl = best.url;

      if (cdn === "cfproxy") {
        playUrl = _sc_convertToProxyUrl(best.url);
        // CF 代理线路不携带 headers
        return Promise.resolve(_sc_buildQuality(roomId, best.title, best.qn, playUrl, null, true));
      }

      return Promise.resolve(_sc_buildQuality(roomId, best.title, best.qn, playUrl, headers, false));
    }

    // 兜底
    var fallbackUrl = _SC_CDN_URL + "/hls/"
      + encodeURIComponent(username)
      + "/master/"
      + encodeURIComponent(username)
      + "_480p.m3u8?playlistType=lowLatency";

    if (cdn === "cfproxy") {
      fallbackUrl = _sc_convertToProxyUrl(fallbackUrl);
      return Promise.resolve(_sc_buildQuality(roomId, "Auto", 0, fallbackUrl, null, true));
    }

    return Promise.resolve(_sc_buildQuality(roomId, "Auto", 0, fallbackUrl, headers, false));
  });
}

function _sc_search(keyword) {
  return _sc_searchModels(keyword).then(function(models) {
    return models.map(function(m) {
      return {
        roomId: String(m.username || ""),
        userId: String(m.id || ""),
        userName: String(m.username || ""),
        roomTitle: String(m.username || ""),
        roomCover: _sc_convertToImgProxyUrl(String(m.snapshotUrl || "")),
        userHeadImg: _sc_convertToImgProxyUrl(String(m.avatarUrl || m.snapshotUrl || "")),
        liveType: "stripchat",
        liveState: "1",
        liveWatchedCount: String(m.viewersCount || "0")
      };
    });
  });
}

function _sc_resolveShare(shareCode) {
  var input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  var username = "";
  var patterns = [
    /stripchat\.(?:global|com)\/([\w]+)/,
    /\/([\w]+)$/
  ];

  for (var p = 0; p < patterns.length; p++) {
    var m = input.match(patterns[p]);
    if (m && m[1]) {
      username = m[1];
      break;
    }
  }

  if (!username && /^[a-zA-Z0-9_]+$/.test(input)) {
    username = input;
  }

  if (!username) {
    _sc_throw("NOT_FOUND", "cannot extract username from shareCode", { shareCode: input });
  }

  return Promise.resolve({
    roomId: username,
    userId: username,
    userName: username,
    roomTitle: username,
    roomCover: "",
    userHeadImg: "",
    liveType: "stripchat",
    liveState: "1",
    liveWatchedCount: "0"
  });
}

// ============================================================
// 插件导出
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function() {
    return _sc_getCategories();
  },

  getRooms: function(payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _sc_getRooms(id, page);
  },

  getPlayback: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getPlayback(roomId);
  },

  refreshPlayback: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    var cdn = String((payload && payload.cdn) || "");
    var quality = (payload && payload.quality) || {};
    var qualityContext = quality.requestContext || {};
    var qn = Number(qualityContext.qn !== undefined ? qualityContext.qn : quality.qn || 0);
    var cdnId = String(qualityContext.cdn || cdn || "cfproxy");

    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_refreshPlayback(roomId, cdnId, qn);
  },

  getRoomDetail: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getRoomDetail(roomId);
  },

  getLiveState: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return Promise.resolve({ liveState: "1" });
  },

  search: function(payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _sc_search(keyword);
  },

  resolveShare: function(payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _sc_resolveShare(shareCode);
  },

  clearCredential: function() {
    return Promise.resolve({ ok: true });
  },

  setCredential: function() {
    return Promise.resolve({ ok: true });
  }
};
