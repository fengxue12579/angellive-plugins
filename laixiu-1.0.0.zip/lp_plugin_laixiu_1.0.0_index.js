// ============================================================
// 来秀直播 AngelLive (LiveParse) Plugin v1.0.0
// Cookie 鉴权 | 直连 wapapi | FLV 直播流
// ============================================================

// ==================== Constants ====================

var _LX_PLATFORM  = "laixiu";
var _LX_API       = "https://wapapi.imkktv.com";
var _LX_SITE      = "https://www.imkktv.com";
var _LX_UA        = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36";
var _LX_LIST_PATH      = "/supplement/image/banner/getBannerAndLiveHot/v2";
var _LX_SEARCH_PATH    = "/user/search/user";
var _LX_ENTER_ROOM_PATH = "/liveroom/userEnterRoomNew";

// ==================== Utility ====================

function _lx_trim(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function _lx_str(v, def) { return v != null ? String(v) : (def || ""); }
function _lx_num(v, def) { var n = Number(v); return isNaN(n) ? (def || 0) : n; }

function _lx_throw(code, message, ctx) {
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, ctx || {});
  throw new Error("LP_PLUGIN_ERROR:" + JSON.stringify({ code: code, message: message, context: ctx || {} }));
}

// ==================== Cookie Reading ====================

function _lx_readCookieHeader() {
  if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") {
    return _lx_trim(Host.session.getCookieHeader(_LX_PLATFORM));
  }
  return "";
}

function _lx_readCookieValue(hdr, name) {
  var cookie = _lx_trim(hdr);
  var target = _lx_trim(name);
  if (!cookie || !target) return "";
  var parts = cookie.split(";");
  for (var i = 0; i < parts.length; i++) {
    var seg = _lx_trim(parts[i]);
    if (!seg) continue;
    var idx = seg.indexOf("=");
    var key = idx >= 0 ? seg.slice(0, idx).trim() : seg;
    var val = idx >= 0 ? seg.slice(idx + 1).trim() : "";
    if (key === target) return val;
  }
  return "";
}

// ==================== MD5 ====================

var _lx_md5Fn = null;
try {
  // Prefer Host.crypto.md5 if available
  if (globalThis.Host && Host.crypto && typeof Host.crypto.md5 === "function") {
    _lx_md5Fn = function (s) { return Host.crypto.md5(s); };
  }
} catch (e) { /* ignore */ }

if (!_lx_md5Fn) {
  // Inline MD5 fallback (pure JS, no dependency)
  _lx_md5Fn = (function () {
    function add32(a, b) { return (a + b) & 0xFFFFFFFF; }
    function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
    function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
    function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
    function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
    function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
    function md5cycle(x, k) {
      var a = x[0], b = x[1], c = x[2], d = x[3];
      a = ff(a,b,c,d,k[0],7,-680876936); d = ff(d,a,b,c,k[1],12,-389564586); c = ff(c,d,a,b,k[2],17,606105819); b = ff(b,c,d,a,k[3],22,-1044525330);
      a = ff(a,b,c,d,k[4],7,-176418897); d = ff(d,a,b,c,k[5],12,1200080426); c = ff(c,d,a,b,k[6],17,-1473231341); b = ff(b,c,d,a,k[7],22,-45705983);
      a = ff(a,b,c,d,k[8],7,1770035416); d = ff(d,a,b,c,k[9],12,-1958414417); c = ff(c,d,a,b,k[10],17,-42063); b = ff(b,c,d,a,k[11],22,-1990404162);
      a = ff(a,b,c,d,k[12],7,1804603682); d = ff(d,a,b,c,k[13],12,-40341101); c = ff(c,d,a,b,k[14],17,-1502002290); b = ff(b,c,d,a,k[15],22,1236535329);
      a = gg(a,b,c,d,k[1],5,-165796510); d = gg(d,a,b,c,k[6],9,-1069501632); c = gg(c,d,a,b,k[11],14,643717713); b = gg(b,c,d,a,k[0],20,-373897302);
      a = gg(a,b,c,d,k[5],5,-701558691); d = gg(d,a,b,c,k[10],9,38016083); c = gg(c,d,a,b,k[15],14,-660478335); b = gg(b,c,d,a,k[4],20,-405537848);
      a = gg(a,b,c,d,k[9],5,568446438); d = gg(d,a,b,c,k[14],9,-1019803690); c = gg(c,d,a,b,k[3],14,-187363961); b = gg(b,c,d,a,k[8],20,1163531501);
      a = gg(a,b,c,d,k[13],5,-1444681467); d = gg(d,a,b,c,k[2],9,-51403784); c = gg(c,d,a,b,k[7],14,1735328473); b = gg(b,c,d,a,k[12],20,-1926607734);
      a = hh(a,b,c,d,k[5],4,-378558); d = hh(d,a,b,c,k[8],11,-2022574463); c = hh(c,d,a,b,k[11],16,1839030562); b = hh(b,c,d,a,k[14],23,-35309556);
      a = hh(a,b,c,d,k[1],4,-1530992060); d = hh(d,a,b,c,k[4],11,1272893353); c = hh(c,d,a,b,k[7],16,-155497632); b = hh(b,c,d,a,k[10],23,-1094730640);
      a = hh(a,b,c,d,k[13],4,681279174); d = hh(d,a,b,c,k[0],11,-358537222); c = hh(c,d,a,b,k[3],16,-722521979); b = hh(b,c,d,a,k[6],23,76029189);
      a = hh(a,b,c,d,k[9],4,-640364487); d = hh(d,a,b,c,k[12],11,-421815835); c = hh(c,d,a,b,k[15],16,530742520); b = hh(b,c,d,a,k[2],23,-995338651);
      a = ii(a,b,c,d,k[0],6,-198630844); d = ii(d,a,b,c,k[7],10,1126891415); c = ii(c,d,a,b,k[14],15,-1416354905); b = ii(b,c,d,a,k[5],21,-57434055);
      a = ii(a,b,c,d,k[12],6,1700485571); d = ii(d,a,b,c,k[3],10,-1894986606); c = ii(c,d,a,b,k[10],15,-1051523); b = ii(b,c,d,a,k[1],21,-2054922799);
      a = ii(a,b,c,d,k[8],6,1873313359); d = ii(d,a,b,c,k[15],10,-30611744); c = ii(c,d,a,b,k[6],15,-1560198380); b = ii(b,c,d,a,k[13],21,1309151649);
      a = ii(a,b,c,d,k[4],6,-145523070); d = ii(d,a,b,c,k[11],10,-1120210379); c = ii(c,d,a,b,k[2],15,718787259); b = ii(b,c,d,a,k[9],21,-343485551);
      x[0] = add32(a, x[0]); x[1] = add32(b, x[1]); x[2] = add32(c, x[2]); x[3] = add32(d, x[3]);
    }
    function md5blk(s) {
      var b = [];
      for (var i = 0; i < 64; i += 4) b[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) + (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24);
      return b;
    }
    var hc = "0123456789abcdef".split("");
    function rh(n) { var s = "", j = 0; for (; j < 4; j++) s += hc[(n >> (j * 8 + 4)) & 0xF] + hc[(n >> (j * 8)) & 0xF]; return s; }
    function hex(x) { for (var i = 0; i < x.length; i++) x[i] = rh(x[i]); return x.join(""); }
    function toU(s) {
      var u = [];
      for (var i = 0; i < s.length; i++) { var c = s.charCodeAt(i); if (c < 128) u.push(c); else if (c < 2048) u.push(192 | (c >> 6), 128 | (c & 63)); else u.push(224 | (c >> 12), 128 | ((c >> 6) & 63), 128 | (c & 63)); }
      return String.fromCharCode.apply(null, u);
    }
    return function (s) {
      s = toU(s);
      var n = s.length, st = [1732584193, -271733879, -1732584194, 271733878], i;
      for (i = 64; i <= n; i += 64) md5cycle(st, md5blk(s.substring(i - 64, i)));
      s = s.substring(i - 64);
      var t = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
      for (i = 0; i < s.length; i++) t[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
      t[i >> 2] |= 0x80 << ((i % 4) << 3);
      if (i > 55) { md5cycle(st, t); for (i = 0; i < 16; i++) t[i] = 0; }
      t[14] = n * 8;
      md5cycle(st, t);
      return hex(st);
    };
  })();
}
var _lx_md5 = _lx_md5Fn;

// ==================== Auth Header Builder ====================

/**
 * 从 Cookie 中读取鉴权信息，构建 wapapi 需要的 header。
 * Cookie 需包含: accessToken, userId, imei, secretSalt
 */
function _lx_buildAuthHeaders() {
  var cookie = _lx_readCookieHeader();
  var accessToken = _lx_readCookieValue(cookie, "accessToken");
  var userId      = _lx_readCookieValue(cookie, "userId");
  var imei        = _lx_readCookieValue(cookie, "imei");
  var secretSalt  = _lx_readCookieValue(cookie, "secretSalt");

  var ts = String(Date.now());
  var requestId = _lx_md5("web" + imei + userId + ts + secretSalt);

  return {
    "User-Agent":    _LX_UA,
    "Content-Type":  "application/x-www-form-urlencoded",
    "accessToken":   accessToken,
    "userId":        userId,
    "imei":          imei,
    "channel":       "9",
    "loginType":     "2",
    "mobileModel":   "web",
    "os":            "web",
    "platform":      "WEB",
    "version":       "1.0.0",
    "versionCode":   "10003",
    "timestamp":     ts,
    "requestId":     requestId
  };
}

// ==================== HTTP Request ====================

function _lx_httpGet(path, query) {
  var url = _LX_API + path;
  if (query) {
    var qs = [];
    for (var k in query) {
      if (query.hasOwnProperty(k)) {
        qs.push(encodeURIComponent(k) + "=" + encodeURIComponent(query[k]));
      }
    }
    if (qs.length) url += "?" + qs.join("&");
  }
  return Host.http.request({
    platformId: _LX_PLATFORM,
    authMode: "platform_cookie",
    request: { url: url, method: "GET", headers: _lx_buildAuthHeaders(), timeout: 15 }
  });
}

function _lx_httpPost(path, bodyStr) {
  var url = _LX_API + path;
  return Host.http.request({
    platformId: _LX_PLATFORM,
    authMode: "platform_cookie",
    request: { url: url, method: "POST", headers: _lx_buildAuthHeaders(), body: bodyStr || "", timeout: 15 }
  });
}

// ==================== Data Helpers ====================

/** 从进房数据中提取 FLV 流地址（优先级: urlPlayAcc > urlPlayFlv > urlPlayAccMix > ...） */
function _lx_extractFlv(data) {
  if (!data) return null;
  var psi = (data.roomPlayStream && data.roomPlayStream.playStreamInfo) || {};
  return psi.urlPlayAcc || psi.urlPlayFlv || psi.urlPlayAccMix || data.urlPlayFlv || data.urlPlayHls || null;
}

/** 将原始 API 数据规范化为 LiveParse LiveModel 结构 */
function _lx_normalizeRoom(raw) {
  var anchorId = _lx_str(raw.anchorId || raw.userId || "");
  if (!anchorId) return null;
  var nick = _lx_str(raw.nickname || raw.nickName || "");
  var cover = _lx_str(raw.livingImg || raw.avatar || raw.coverUrl || raw.avatarUrl || "");
  var audience = _lx_num(raw.audienceNum || raw.onlineUsers || 0);
  var isLive = audience > 0 || Number(raw.status) === 1 || Number(raw.openStatus) === 0;
  var title = _lx_str(raw.liveTitle || raw.signName || "来秀直播");
  return {
    roomId:            anchorId,
    userId:            anchorId,
    userName:          nick || "未知主播",
    roomTitle:         title,
    roomCover:         cover,
    userHeadImg:       _lx_str(raw.avatar || raw.avatarUrl || cover),
    liveType:          "laixiu",
    liveState:         isLive ? "1" : "0",
    liveWatchedCount:  String(audience)
  };
}

// ==================== Genre Filter ====================

function _lx_genreFilter(item, genreId) {
  if (!genreId || genreId === "all") return true;
  var sex = _lx_num(item.sex, 0);
  var showPK = _lx_num(item.showPK, 0);
  switch (genreId) {
    case "female_dance": return sex === 2 && showPK === 0;
    case "female_pk":    return sex === 2 && showPK === 1;
    case "female":       return sex === 2;
    case "male":         return sex === 1;
    default:             return true;
  }
}

// ==================== Core: getCategories ====================

function _lx_getCategories() {
  return Promise.resolve([
    { id: "all", parentId: "", title: "全部直播", icon: "", biz: "all", subList: [
      { id: "all", parentId: "all", title: "全部", icon: "", biz: "all" }
    ]},
    { id: "female_dance", parentId: "", title: "舞蹈", icon: "", biz: "female_dance", subList: [
      { id: "female_dance", parentId: "female_dance", title: "女·舞蹈", icon: "", biz: "female_dance" }
    ]},
    { id: "female_pk", parentId: "", title: "PK", icon: "", biz: "female_pk", subList: [
      { id: "female_pk", parentId: "female_pk", title: "女·PK", icon: "", biz: "female_pk" }
    ]},
    { id: "female", parentId: "", title: "颜值", icon: "", biz: "female", subList: [
      { id: "female", parentId: "female", title: "女主播", icon: "", biz: "female" }
    ]},
    { id: "male", parentId: "", title: "男主播", icon: "", biz: "male", subList: [
      { id: "male", parentId: "male", title: "男主播", icon: "", biz: "male" }
    ]}
  ]);
}

// ==================== Core: getRooms ====================

function _lx_getRooms(cateId, page) {
  return _lx_httpGet(_LX_LIST_PATH, { currentPage: page || 1 }).then(function (resp) {
    if (resp.status >= 500) {
      _lx_throw("NETWORK", "HTTP " + resp.status, { path: _LX_LIST_PATH });
    }
    var data = JSON.parse(resp.bodyText || "{}");
    if (!data || !data.success) {
      _lx_throw("API_ERROR", (data && data.retMsg) ? data.retMsg : "获取直播列表失败", {});
    }
    var list = (data.data && data.data.resLiveHotDtoList) ? data.data.resLiveHotDtoList : [];

    // 按分类过滤
    if (cateId && cateId !== "all") {
      list = list.filter(function (r) { return _lx_genreFilter(r, cateId); });
    }

    var rooms = [];
    for (var i = 0; i < list.length; i++) {
      var room = _lx_normalizeRoom(list[i]);
      if (room) rooms.push(room);
    }
    return rooms;
  });
}

// ==================== Core: getPlayback ====================

function _lx_getPlayback(roomId) {
  var body = "roomId=" + encodeURIComponent(roomId);
  return _lx_httpPost(_LX_ENTER_ROOM_PATH, body).then(function (resp) {
    if (resp.status >= 500) {
      _lx_throw("NETWORK", "HTTP " + resp.status, { roomId: roomId });
    }
    var data = JSON.parse(resp.bodyText || "{}");
    if (!data || !data.success || data.retCode !== 200 || !data.data) {
      _lx_throw("API_ERROR", "进房失败或主播未在直播", { roomId: roomId });
    }
    var flvUrl = _lx_extractFlv(data.data);
    if (!flvUrl) {
      _lx_throw("NO_STREAM", "未获取到直播流地址，主播可能未在直播", { roomId: roomId });
    }
    return [{
      cdn:        "default",
      displayName: "来秀直播",
      qualitys: [{
        roomId:       String(roomId),
        title:        "直播流",
        qn:           1000,
        url:          flvUrl,
        liveCodeType: "flv",
        liveType:     "laixiu",
        userAgent:    _LX_UA,
        headers:      { "Referer": _LX_SITE + "/" }
      }]
    }];
  });
}

// ==================== Core: search ====================

function _lx_search(keyword, page) {
  var body = "keywords=" + encodeURIComponent(keyword);

  return _lx_httpPost(_LX_SEARCH_PATH, body).then(function (resp) {
    if (resp.status >= 500) {
      _lx_throw("NETWORK", "HTTP " + resp.status, {});
    }
    var data = JSON.parse(resp.bodyText || "{}");
    if (!data || !data.success || data.retCode !== 200 || !Array.isArray(data.data)) {
      return [];
    }
    var rows = data.data.filter(function (row) {
      return Number(row.isAnchor) === 1 || row.roomPlayStream || row.urlPlayFlv;
    });

    var rooms = [];
    var seen = {};
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var mapped = _lx_normalizeRoom({
        anchorId:      row.userId,
        nickname:      row.nickName,
        livingImg:     row.coverUrl || row.avatarUrl,
        avatar:        row.avatarUrl,
        liveTitle:     row.signName || "来秀",
        sex:           Number(row.sex || 0),
        audienceNum:   Number(row.status) === 1 ? 1 : 0,
        showPK:        0,
        roomPlayStream: row.roomPlayStream,
        urlPlayFlv:    row.urlPlayFlv,
        status:        row.status
      });
      if (mapped && !seen[mapped.roomId]) {
        seen[mapped.roomId] = true;
        rooms.push(mapped);
      }
    }

    // 纯数字关键词（可能是房间号）且搜索无结果时，尝试 enterRoom
    if (rooms.length === 0 && /^\d{5,10}$/.test(keyword)) {
      return _lx_httpPost(_LX_ENTER_ROOM_PATH, "roomId=" + encodeURIComponent(keyword))
        .then(function (resp2) {
          var data2 = JSON.parse(resp2.bodyText || "{}");
          if (data2 && data2.success && data2.data) {
            var mapped2 = _lx_normalizeRoom({
              anchorId:       data2.data.anchorId,
              nickname:       data2.data.anchorNikeName,
              livingImg:      data2.data.anchorCoverUrl || data2.data.anchorAvatar,
              avatar:         data2.data.anchorAvatar,
              liveTitle:      "来秀",
              sex:            2,
              audienceNum:    Number(data2.data.openStatus) === 0 ? 1 : 0,
              showPK:         0,
              roomPlayStream: data2.data.roomPlayStream,
              openStatus:     data2.data.openStatus
            });
            if (mapped2) return [mapped2];
          }
          return [];
        })
        .catch(function () { return []; });
    }
    return rooms;
  });
}

// ==================== Core: getRoomDetail ====================

function _lx_getRoomDetail(roomId) {
  var body = "roomId=" + encodeURIComponent(roomId);
  return _lx_httpPost(_LX_ENTER_ROOM_PATH, body).then(function (resp) {
    if (resp.status >= 500) {
      _lx_throw("NETWORK", "HTTP " + resp.status, { roomId: roomId });
    }
    var data = JSON.parse(resp.bodyText || "{}");
    if (!data || !data.success || !data.data) {
      _lx_throw("NOT_FOUND", "未找到该直播间", { roomId: roomId });
    }
    var d = data.data;
    var isLive = Number(d.openStatus) === 0;
    return {
      roomId:           String(d.anchorId || roomId),
      userId:           String(d.anchorId || roomId),
      userName:         _lx_str(d.anchorNikeName),
      roomTitle:        _lx_str(d.liveTitle || "来秀直播"),
      roomCover:        _lx_str(d.anchorCoverUrl || d.anchorAvatar),
      userHeadImg:      _lx_str(d.anchorAvatar),
      liveType:         "laixiu",
      liveState:        isLive ? "1" : "0",
      liveWatchedCount: String(_lx_num(d.audienceNum, 0))
    };
  });
}

// ==================== Core: getLiveState ====================

function _lx_getLiveState(roomId) {
  var body = "roomId=" + encodeURIComponent(roomId);
  return _lx_httpPost(_LX_ENTER_ROOM_PATH, body).then(function (resp) {
    var data = JSON.parse(resp.bodyText || "{}");
    if (!data || !data.success || !data.data) {
      return { liveState: "0" };
    }
    var isLive = Number(data.data.openStatus) === 0;
    return { liveState: isLive ? "1" : "0" };
  }).catch(function () {
    return { liveState: "0" };
  });
}

// ==================== Core: resolveShare ====================

function _lx_resolveShare(shareCode) {
  var input = _lx_trim(shareCode);
  if (!input) _lx_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });

  var roomId = "";
  // 匹配 URL: https://www.imkktv.com/123456, https://m.imkktv.com/123456, imkktv.com/123456
  var m = input.match(/imkktv\.com\/(\d+)/);
  if (m && m[1]) {
    roomId = m[1];
  } else if (/^\d{5,10}$/.test(input)) {
    // 纯数字可能是房间号
    roomId = input;
  }
  if (!roomId) {
    _lx_throw("NOT_FOUND", "cannot extract roomId from shareCode", { shareCode: input });
  }

  // 通过进房 API 获取完整信息
  return _lx_getRoomDetail(roomId);
}

// ==================== Core: getDanmaku ====================

function _lx_getDanmaku(payload) {
  // 来秀弹幕需要 WebSocket + 自定义协议，暂不实现插件驱动弹幕
  return Promise.resolve({
    args:   { roomId: String((payload && payload.roomId) || "") },
    headers: null
  });
}

// ============================================================
// Plugin Export
// ============================================================

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function () {
    return _lx_getCategories();
  },

  getRooms: function (payload) {
    var id   = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _lx_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _lx_getRooms(id, page);
  },

  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _lx_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _lx_getPlayback(roomId);
  },

  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _lx_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    var page = payload && payload.page ? Number(payload.page) : 1;
    return _lx_search(keyword, page);
  },

  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _lx_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _lx_getRoomDetail(roomId);
  },

  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _lx_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _lx_getLiveState(roomId);
  },

  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _lx_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _lx_resolveShare(shareCode);
  },

  getDanmaku: function (payload) {
    return _lx_getDanmaku(payload);
  }
};