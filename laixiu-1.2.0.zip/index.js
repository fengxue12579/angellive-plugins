// ============================================================
// 来秀直播 AngelLive Plugin v1.2.0
// 直连鉴权（无代理），自动生成 imei/requestId
// 支持游客模式和登录模式
// ============================================================

// ---- 全局配置 ----
var _LX_ACCESS_TOKEN = "";
var _LX_USER_ID = "";
var _LX_IMEI = "";
var _LX_CHANNEL = "9";

// ---- 常量 ----
var _LX_WAP_API = "https://wapapi.imkktv.com";
var _LX_LIST_PATH = "/supplement/image/banner/getBannerAndLiveHot/v2";
var _LX_SEARCH_PATH = "/user/search/user";
var _LX_ENTER_ROOM_PATH = "/liveroom/userEnterRoomNew";
var _LX_SITE_URL = "https://www.imkktv.com";
var _LX_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1";
var _LX_SECRET_KEY = "kk792f28d6ff1f34ec702c08626d454b39pro";
var _LX_PLATFORM_ID = "laixiu";

// ---- 工具函数 ----
function _lx_str(v, def) { return v != null ? String(v) : (def || ""); }
function _lx_num(v, def) { var n = Number(v); return isNaN(n) ? (def || 0) : n; }
function _lx_uuid() {
  return 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'.replace(/[x]/g, function (c) {
    return (Math.random() * 16 | 0).toString(16);
  });
}

// ---- MD5（内置实现） ----
var _lx_md5 = (function () {
  function add32(a, b) { return (a + b) & 0xFFFFFFFF; }
  function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
  function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
  function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
  function md5cycle(x, k) {
    var a=x[0],b=x[1],c=x[2],d=x[3];
    a=ff(a,b,c,d,k[0],7,-680876936);d=ff(d,a,b,c,k[1],12,-389564586);c=ff(c,d,a,b,k[2],17,606105819);b=ff(b,c,d,a,k[3],22,-1044525330);
    a=ff(a,b,c,d,k[4],7,-176418897);d=ff(d,a,b,c,k[5],12,1200080426);c=ff(c,d,a,b,k[6],17,-1473231341);b=ff(b,c,d,a,k[7],22,-45705983);
    a=ff(a,b,c,d,k[8],7,1770035416);d=ff(d,a,b,c,k[9],12,-1958414417);c=ff(c,d,a,b,k[10],17,-42063);b=ff(b,c,d,a,k[11],22,-1990404162);
    a=ff(a,b,c,d,k[12],7,1804603682);d=ff(d,a,b,c,k[13],12,-40341101);c=ff(c,d,a,b,k[14],17,-1502002290);b=ff(b,c,d,a,k[15],22,1236535329);
    a=gg(a,b,c,d,k[1],5,-165796510);d=gg(d,a,b,c,k[6],9,-1069501632);c=gg(c,d,a,b,k[11],14,643717713);b=gg(b,c,d,a,k[0],20,-373897302);
    a=gg(a,b,c,d,k[5],5,-701558691);d=gg(d,a,b,c,k[10],9,38016083);c=gg(c,d,a,b,k[15],14,-660478335);b=gg(b,c,d,a,k[4],20,-405537848);
    a=gg(a,b,c,d,k[9],5,568446438);d=gg(d,a,b,c,k[14],9,-1019803690);c=gg(c,d,a,b,k[3],14,-187363961);b=gg(b,c,d,a,k[8],20,1163531501);
    a=gg(a,b,c,d,k[13],5,-1444681467);d=gg(d,a,b,c,k[2],9,-51403784);c=gg(c,d,a,b,k[7],14,1735328473);b=gg(b,c,d,a,k[12],20,-1926607734);
    a=hh(a,b,c,d,k[5],4,-378558);d=hh(d,a,b,c,k[8],11,-2022574463);c=hh(c,d,a,b,k[11],16,1839030562);b=hh(b,c,d,a,k[14],23,-35309556);
    a=hh(a,b,c,d,k[1],4,-1530992060);d=hh(d,a,b,c,k[4],11,1272893353);c=hh(c,d,a,b,k[7],16,-155497632);b=hh(b,c,d,a,k[10],23,-1094730640);
    a=hh(a,b,c,d,k[13],4,681279174);d=hh(d,a,b,c,k[0],11,-358537222);c=hh(c,d,a,b,k[3],16,-722521979);b=hh(b,c,d,a,k[6],23,76029189);
    a=hh(a,b,c,d,k[9],4,-640364487);d=hh(d,a,b,c,k[12],11,-421815835);c=hh(c,d,a,b,k[15],16,530742520);b=hh(b,c,d,a,k[2],23,-995338651);
    a=ii(a,b,c,d,k[0],6,-198630844);d=ii(d,a,b,c,k[7],10,1126891415);c=ii(c,d,a,b,k[14],15,-1416354905);b=ii(b,c,d,a,k[5],21,-57434055);
    a=ii(a,b,c,d,k[12],6,1700485571);d=ii(d,a,b,c,k[3],10,-1894986606);c=ii(c,d,a,b,k[10],15,-1051523);b=ii(b,c,d,a,k[1],21,-2054922799);
    a=ii(a,b,c,d,k[8],6,1873313359);d=ii(d,a,b,c,k[15],10,-30611744);c=ii(c,d,a,b,k[6],15,-1560198380);b=ii(b,c,d,a,k[13],21,1309151649);
    a=ii(a,b,c,d,k[4],6,-145523070);d=ii(d,a,b,c,k[11],10,-1120210379);c=ii(c,d,a,b,k[2],15,718787259);b=ii(b,c,d,a,k[9],21,-343485551);
    x[0]=add32(a,x[0]);x[1]=add32(b,x[1]);x[2]=add32(c,x[2]);x[3]=add32(d,x[3]);
  }
  function md5blk(s){var b=[];for(var i=0;i<64;i+=4)b[i>>2]=s.charCodeAt(i)+(s.charCodeAt(i+1)<<8)+(s.charCodeAt(i+2)<<16)+(s.charCodeAt(i+3)<<24);return b;}
  var hc='0123456789abcdef'.split('');
  function rh(n){var s='',j=0;for(;j<4;j++)s+=hc[(n>>(j*8+4))&0xF]+hc[(n>>(j*8))&0xF];return s;}
  function hex(x){for(var i=0;i<x.length;i++)x[i]=rh(x[i]);return x.join('');}
  function toU(s){var u=[];for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)u.push(c);else if(c<2048)u.push(192|(c>>6),128|(c&63));else u.push(224|(c>>12),128|((c>>6)&63),128|(c&63));}return String.fromCharCode.apply(null,u);}
  return function(s){s=toU(s);var n=s.length,st=[1732584193,-271733879,-1732584194,271733878],i;for(i=64;i<=n;i+=64)md5cycle(st,md5blk(s.substring(i-64,i)));s=s.substring(i-64);var t=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];for(i=0;i<s.length;i++)t[i>>2]|=s.charCodeAt(i)<<((i%4)<<3);t[i>>2]|=0x80<<((i%4)<<3);if(i>55){md5cycle(st,t);for(i=0;i<16;i++)t[i]=0;}t[14]=n*8;md5cycle(st,t);return hex(st);};
})();

// ---- 错误处理 ----
function _lx_throw(code, message, ctx) {
  var err = new Error(message);
  err.name = "LaixiuError";
  err.code = code;
  err.ctx = ctx || {};
  throw err;
}

// ---- Cookie 读取工具（StripChat 插件风格） ----
function _lx_readCookieHeader() {
  if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") {
    return _lx_str(Host.session.getCookieHeader(_LX_PLATFORM_ID));
  }
  return "";
}
function _lx_readCookieValue(hdr, name) {
  if (!hdr) return "";
  var parts = hdr.split(";");
  for (var i = 0; i < parts.length; i++) {
    var kv = parts[i].trim().split("=");
    if (kv[0].trim() === name) return decodeURIComponent(kv.slice(1).join("=").trim());
  }
  return "";
}

// ---- 自动生成鉴权 Header ----
function _lx_buildHeaders() {
  if (!_LX_IMEI) _LX_IMEI = _lx_uuid();
  var ts = String(Date.now());
  var userId = _lx_str(_LX_USER_ID);
  var requestId = _lx_md5("web" + _LX_IMEI + userId + ts + _LX_SECRET_KEY);
  return {
    "User-Agent": _LX_UA,
    "Referer": _LX_SITE_URL + "/",
    "platform": "WEB",
    "timestamp": ts,
    "version": "1.0.0",
    "versionCode": "10003",
    "imei": _LX_IMEI,
    "os": "web",
    "mobileModel": "web",
    "loginType": "2",
    "channel": _LX_CHANNEL,
    "requestId": requestId,
    "accessToken": _lx_str(_LX_ACCESS_TOKEN),
    "userId": userId,
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
  };
}

// ---- HTTP 请求（AngelLive Host API，模仿StripChat插件格式） ----
function _lx_httpGet(url, timeout) {
  return Host.http.request({
    platformId: _LX_PLATFORM_ID, authMode: "platform_cookie",
    request: { url: url, method: "GET", headers: _lx_buildHeaders(), timeout: timeout || 20 }
  }).then(function (r) {
    if (r.status >= 500) throw new Error("HTTP " + r.status);
    return r;
  });
}

function _lx_httpPost(url, body, timeout) {
  return Host.http.request({
    platformId: _LX_PLATFORM_ID, authMode: "platform_cookie",
    request: { url: url, method: "POST", headers: _lx_buildHeaders(), body: body, timeout: timeout || 20 }
  }).then(function (r) {
    if (r.status >= 500) throw new Error("HTTP " + r.status);
    return r;
  });
}

// ---- 提取流地址 ----
function _lx_extractFlv(item) {
  var psi = (item && item.roomPlayStream && item.roomPlayStream.playStreamInfo) || {};
  return psi.urlPlayAcc || psi.urlPlayFlv || psi.urlPlayAccMix || item.urlPlayFlv || item.urlPlayHls || null;
}

// ---- 分区过滤 ----
function _lx_genreFilter(item, genreId) {
  if (!genreId || genreId === "all") return true;
  var sex = _lx_num(item.sex, 0);
  var showPK = _lx_num(item.showPK, 0);
  switch (genreId) {
    case "female_dance": return sex === 2 && showPK === 0;
    case "female_pk": return sex === 2 && showPK === 1;
    case "female": return sex === 2;
    case "male": return sex === 1;
    default: return true;
  }
}

// ---- API: 获取直播列表 ----
function _lx_fetchPage(page) {
  var url = _LX_WAP_API + _LX_LIST_PATH + "?currentPage=" + page;
  return _lx_httpGet(url, 20).then(function (res) {
    var data;
    try { data = JSON.parse(res.bodyText); } catch (e) { data = {}; }
    if (!data || !data.success) throw new Error(data && data.retMsg ? data.retMsg : "API 失败");
    return (data.data && data.data.resLiveHotDtoList) ? data.data.resLiveHotDtoList : [];
  });
}

// ---- API: 进入房间 ----
function _lx_enterRoom(roomId) {
  var url = _LX_WAP_API + _LX_ENTER_ROOM_PATH;
  var body = "roomId=" + encodeURIComponent(roomId);
  return _lx_httpPost(url, body, 20).then(function (res) {
    var data;
    try { data = JSON.parse(res.bodyText); } catch (e) { data = {}; }
    if (!data || !data.success || data.retCode !== 200 || !data.data) return null;
    return data.data;
  });
}

// ---- API: 搜索用户 ----
function _lx_searchUsers(keyword) {
  var url = _LX_WAP_API + _LX_SEARCH_PATH;
  var body = "keywords=" + encodeURIComponent(keyword);
  return _lx_httpPost(url, body, 20).then(function (res) {
    var data;
    try { data = JSON.parse(res.bodyText); } catch (e) { data = {}; }
    if (!data || !data.success || data.retCode !== 200 || !Array.isArray(data.data)) return [];
    return data.data.filter(function (row) {
      return Number(row.isAnchor) === 1 || row.roomPlayStream || row.urlPlayFlv;
    });
  });
}

// ---- 数据转换: 原始数据 -> Room ----
function _lx_modelToRoom(raw) {
  var anchorId = _lx_str(raw.anchorId || raw.userId || "");
  if (!anchorId) return null;
  var nick = _lx_str(raw.nickname || raw.nickName || "");
  var cover = _lx_str(raw.livingImg || raw.avatar || raw.coverUrl || raw.avatarUrl || "");
  var audience = _lx_num(raw.audienceNum || raw.onlineUsers || 0);
  var isLive = audience > 0 || Number(raw.status) === 1 || Number(raw.openStatus) === 0;
  return {
    roomId: anchorId, userId: anchorId,
    userName: nick || "未知主播",
    roomTitle: nick || "未知主播",
    roomCover: cover,
    userHeadImg: cover,
    liveType: "laixiu",
    liveState: isLive ? "1" : "0",
    liveWatchedCount: String(audience),
  };
}

// ---- 从 Cookie 同步登录态 ----
function _lx_syncCredential() {
  var hdr = _lx_readCookieHeader();
  if (!hdr) return;
  var token = _lx_readCookieValue(hdr, "token");
  var userId = _lx_readCookieValue(hdr, "kxUserId");
  if (token) _LX_ACCESS_TOKEN = token;
  if (userId) _LX_USER_ID = userId;
}

// ============================================================
// AngelLive 插件导出函数
// ============================================================

function getCategories(payload) {
  _lx_syncCredential();
  return Promise.resolve([
    { id: "all", parentId: "", title: "全部直播", icon: "", biz: "all", subList: [
      { id: "all", parentId: "all", title: "全部直播", icon: "", biz: "all" },
      { id: "female_dance", parentId: "all", title: "舞蹈", icon: "", biz: "female_dance" },
      { id: "female_pk", parentId: "all", title: "PK", icon: "", biz: "female_pk" },
      { id: "female", parentId: "all", title: "颜值", icon: "", biz: "female" },
      { id: "male", parentId: "all", title: "男主播", icon: "", biz: "male" },
      { id: "hot", parentId: "all", title: "人气榜", icon: "", biz: "hot" }
    ]}
  ]);
}

function getRooms(payload) {
  _lx_syncCredential();
  var cateId = _lx_str(payload && payload.categoryId, "all");
  var page = _lx_num(payload && payload.page, 1);
  return _lx_fetchPage(page).then(function (rooms) {
    if (cateId && cateId !== "all") {
      rooms = rooms.filter(function (r) { return _lx_genreFilter(r, cateId); });
    }
    if (cateId === "hot") {
      rooms = rooms.slice().sort(function (a, b) {
        return (_lx_num(b.audienceNum || b.onlineUsers) - _lx_num(a.audienceNum || a.onlineUsers));
      });
    }
    var results = [];
    for (var i = 0; i < rooms.length; i++) {
      var item = _lx_modelToRoom(rooms[i]);
      if (item) results.push(item);
    }
    return results;
  });
}

function getPlayback(payload) {
  _lx_syncCredential();
  var roomId = _lx_str(payload.roomId || payload.id || "");
  if (!roomId) _lx_throw("INVALID_ARGS", "missing roomId");

  return _lx_enterRoom(roomId).then(function (data) {
    var flvUrl = "";
    if (data) flvUrl = _lx_extractFlv(data);
    if (!flvUrl) _lx_throw("STREAM_ERROR", "未获取到直播流地址，主播可能未在直播");

    return [{
      cdn: "laixiu",
      displayName: "来秀直播",
      qualitys: [{
        roomId: roomId,
        title: "原画",
        qn: 9999,
        url: flvUrl,
        liveCodeType: "flv",
        liveType: "laixiu",
        userAgent: _LX_UA,
        headers: { "Referer": _LX_SITE_URL + "/" },
        playbackHints: { streamFormat: "flv", selectionBehavior: "direct" }
      }]
    }];
  });
}

function getRoomDetail(payload) {
  _lx_syncCredential();
  var roomId = _lx_str(payload.roomId || payload.id || "");
  if (!roomId) _lx_throw("INVALID_ARGS", "missing roomId");
  return Promise.resolve({
    roomId: roomId, userId: roomId,
    userName: roomId, roomTitle: roomId,
    roomCover: "", userHeadImg: "",
    liveType: "laixiu", liveState: "1",
    liveWatchedCount: "0",
  });
}

function refreshPlayback(payload) {
  return getPlayback(payload);
}

function search(payload) {
  _lx_syncCredential();
  var keyword = _lx_str(payload.keyword || "", "").trim();
  if (!keyword) return Promise.resolve([]);
  var results = [];
  var seen = {};
  function pushItem(item) {
    if (!item || !item.roomId || seen[item.roomId]) return;
    seen[item.roomId] = true;
    results.push(item);
  }

  return _lx_searchUsers(keyword).then(function (rows) {
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      pushItem(_lx_modelToRoom({
        anchorId: row.userId, nickname: row.nickName,
        livingImg: row.coverUrl || row.avatarUrl, avatar: row.avatarUrl,
        liveTitle: row.signName || "来秀", sex: Number(row.sex || 0),
        audienceNum: Number(row.status) === 1 ? 1 : 0, showPK: 0,
        roomPlayStream: row.roomPlayStream, urlPlayFlv: row.urlPlayFlv, status: row.status,
      }));
    }
    if (/^\d{5,10}$/.test(keyword) && results.length === 0) {
      return _lx_enterRoom(keyword).then(function (data) {
        if (data) {
          pushItem(_lx_modelToRoom({
            anchorId: data.anchorId, nickname: data.anchorNikeName,
            livingImg: data.anchorCoverUrl || data.anchorAvatar, avatar: data.anchorAvatar,
            liveTitle: "来秀", sex: 2, audienceNum: Number(data.openStatus) === 0 ? 1 : 0,
            showPK: 0, roomPlayStream: data.roomPlayStream, openStatus: data.openStatus,
          }));
        }
        return results;
      });
    }
    return results;
  });
}

function resolveShare(payload) {
  _lx_syncCredential();
  var input = _lx_str(payload.shareCode || "").trim();
  if (!input) _lx_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });
  var roomId = "";
  var m = input.match(/imkktv\.com\/(\d+)/);
  if (m && m[1]) roomId = m[1];
  else if (/^\d{5,10}$/.test(input)) roomId = input;
  else if (input.indexOf("laixiu:") === 0) roomId = input.replace("laixiu:", "");
  if (!roomId) _lx_throw("NOT_FOUND", "cannot extract roomId", { shareCode: input });
  return Promise.resolve({
    roomId: roomId, userId: roomId,
    userName: roomId, roomTitle: roomId,
    roomCover: "", userHeadImg: "",
    liveType: "laixiu", liveState: "1",
    liveWatchedCount: "0",
  });
}

// ---- 登录相关方法（StripChat 插件格式） ----
function clearCredential() { return Promise.resolve(); }
function getCredentialStatus() {
  var hdr = _lx_readCookieHeader();
  var token = _lx_readCookieValue(hdr || "", "token");
  var uid = _lx_readCookieValue(hdr || "", "kxUserId");
  return Promise.resolve({ valid: !!(token && uid), userId: uid, msg: token && uid ? "已登录" : "未登录（游客模式可用）" });
}
function validateCredential() { return getCredentialStatus(); }

// ============================================================
// 模块导出
// ============================================================
module.exports = {
  getCategories: getCategories,
  getRooms: getRooms,
  getPlayback: getPlayback,
  getRoomDetail: getRoomDetail,
  refreshPlayback: refreshPlayback,
  search: search,
  resolveShare: resolveShare,
  clearCredential: clearCredential,
  getCredentialStatus: getCredentialStatus,
  validateCredential: validateCredential,
};