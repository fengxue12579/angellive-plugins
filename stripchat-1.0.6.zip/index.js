/* Stripchat LiveParse Plugin v1.0.0
 * 基于 py_stripchat.py (Hawk版) 逐行转换
 * 4分类: 女主播/情侣/男主播/跨性别
 */

var SC_PLUGIN_ID = "stripchat";
var SC_LIVE_TYPE = "20";
var SC_API_BASE = "https://stripchat.com/api/front";
var SC_SITE = "https://stripchat.com";
var SC_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var SC_HLS_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0";
var SC_DOPPIOCDN = "doppiocdn.org";

/* ---------- 基础工具 ---------- */

function scThrow(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw new Error(String(message || "unknown error"));
}

function scStr(v) { return v === undefined || v === null ? "" : String(v); }
function scInt(v, fb) { var n = parseInt(v, 10); return isNaN(n) ? fb : n; }

function scRuntimePayload(p) {
  return (p && typeof p === "object") ? p : {};
}

async function scHttpRequest(opts, errCode) {
  try {
    var req = {
      url: opts.url,
      method: opts.method || "GET",
      headers: opts.headers || {},
      timeout: opts.timeout || 20
    };
    if (opts.body !== undefined) req.body = opts.body;
    var res = await Host.http.request({
      authMode: "none",
      followRedirects: false,
      request: req
    });
    return res;
  } catch (e) {
    scThrow(errCode || "NETWORK", "网络请求失败", { url: opts.url });
  }
}

async function scGetText(url, headers) {
  var res = await scHttpRequest({
    url: url,
    method: "GET",
    headers: Object.assign(
      { "User-Agent": SC_UA, "Referer": SC_SITE + "/", "Accept": "application/json, text/plain, */*" },
      headers || {}
    )
  }, "NETWORK");
  var body = res && (res.bodyText !== undefined ? res.bodyText : res.body);
  return scStr(body);
}

async function scGetJson(url, headers) {
  var text = await scGetText(url, headers);
  try { return JSON.parse(text || "{}"); } catch (e) { return {}; }
}

/* ---------- 国旗/状态 ---------- */

function scCountryFlag(code) {
  code = scStr(code).toUpperCase();
  if (!/^[A-Z]{2}$/.test(code)) return "";
  var out = "";
  for (var i = 0; i < 2; i++) {
    out += String.fromCodePoint(code.charCodeAt(i) - 65 + 0x1F1E6);
  }
  return out;
}

function scParseStatus(status, viewers) {
  status = scStr(status).toLowerCase();
  var st;
  if (status === "public") st = "🔴直播中";
  else if (status === "groupshow") st = "🎫门票房";
  else if (status === "ticket") st = "🎫购票房";
  else if (status === "off") st = "⚫已下播";
  else st = "🎫" + status;
  if (viewers) st += " 👤" + viewers + "人";
  return st;
}

function scLiveState(status) {
  status = scStr(status).toLowerCase();
  if (status === "public") return "1";
  if (status === "off") return "0";
  return "2";
}

/* ---------- 数据映射 ---------- */

function scModelToRoom(raw) {
  if (!raw || typeof raw !== "object") return null;
  var username = scStr(raw.username).trim();
  var mid = scStr(raw.id).trim();
  var stream = scStr(raw.streamName).trim();
  if (!username && !mid) return null;

  var status = scStr(raw.status || "off").toLowerCase();
  var viewers = raw.viewersCount || 0;
  var country = scStr(raw.country || "").toUpperCase();
  var flag = scCountryFlag(country);

  var snapTs = raw.snapshotTimestamp || "";
  var pic = "";
  if (mid && snapTs) {
    pic = "https://img." + SC_DOPPIOCDN + "/snapshot/" + mid + "/" + snapTs;
  }

  var roomId = stream && /^\d+$/.test(stream) ? stream : mid;
  if (!roomId) roomId = username;

  return {
    userName: flag ? flag + username : username,
    roomTitle: scParseStatus(status, viewers),
    roomCover: pic,
    userHeadImg: pic,
    userId: mid || username,
    roomId: roomId,
    liveState: scLiveState(status),
    liveWatchedCount: viewers,
    _username: username,
    _status: status
  };
}

/* ---------- 分类定义 (与 Hawk 版一致) ---------- */

var SC_CLASSES = [
  { id: "girls", title: "女主播" },
  { id: "couples", title: "情侣" },
  { id: "men", title: "男主播" },
  { id: "trans", title: "跨性别" }
];

var SC_TAGS = [
  { v: "autoTagNew", n: "新主播" },
  { v: "recommended", n: "推荐" },
  { v: "fuckMachine", n: "炮机" },
  { v: "ageTeen", n: "青年" },
  { v: "autoTagVr", n: "VR" },
  { v: "ethnicityAsian", n: "亚洲人" },
  { v: "tagLanguageChinese", n: "🇨🇳中国" },
  { v: "tagLanguageJapanese", n: "🇯🇵日本" },
  { v: "tagLanguageKorean", n: "🇰🇷韩国" },
  { v: "tagLanguageVietnamese", n: "🇻🇳越南" },
  { v: "tagLanguageUkrainian", n: "🇺🇦乌克兰" },
  { v: "tagLanguageRussianSpeaking", n: "🇷🇺俄罗斯" },
  { v: "tagLanguageUSModels", n: "🇺🇸美国" },
  { v: "tagLanguageColombian", n: "🇨🇴哥伦比亚" },
  { v: "tagLanguageGermanSpeaking", n: "🇩🇪德国" },
  { v: "tagLanguageFrench", n: "🇫🇷法国" },
  { v: "tagLanguageUKModels", n: "🇬🇧英国" },
  { v: "tagLanguageCanadian", n: "🇨🇦加拿大" },
  { v: "tagLanguageMexican", n: "🇲🇽墨西哥" },
  { v: "ethnicityIndian", n: "🇮🇳印度" },
  { v: "tagLanguageVenezuelan", n: "🇻🇪委内瑞拉" },
  { v: "tagLanguageRomanian", n: "🇷🇴罗马尼亚" },
  { v: "tagLanguageAfrican", n: "🌍非洲" },
  { v: "tagLanguageSpanishSpeaking", n: "🇪🇸西班牙" },
  { v: "ethnicityMiddleEastern", n: "🇸🇦🇦🇪阿拉伯" },
  { v: "tagLanguageKenyan", n: "🇰🇪肯尼亚" },
  { v: "tagLanguageSouthAfrican", n: "🇿🇦南非" },
  { v: "tagLanguageBrazilian", n: "🇧🇷巴西" },
  { v: "tagLanguageThai", n: "🇹🇭泰国" },
  { v: "tagLanguageItalian", n: "🇮🇹意大利" },
  { v: "ethnicityWhite", n: "白人" },
  { v: "ethnicityLatino", n: "拉丁" },
  { v: "ethnicityMultiracial", n: "混血" },
  { v: "ethnicityEbony", n: "黑人" },
  { v: "ageYoung", n: "鲜嫩青年22+" },
  { v: "subcultureStudent", n: "学生" },
  { v: "doBlowjob", n: "口交" },
  { v: "doDeepThroat", n: "深喉" },
  { v: "doFootFetish", n: "恋足" },
  { v: "autoTagInteractiveToy", n: "互动玩具" },
  { v: "doMasturbation", n: "自慰" },
  { v: "doAnal", n: "肛交" },
  { v: "doSquirt", n: "潮吹" },
  { v: "doDoggyStyle", n: "狗式" },
  { v: "doCosplay", n: "Cosplay" },
  { v: "doRolePlay", n: "RolePlay" }
];

var SC_TAGS_MEN = [
  { v: "sexGayCouples", n: "情侣" },
  { v: "orientationStraight", n: "直男" }
];

/* ---------- m3u8 解析 ---------- */

function scJoinUrl(base, rel) {
  if (!rel) return "";
  if (/^https?:\/\//i.test(rel)) return rel;
  var b = scStr(base).replace(/\/+$/, "");
  if (rel.charAt(0) === "/") {
    var m = b.match(/^(https?:\/\/[^\/]+)/i);
    return (m ? m[1] : b) + rel;
  }
  return b + "/" + rel;
}

function scExtractShards(variants) {
  var shards = {};
  for (var i = 0; i < variants.length; i++) {
    var m = scStr(variants[i].url).match(/b-hls-(\d+)/i);
    if (m) shards[m[1]] = true;
  }
  var keys = Object.keys(shards);
  if (keys.length === 0) {
    return ["10", "11", "12", "13", "14", "15", "16", "20", "24", "25", "30", "32"];
  }
  return keys;
}

var SC_GROW_SUFFIXES = ["", "_source", "_orig", "_1600p", "_1080p", "_720p", "_480p", "_360p", "_240p"];

async function scIsPlayable(url) {
  try {
    var text = await scGetText(url, {
      "User-Agent": SC_HLS_UA,
      "Referer": SC_SITE + "/"
    });
    if (!text || text.length < 12) return false;
    if (text.indexOf("#EXT-X-MOUFLON-ADVERT") >= 0) return false;
    if (text.indexOf("cpa/v2/") >= 0) return false;
    if (text.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") >= 0) return false;
    return text.indexOf("#EXTINF") >= 0;
  } catch (e) {
    return false;
  }
}

function scParseVariants(text, baseUrl) {
  var lines = scStr(text).split("\n");
  var out = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    var bwM = line.match(/BANDWIDTH=(\d+)/i);
    var nameM = line.match(/NAME="([^"]+)"/i);
    var resM = line.match(/RESOLUTION=(\d+)x(\d+)/i);
    var next = (lines[i + 1] || "").trim();
    if (!next || next.charAt(0) === "#") continue;
    var name = nameM ? nameM[1] : "";
    if (/blurred/i.test(name)) continue;
    out.push({
      bandwidth: bwM ? parseInt(bwM[1], 10) : 0,
      name: name,
      height: resM ? parseInt(resM[2], 10) : 0,
      url: scJoinUrl(baseUrl, next)
    });
  }
  return out;
}

function scVariantScore(v) {
  var h = v.height || 0;
  var n = scStr(v.name).toLowerCase();
  if (n === "source" || n === "orig" || n === "original") h = Math.max(h, 2160);
  return h * 1e9 + (v.bandwidth || 0);
}

function scQualityTitle(v) {
  var n = scStr(v.name).toLowerCase();
  if (n === "source" || n === "orig" || n === "original") return "原画";
  var h = v.height || 0;
  if (h >= 1600) return "原画";
  if (h >= 1000) return "1080p";
  if (h >= 700) return "720p";
  if (h >= 460) return "480p";
  if (h > 0) return h + "p";
  if (/1080/.test(n)) return "1080p";
  if (/720/.test(n)) return "720p";
  if (/480/.test(n)) return "480p";
  return n || "自动";
}

async function scResolveStreamId(username) {
  username = scStr(username).trim().replace(/^\/+|\/+$/g, "").split("/").pop();
  if (/^\d+$/.test(username)) return username;
  try {
    var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(username));
    var id = data && (data.id || (data.model && data.model.id));
    if (id && /^\d+$/.test(String(id))) return String(id);
  } catch (e) {}
  return "";
}

/* ---------- 插件主体 ---------- */

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async getCategories(payload) {
    return SC_CLASSES.map(function (c) {
      var tags = c.id === "men" ? SC_TAGS_MEN.concat(SC_TAGS) : SC_TAGS;
      return {
        id: c.id,
        title: c.title,
        icon: "",
        biz: "",
        subList: tags.map(function (t) {
          return { id: t.v, parentId: c.id, title: t.n, icon: "", biz: t.v };
        })
      };
    });
  },

  async getRooms(payload) {
    var p = scRuntimePayload(payload);
    var categoryId = scStr(p.id) || "girls";
    var validIds = SC_CLASSES.map(function (c) { return c.id; });
    if (validIds.indexOf(categoryId) < 0) categoryId = "girls";
    var page = Math.max(1, scInt(p.page, 1));
    var pageSize = Math.max(1, Math.min(100, scInt(p.pageSize, 50)));
    var tag = scStr(p.tag || p.biz);
    var offset = (page - 1) * pageSize;
    var ts = Date.now();

    var url = SC_API_BASE + "/v2/models?primaryTag=" + encodeURIComponent(categoryId) +
      "&limit=" + (pageSize + 1) + "&offset=" + offset + "&sortBy=stripRanking&_t=" + ts;
    if (tag) {
      url += "&filterGroupTags=" + encodeURIComponent('[["' + tag + '"]]');
    }

    var data = await scGetJson(url);
    var models = [];
    if (data && Array.isArray(data.models)) models = data.models;
    else if (data && Array.isArray(data.blocks)) {
      data.blocks.forEach(function (b) {
        if (b && Array.isArray(b.models)) models = models.concat(b.models);
      });
    }

    var rooms = [];
    for (var i = 0; i < Math.min(models.length, pageSize); i++) {
      var r = scModelToRoom(models[i]);
      if (r) rooms.push(r);
    }
    return rooms;
  },

  async getPlayback(payload) {
    var p = scRuntimePayload(payload);
    var rawId = scStr(p.roomId || p.userId).trim();
    if (!rawId) scThrow("INVALID_ARGS", "roomId is required", { field: "roomId" });

    var streamId = await scResolveStreamId(rawId);
    if (!streamId) scThrow("NOT_FOUND", "无法解析主播流ID", { roomId: rawId });

    var masters = [
      "https://edge-hls.doppiocdn.org/hls/" + streamId + "/master/" + streamId + "_auto.m3u8",
      "https://edge-hls.doppiocdn.com/hls/" + streamId + "/master/" + streamId + "_auto.m3u8",
      "https://edge-hls.growcdnssedge.com/hls/" + streamId + "/master/" + streamId + "_auto.m3u8"
    ];

    var seen = {};
    for (var mi = 0; mi < masters.length; mi++) {
      var text = await scGetText(masters[mi], {
        "User-Agent": SC_HLS_UA, "Referer": SC_SITE + "/"
      });
      var t = scStr(text).trim();
      if (!t || t.indexOf("#EXTM3U") !== 0) continue;
      if (t.indexOf("#EXT-X-MOUFLON-ADVERT") >= 0 && t.indexOf("#EXT-X-STREAM-INF") < 0) continue;
      if (t.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") >= 0) continue;
      var base = masters[mi].substring(0, masters[mi].lastIndexOf("/") + 1);
      var variants = scParseVariants(t, base);
      for (var vi = 0; vi < variants.length; vi++) {
        var v = variants[vi];
        if (!v.url) continue;
        var path = v.url.replace(/^https?:\/\/[^\/]+/i, "");
        var key = v.height + "|" + path;
        if (!seen[key] || scVariantScore(v) > scVariantScore(seen[key])) seen[key] = v;
      }
      if (Object.keys(seen).length > 0) break;
    }

    var sorted = Object.keys(seen).map(function (k) { return seen[k]; })
      .sort(function (a, b) { return scVariantScore(b) - scVariantScore(a); });

    // 分片直连：为每个清晰度找可用 URL
    var shards = scExtractShards(sorted);
    var qualityDefs = [
      { title: "原画", suffixes: ["_source", "_orig", ""] },
      { title: "1080p", suffixes: ["_1080p"] },
      { title: "720p", suffixes: ["_720p"] },
      { title: "480p", suffixes: ["_480p"] },
      { title: "360p", suffixes: ["_360p"] },
      { title: "240p", suffixes: ["_240p"] }
    ];
    var directUrls = [];
    var shard = shards[0] || "22";
    for (var qi2 = 0; qi2 < qualityDefs.length; qi2++) {
      var qd = qualityDefs[qi2];
      var found = null;
      // 先试 growcdn
      for (var gi = 0; gi < qd.suffixes.length && !found; gi++) {
        var gurl = "https://media-hls.growcdnssedge.com/b-hls-" + shard + "/" + streamId + "/" + streamId + qd.suffixes[gi] + ".m3u8";
        if (await scIsPlayable(gurl)) found = gurl;
      }
      // 再试 doppiocdn
      for (var di = 0; di < qd.suffixes.length && !found; di++) {
        var durl = "https://media-hls.doppiocdn.org/b-hls-" + shard + "/" + streamId + "/" + streamId + qd.suffixes[di] + ".m3u8";
        if (await scIsPlayable(durl)) found = durl;
      }
      if (found) directUrls.push({ url: found, title: qd.title });
    }

    var finalVariants = directUrls.length > 0 ? directUrls : sorted;

    var headers = { "Referer": SC_SITE + "/" };
    var qualitys = [];
    var usedTitles = {};

    for (var qi = 0; qi < finalVariants.length; qi++) {
      var vv = finalVariants[qi];
      var title = vv.title || scQualityTitle(vv);
      if (usedTitles[title]) title = title + " " + (vv.height ? vv.height + "p" : vv.bandwidth);
      usedTitles[title] = true;
      qualitys.push({
        roomId: streamId,
        title: title,
        qn: vv.height || 0,
        url: vv.url,
        liveCodeType: "m3u8",
        liveType: SC_LIVE_TYPE,
        userAgent: SC_HLS_UA,
        headers: headers
      });
    }

    if (qualitys.length === 0) scThrow("NOT_FOUND", "无可用播放流", { roomId: rawId });

    qualitys.push({
      roomId: streamId,
      title: "自动",
      qn: -1,
      url: masters[0],
      liveCodeType: "m3u8",
      liveType: SC_LIVE_TYPE,
      userAgent: SC_HLS_UA,
      headers: headers
    });

    return [{ cdn: "default", qualitys: qualitys }];
  },

  async search(payload) {
    var p = scRuntimePayload(payload);
    var keyword = scStr(p.keyword).trim();
    if (!keyword) scThrow("INVALID_ARGS", "keyword is required", { field: "keyword" });
    var ts = Date.now();
    var seen = {};
    var out = [];

    var tags = ["girls", "couples", "men", "trans"];
    for (var ti = 0; ti < tags.length; ti++) {
      try {
        var url = SC_API_BASE + "/v4/models/search/group/username?query=" +
          encodeURIComponent(keyword) + "&limit=50&primaryTag=" + tags[ti] + "&_t=" + ts;
        var data = await scGetJson(url);
        var models = (data && Array.isArray(data.models)) ? data.models : [];
        for (var i = 0; i < models.length; i++) {
          var r = scModelToRoom(models[i]);
          if (r && !seen[r.roomId]) { seen[r.roomId] = true; out.push(r); }
        }
      } catch (e) {}
    }
    return out;
  },

  async getRoomDetail(payload) {
    var p = scRuntimePayload(payload);
    var rawId = scStr(p.roomId || p.userId).trim();
    if (!rawId) scThrow("INVALID_ARGS", "roomId is required", { field: "roomId" });
    var username = rawId.split("/").pop();
    if (/^\d+$/.test(username)) {
      return {
        userName: username, roomTitle: "", roomCover: "",
        userHeadImg: "", userId: username, roomId: username, liveState: "1"
      };
    }
    try {
      var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(username));
      var model = data.model || data;
      var r = scModelToRoom(model);
      if (r) return r;
    } catch (e) {}
    scThrow("NOT_FOUND", "房间不存在", { roomId: rawId });
  },

  async getLiveState(payload) {
    var p = scRuntimePayload(payload);
    var rawId = scStr(p.roomId || p.userId).trim();
    if (!rawId) return { liveState: "3" };
    try {
      var detail = await this.getRoomDetail(payload);
      return { liveState: detail.liveState || "1" };
    } catch (e) {
      return { liveState: "0" };
    }
  },

  async resolveShare(payload) {
    var p = scRuntimePayload(payload);
    var text = scStr(p.shareCode || p.shareUrl || p.url).trim();
    if (!text) scThrow("INVALID_ARGS", "shareCode is required", {});
    var m = text.match(/stripchat\.com\/([A-Za-z0-9_]+)/i);
    var username = m ? m[1] : text.split("/").pop().split("?")[0];
    if (!username) scThrow("INVALID_ARGS", "无法解析分享链接", {});
    return await this.getRoomDetail({ roomId: username });
  },

  async getDanmaku(payload) {
    return { args: {}, headers: null };
  }
};
