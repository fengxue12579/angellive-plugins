// ============================================================
// 小心心直播 AngelLive Plugin v1.0.0
// 说明：
// - 列表/分类/详情来自小心心 H5 官方接口
// - 播放优先使用接口里的 pullStreamUrl
// - 当前网页主体播放链路是 Agora RTC；若 pullStreamUrl 为空，普通播放器无法直接播放
// ============================================================

var _XXX_PLATFORM_ID = "xiaoxinxin";
var _XXX_LIVE_TYPE = "xiaoxinxin";
var _XXX_BASE = "https://api.xiaoxinxin.com/smallheart-app";
var _XXX_WEB = "https://h5.xiaoxinxin.com";
var _XXX_OSS = "https://static.xiaoxinxin.com/";
var _XXX_SECRET = "H5IUaDFsFUdDUBdFWYeQEfeuhgt98kmdF87vGHJgKPJteK09L";
var _XXX_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148";
var _XXX_DEFAULT_COVER = "https://static.xiaoxinxin.com/admin/2024/08/21/d52ab9da-9951-4462-b6da-b3fedc4c66a2.png";

var _xxx_cache = {
  categories: null,
  rooms: {},
  token: "",
  tokenAt: 0,
  ttl: 5 * 60 * 1000,
  tokenTtl: 30 * 60 * 1000
};

function _xxx_throw(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  throw new Error(String(message || "unknown error"));
}

function _xxx_query(params) {
  var parts = [];
  params = params || {};
  Object.keys(params).forEach(function(k) {
    if (params[k] !== undefined && params[k] !== null && params[k] !== "") {
      parts.push(encodeURIComponent(k) + "=" + encodeURIComponent(String(params[k])));
    }
  });
  return parts.join("&");
}

function _xxx_sortedJson(obj) {
  var keys = Object.keys(obj || {}).sort();
  var out = {};
  for (var i = 0; i < keys.length; i++) out[keys[i]] = obj[keys[i]];
  return JSON.stringify(out);
}

function _xxx_stringifyGetValue(v) {
  if (v === null || v === undefined) return String(v);
  if (Array.isArray(v)) return v.map(_xxx_stringifyGetValue);
  if (typeof v === "object") {
    var o = {};
    Object.keys(v).forEach(function(k) { o[k] = _xxx_stringifyGetValue(v[k]); });
    return o;
  }
  return String(v);
}

function _xxx_apiHeaders(data, method, token) {
  var signObj = {};
  var src = data || {};
  Object.keys(src).forEach(function(k) {
    signObj[k] = String(method || "GET").toUpperCase() === "GET" ? _xxx_stringifyGetValue(src[k]) : src[k];
  });
  var nonce = Math.random().toString(16).slice(2) + String(Math.floor(Math.random() * 100000));
  var ts = String(Date.now());
  signObj["api-nonce"] = nonce;
  signObj["api-timestamp"] = ts;
  var payload = _xxx_sortedJson(signObj);
  var headers = {
    "User-Agent": _XXX_UA,
    "channel": "xiaoxinxin-H5",
    "url-type": "H5-share",
    "api-calling-platform": "h5",
    "platform": "H5",
    "version_name": "1.0",
    "api-nonce": nonce,
    "api-timestamp": ts,
    "api-sign": _xxx_md5(payload + "&key=" + _XXX_SECRET)
  };
  if (token) headers["Authorization"] = "Bearer " + token;
  return headers;
}

function _xxx_request(path, method, data, token) {
  method = String(method || "GET").toUpperCase();
  data = data || {};
  var url = _XXX_BASE + path;
  var headers = _xxx_apiHeaders(data, method, token);
  var req = { url: url, method: method, headers: headers, timeout: 20 };
  if (method === "GET") {
    var qs = _xxx_query(data);
    if (qs) req.url += (req.url.indexOf("?") >= 0 ? "&" : "?") + qs;
  } else {
    headers["Content-Type"] = "application/json";
    req.body = JSON.stringify(data);
  }
  return Host.http.request({
    platformId: _XXX_PLATFORM_ID,
    authMode: "none",
    request: req
  }).then(function(resp) {
    var obj = {};
    try { obj = JSON.parse(resp.bodyText || "{}"); } catch (e) {}
    if (resp.status !== 200) _xxx_throw("HTTP_ERROR", "小心心接口请求失败", { status: resp.status, path: path });
    if (obj && obj.code && obj.code !== "20001" && obj.success !== true) {
      _xxx_throw("API_ERROR", obj.message || "小心心接口返回错误", { code: obj.code, path: path });
    }
    return obj;
  });
}

function _xxx_getToken() {
  if (_xxx_cache.token && Date.now() - _xxx_cache.tokenAt < _xxx_cache.tokenTtl) {
    return Promise.resolve(_xxx_cache.token);
  }
  var deviceId = "angellive_h5_" + String(Date.now()) + "_" + Math.random().toString(16).slice(2);
  return _xxx_request("/tourist-mode-auth/tourist-mode-login", "POST", {
    equipmentId: deviceId,
    device: "APP"
  }).then(function(obj) {
    var token = obj && obj.data && obj.data.token ? String(obj.data.token) : "";
    if (!token) _xxx_throw("AUTH_ERROR", "小心心游客登录失败，未取得 token", {});
    _xxx_cache.token = token;
    _xxx_cache.tokenAt = Date.now();
    return token;
  });
}

function _xxx_fixImg(url) {
  if (!url || typeof url !== "string") return _XXX_DEFAULT_COVER;
  url = String(url).trim();
  if (url.indexOf("http://") === 0 || url.indexOf("https://") === 0) return url;
  return _XXX_OSS + url.replace(/^\/+/, "");
}

function _xxx_roomId(liveId, anchorUserId) {
  return "xxx_" + String(liveId || "") + "_" + String(anchorUserId || "");
}

function _xxx_parseRoomId(roomId) {
  var s = String(roomId || "");
  if (s.indexOf("xxx_") !== 0) return null;
  var arr = s.slice(4).split("_");
  if (arr.length < 2) return null;
  return { liveId: arr[0], anchorUserId: arr[1] };
}

function _xxx_liveState(status) {
  return String(status) === "1" ? "1" : "3";
}

function _xxx_toRoom(item) {
  item = item || {};
  var liveId = String(item.liveId || item.id || "");
  var anchorUserId = String(item.anchorUserId || item.userId || item.anchorUid || "");
  var roomId = _xxx_roomId(liveId, anchorUserId);
  var cover = _xxx_fixImg(item.coverImg || item.avatar || item.userAvatar || "");
  var title = String(item.title || item.nickname || item.userName || "小心心直播");
  var userName = String(item.nickname || item.userName || title);
  var room = {
    roomId: roomId,
    userId: anchorUserId || roomId,
    userName: userName,
    roomTitle: title,
    roomCover: cover,
    userHeadImg: _xxx_fixImg(item.avatar || item.userAvatar || item.coverImg || ""),
    liveType: _XXX_LIVE_TYPE,
    liveState: _xxx_liveState(item.status),
    liveWatchedCount: String(item.liveOnlinePeople || item.livePeopleNumber || item.hot || "0"),
    _raw: item
  };
  _xxx_cache.rooms[roomId] = item;
  return room;
}

function _xxx_getCategories() {
  if (_xxx_cache.categories && Date.now() - _xxx_cache.categoriesAt < _xxx_cache.ttl) {
    return Promise.resolve(_xxx_cache.categories);
  }
  return _xxx_request("/user/category/list-ext", "GET", { isEnable: 1 }).then(function(obj) {
    var arr = obj.data || [];
    var list = [{
      id: "recommend",
      title: "推荐",
      icon: _XXX_DEFAULT_COVER,
      biz: "recommend",
      subList: [{ id: "recommend", parentId: "recommend", title: "推荐", icon: "", biz: "recommend" }]
    }];
    for (var i = 0; i < arr.length; i++) {
      var c = arr[i] || {};
      if (!c.id || !c.categoryName) continue;
      list.push({
        id: "cat_" + String(c.id),
        title: String(c.categoryName),
        icon: _xxx_fixImg(c.categoryImg || ""),
        biz: String(c.id),
        subList: [{ id: "cat_" + String(c.id), parentId: "cat_" + String(c.id), title: String(c.categoryName), icon: "", biz: String(c.id) }]
      });
    }
    _xxx_cache.categories = list;
    _xxx_cache.categoriesAt = Date.now();
    return list;
  });
}

function _xxx_getRooms(cateId, page) {
  cateId = String(cateId || "recommend");
  page = Number(page || 1);
  if (page < 1) page = 1;
  if (cateId === "recommend") {
    return _xxx_request("/other/broadcast/page-recommend", "GET", { pageNum: page, pageSize: 20 }).then(function(obj) {
      var data = obj.data || {};
      var rows = [];
      if (page === 1 && data.recommendList) rows = rows.concat(data.recommendList);
      if (data.weightPage && data.weightPage.records) rows = rows.concat(data.weightPage.records);
      return rows.map(_xxx_toRoom);
    });
  }
  var categoryId = cateId.replace(/^cat_/, "");
  return _xxx_request("/other/broadcast/page-weight", "GET", { pageNum: page, pageSize: 20, categoryId: categoryId }).then(function(obj) {
    return (obj.data && obj.data.records ? obj.data.records : []).map(_xxx_toRoom);
  });
}

function _xxx_getDetail(roomId) {
  var parsed = _xxx_parseRoomId(roomId);
  if (!parsed) _xxx_throw("INVALID_ARGS", "roomId 格式不正确", { roomId: roomId });
  return _xxx_getToken().then(function(token) {
    return _xxx_request("/other/broadcast/homeDetail", "GET", {
      appType: 3,
      anchorFlag: false,
      anchorUserId: parsed.anchorUserId,
      liveId: parsed.liveId
    }, token);
  }).then(function(obj) {
    var live = obj.data && obj.data.liveBroadcastResult ? obj.data.liveBroadcastResult : {};
    live.liveId = live.id || parsed.liveId;
    live.anchorUserId = live.userId || parsed.anchorUserId;
    _xxx_cache.rooms[roomId] = live;
    return _xxx_toRoom(live);
  });
}

function _xxx_codeType(url) {
  var u = String(url || "").toLowerCase();
  if (u.indexOf(".m3u8") >= 0) return "m3u8";
  if (u.indexOf(".flv") >= 0) return "flv";
  if (u.indexOf(".ts") >= 0) return "mpegts";
  return "m3u8";
}

function _xxx_playback(roomId) {
  return _xxx_getDetail(roomId).then(function() {
    var live = _xxx_cache.rooms[roomId] || {};
    var url = String(live.pullStreamUrl || live.playUrl || live.streamUrl || "");
    if (!url) {
      _xxx_throw(
        "RTC_NOT_SUPPORTED",
        "该小心心直播间使用 Agora RTC 播放，接口未返回 m3u8/flv/ts 拉流地址，AngelLive 普通播放器暂不能直接播放。",
        {
          roomId: roomId,
          shareUrl: _XXX_WEB + "/pages/share/live?id=" + encodeURIComponent(live.id || "") + "&anchorUid=" + encodeURIComponent(live.userId || "") + "&liveId=" + encodeURIComponent(live.id || "") + "&type=4"
        }
      );
    }
    var codeType = _xxx_codeType(url);
    return [{
      cdn: "default",
      displayName: "默认线路",
      qualitys: [{
        roomId: roomId,
        title: "原画",
        qn: 9999,
        url: url,
        liveCodeType: codeType,
        liveType: _XXX_LIVE_TYPE,
        userAgent: _XXX_UA,
        headers: { "Referer": _XXX_WEB + "/" },
        playbackHints: {
          streamFormat: codeType === "m3u8" ? "hlsLive" : (codeType === "flv" ? "flvLive" : "mpegtsLive"),
          selectionBehavior: "direct"
        }
      }]
    }];
  });
}

function _xxx_search(keyword) {
  keyword = String(keyword || "").trim().toLowerCase();
  if (!keyword) return Promise.resolve([]);
  return _xxx_getRooms("recommend", 1).then(function(list) {
    return list.filter(function(r) {
      return String(r.userName + " " + r.roomTitle).toLowerCase().indexOf(keyword) >= 0;
    });
  });
}

function _xxx_resolveShare(shareCode) {
  var s = String(shareCode || "");
  var liveId = (s.match(/[?&](?:id|liveId)=([^&]+)/) || [])[1];
  var anchorUid = (s.match(/[?&]anchorUid=([^&]+)/) || [])[1];
  if (!liveId || !anchorUid) _xxx_throw("INVALID_SHARE", "无法解析小心心分享链接", { shareCode: shareCode });
  return _xxx_getDetail(_xxx_roomId(decodeURIComponent(liveId), decodeURIComponent(anchorUid)));
}

globalThis.LiveParsePlugin = {
  apiVersion: 1,
  getCategories: function() { return _xxx_getCategories(); },
  getRooms: function(payload) {
    return _xxx_getRooms(payload && payload.id ? payload.id : "recommend", payload && payload.page ? payload.page : 1);
  },
  getPlayback: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xxx_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xxx_playback(roomId);
  },
  getRoomDetail: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _xxx_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _xxx_getDetail(roomId);
  },
  getLiveState: function(payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) return Promise.resolve({ liveState: "3" });
    return _xxx_getDetail(roomId).then(function(room) { return { liveState: room.liveState || "3" }; }).then(null, function() { return { liveState: "3" }; });
  },
  search: function(payload) {
    return _xxx_search(payload && payload.keyword ? payload.keyword : "");
  },
  resolveShare: function(payload) {
    return _xxx_resolveShare(payload && payload.shareCode ? payload.shareCode : "");
  },
  getDanmaku: function() {
    return Promise.resolve({ args: {}, headers: null });
  }
};

// JavaScript MD5，供小心心 H5 API 签名使用
function _xxx_md5cycle(x, k) {
  var a = x[0], b = x[1], c = x[2], d = x[3];
  a = _xxx_ff(a, b, c, d, k[0], 7, -680876936); d = _xxx_ff(d, a, b, c, k[1], 12, -389564586);
  c = _xxx_ff(c, d, a, b, k[2], 17, 606105819); b = _xxx_ff(b, c, d, a, k[3], 22, -1044525330);
  a = _xxx_ff(a, b, c, d, k[4], 7, -176418897); d = _xxx_ff(d, a, b, c, k[5], 12, 1200080426);
  c = _xxx_ff(c, d, a, b, k[6], 17, -1473231341); b = _xxx_ff(b, c, d, a, k[7], 22, -45705983);
  a = _xxx_ff(a, b, c, d, k[8], 7, 1770035416); d = _xxx_ff(d, a, b, c, k[9], 12, -1958414417);
  c = _xxx_ff(c, d, a, b, k[10], 17, -42063); b = _xxx_ff(b, c, d, a, k[11], 22, -1990404162);
  a = _xxx_ff(a, b, c, d, k[12], 7, 1804603682); d = _xxx_ff(d, a, b, c, k[13], 12, -40341101);
  c = _xxx_ff(c, d, a, b, k[14], 17, -1502002290); b = _xxx_ff(b, c, d, a, k[15], 22, 1236535329);
  a = _xxx_gg(a, b, c, d, k[1], 5, -165796510); d = _xxx_gg(d, a, b, c, k[6], 9, -1069501632);
  c = _xxx_gg(c, d, a, b, k[11], 14, 643717713); b = _xxx_gg(b, c, d, a, k[0], 20, -373897302);
  a = _xxx_gg(a, b, c, d, k[5], 5, -701558691); d = _xxx_gg(d, a, b, c, k[10], 9, 38016083);
  c = _xxx_gg(c, d, a, b, k[15], 14, -660478335); b = _xxx_gg(b, c, d, a, k[4], 20, -405537848);
  a = _xxx_gg(a, b, c, d, k[9], 5, 568446438); d = _xxx_gg(d, a, b, c, k[14], 9, -1019803690);
  c = _xxx_gg(c, d, a, b, k[3], 14, -187363961); b = _xxx_gg(b, c, d, a, k[8], 20, 1163531501);
  a = _xxx_gg(a, b, c, d, k[13], 5, -1444681467); d = _xxx_gg(d, a, b, c, k[2], 9, -51403784);
  c = _xxx_gg(c, d, a, b, k[7], 14, 1735328473); b = _xxx_gg(b, c, d, a, k[12], 20, -1926607734);
  a = _xxx_hh(a, b, c, d, k[5], 4, -378558); d = _xxx_hh(d, a, b, c, k[8], 11, -2022574463);
  c = _xxx_hh(c, d, a, b, k[11], 16, 1839030562); b = _xxx_hh(b, c, d, a, k[14], 23, -35309556);
  a = _xxx_hh(a, b, c, d, k[1], 4, -1530992060); d = _xxx_hh(d, a, b, c, k[4], 11, 1272893353);
  c = _xxx_hh(c, d, a, b, k[7], 16, -155497632); b = _xxx_hh(b, c, d, a, k[10], 23, -1094730640);
  a = _xxx_hh(a, b, c, d, k[13], 4, 681279174); d = _xxx_hh(d, a, b, c, k[0], 11, -358537222);
  c = _xxx_hh(c, d, a, b, k[3], 16, -722521979); b = _xxx_hh(b, c, d, a, k[6], 23, 76029189);
  a = _xxx_hh(a, b, c, d, k[9], 4, -640364487); d = _xxx_hh(d, a, b, c, k[12], 11, -421815835);
  c = _xxx_hh(c, d, a, b, k[15], 16, 530742520); b = _xxx_hh(b, c, d, a, k[2], 23, -995338651);
  a = _xxx_ii(a, b, c, d, k[0], 6, -198630844); d = _xxx_ii(d, a, b, c, k[7], 10, 1126891415);
  c = _xxx_ii(c, d, a, b, k[14], 15, -1416354905); b = _xxx_ii(b, c, d, a, k[5], 21, -57434055);
  a = _xxx_ii(a, b, c, d, k[12], 6, 1700485571); d = _xxx_ii(d, a, b, c, k[3], 10, -1894986606);
  c = _xxx_ii(c, d, a, b, k[10], 15, -1051523); b = _xxx_ii(b, c, d, a, k[1], 21, -2054922799);
  a = _xxx_ii(a, b, c, d, k[8], 6, 1873313359); d = _xxx_ii(d, a, b, c, k[15], 10, -30611744);
  c = _xxx_ii(c, d, a, b, k[6], 15, -1560198380); b = _xxx_ii(b, c, d, a, k[13], 21, 1309151649);
  a = _xxx_ii(a, b, c, d, k[4], 6, -145523070); d = _xxx_ii(d, a, b, c, k[11], 10, -1120210379);
  c = _xxx_ii(c, d, a, b, k[2], 15, 718787259); b = _xxx_ii(b, c, d, a, k[9], 21, -343485551);
  x[0] = _xxx_add32(a, x[0]); x[1] = _xxx_add32(b, x[1]); x[2] = _xxx_add32(c, x[2]); x[3] = _xxx_add32(d, x[3]);
}
function _xxx_cmn(q, a, b, x, s, t) { a = _xxx_add32(_xxx_add32(a, q), _xxx_add32(x, t)); return _xxx_add32((a << s) | (a >>> (32 - s)), b); }
function _xxx_ff(a, b, c, d, x, s, t) { return _xxx_cmn((b & c) | ((~b) & d), a, b, x, s, t); }
function _xxx_gg(a, b, c, d, x, s, t) { return _xxx_cmn((b & d) | (c & (~d)), a, b, x, s, t); }
function _xxx_hh(a, b, c, d, x, s, t) { return _xxx_cmn(b ^ c ^ d, a, b, x, s, t); }
function _xxx_ii(a, b, c, d, x, s, t) { return _xxx_cmn(c ^ (b | (~d)), a, b, x, s, t); }
function _xxx_md51(s) {
  var n = s.length, state = [1732584193, -271733879, -1732584194, 271733878], i;
  for (i = 64; i <= s.length; i += 64) _xxx_md5cycle(state, _xxx_md5blk(s.substring(i - 64, i)));
  s = s.substring(i - 64);
  var tail = Array(16).fill(0);
  for (i = 0; i < s.length; i++) tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
  tail[i >> 2] |= 0x80 << ((i % 4) << 3);
  if (i > 55) { _xxx_md5cycle(state, tail); tail = Array(16).fill(0); }
  tail[14] = n * 8;
  _xxx_md5cycle(state, tail);
  return state;
}
function _xxx_md5blk(s) {
  var md5blks = [], i;
  for (i = 0; i < 64; i += 4) md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i + 1) << 8) + (s.charCodeAt(i + 2) << 16) + (s.charCodeAt(i + 3) << 24);
  return md5blks;
}
var _xxx_hex_chr = "0123456789abcdef".split("");
function _xxx_rhex(n) { var s = "", j; for (j = 0; j < 4; j++) s += _xxx_hex_chr[(n >> (j * 8 + 4)) & 15] + _xxx_hex_chr[(n >> (j * 8)) & 15]; return s; }
function _xxx_hex(x) { for (var i = 0; i < x.length; i++) x[i] = _xxx_rhex(x[i]); return x.join(""); }
function _xxx_md5(s) { return _xxx_hex(_xxx_md51(unescape(encodeURIComponent(s)))); }
function _xxx_add32(a, b) { return (a + b) & 0xFFFFFFFF; }
