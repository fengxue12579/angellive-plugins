const _sc_loginPlatformId = "stripchat";

const _sc_loginRuntime = {
  credentialSynced: false,
  credentialStatus: {
    state: "missing",
    expireAt: 0,
    userId: "",
    userName: "",
    message: ""
  }
};

function _sc_loginTrim(value) {
  return value === undefined || value === null ? "" : String(value).trim();
}

function _sc_loginBuildCredentialStatus(status) {
  var source = status && typeof status === "object" ? status : {};
  return {
    state: _sc_loginTrim(source.state) || "unknown",
    expireAt: (source.expireAt || 0),
    userId: _sc_loginTrim(source.userId),
    userName: _sc_loginTrim(source.userName),
    message: _sc_loginTrim(source.message)
  };
}

function _sc_loginSetCredentialStatus(status) {
  _sc_loginRuntime.credentialStatus = _sc_loginBuildCredentialStatus(status);
  return _sc_loginGetCredentialStatusSnapshot();
}

function _sc_loginGetCredentialStatusSnapshot() {
  return _sc_loginBuildCredentialStatus(_sc_loginRuntime.credentialStatus);
}

function _sc_loginMarkSynced(message) {
  _sc_loginRuntime.credentialSynced = true;
  return _sc_loginSetCredentialStatus({
    state: "unknown",
    expireAt: 0,
    userId: "",
    userName: "",
    message: _sc_loginTrim(message) || "credential synced; validation pending"
  });
}

function _sc_loginMarkCleared() {
  _sc_loginRuntime.credentialSynced = false;
  return _sc_loginSetCredentialStatus({
    state: "missing",
    expireAt: 0,
    userId: "",
    userName: "",
    message: ""
  });
}

function _sc_loginReadCookieHeader() {
  if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") {
    return _sc_loginTrim(Host.session.getCookieHeader(_sc_loginPlatformId));
  }
  return "";
}

function _sc_loginReadCookieValue(cookieHeader, name) {
  var cookie = _sc_loginTrim(cookieHeader);
  var target = _sc_loginTrim(name);
  if (!cookie || !target) return "";
  var parts = cookie.split(";");
  for (var i = 0; i < parts.length; i++) {
    var segment = _sc_loginTrim(parts[i]);
    if (!segment) continue;
    var index = segment.indexOf("=");
    var key = index >= 0 ? segment.slice(0, index).trim() : segment;
    var value = index >= 0 ? segment.slice(index + 1).trim() : "";
    if (key === target) return value;
  }
  return "";
}

// 唯一判断标准：isLogged=1 才算已登录
function _sc_loginIsLoggedIn(cookieHeader) {
  return _sc_loginReadCookieValue(cookieHeader, "isLogged") === "1";
}

async function _sc_loginValidateCredential() {
  var cookieHeader = _sc_loginReadCookieHeader();

  if (!cookieHeader) {
    return _sc_loginSetCredentialStatus({
      state: "missing",
      expireAt: 0,
      userId: "",
      userName: "",
      message: "未检测到 Cookie"
    });
  }

  if (!_sc_loginIsLoggedIn(cookieHeader)) {
    return _sc_loginSetCredentialStatus({
      state: "missing",
      expireAt: 0,
      userId: "",
      userName: "",
      message: "未登录，请使用账号密码登录 StripChat"
    });
  }

  // 已登录，从 Cookie 提取用户信息
  var sessionId = _sc_loginReadCookieValue(cookieHeader, "stripchat_com_sessionId");
  var moeUuid = _sc_loginReadCookieValue(cookieHeader, "moe_uuid");

  return _sc_loginSetCredentialStatus({
    state: "valid",
    expireAt: 0,
    userId: moeUuid || sessionId || "stripchat_user",
    userName: "StripChat 用户",
    message: ""
  });
}

async function _sc_loginSetCookie() {
  _sc_loginMarkSynced("cookie synced from host");
  return { ok: true };
}

async function _sc_loginClearCookie() {
  _sc_loginMarkCleared();
  return { ok: true };
}

async function _sc_loginSetCredential() {
  var status = _sc_loginMarkSynced("credential synced from host");
  return Object.assign({ ok: true }, status);
}

async function _sc_loginClearCredential() {
  var status = _sc_loginMarkCleared();
  return Object.assign({ ok: true }, status);
}

async function _sc_loginGetCredentialStatus() {
  return _sc_loginGetCredentialStatusSnapshot();
}

globalThis.__lp_plugin_stripchat_login = {
  setCookie: _sc_loginSetCookie,
  clearCookie: _sc_loginClearCookie,
  setCredential: _sc_loginSetCredential,
  clearCredential: _sc_loginClearCredential,
  getCredentialStatus: _sc_loginGetCredentialStatus,
  validateCredential: _sc_loginValidateCredential
};
