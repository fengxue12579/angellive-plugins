/* 直播聚合 LiveParse Plugin v3.0.0
 * 9平台：来秀/畅聊/流星/VV星球/乐嗨/PandaTV/Stripchat/体育直播/蜘蛛直播
 * 风格模仿 stripchat 1.1.1：顶部简单辅助函数 → 9 平台分块 → 路由 → 插件入口
 * 约定：点开分类一次加载全部（page>1 返回空数组）
 */

var LA_PLUGIN_ID = "liveall";
var LA_LIVE_TYPE = "30";
var LA_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

/* ================= 基础工具 ================= */

function laThrow(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, context || {});
  throw new Error(String(message || "unknown error"));
}
function laStr(v) { return v === undefined || v === null ? "" : String(v); }
function laInt(v, fb) { var n = parseInt(v, 10); return isNaN(n) ? fb : n; }
function laPayload(p) { return (p && typeof p === "object") ? p : {}; }
function laUUID() {
  var s = "";
  for (var i = 0; i < 32; i++) s += "0123456789abcdef"[Math.floor(Math.random() * 16)];
  return s.substring(0, 8) + "-" + s.substring(8, 12) + "-" + s.substring(12, 16) +
         "-" + s.substring(16, 20) + "-" + s.substring(20, 32);
}

async function laHttp(opts, errCode) {
  try {
    var req = { url: opts.url, method: opts.method || "GET", headers: opts.headers || {}, timeout: opts.timeout || 15 };
    if (opts.body !== undefined) req.body = opts.body;
    var res = await Host.http.request({ authMode: "none", followRedirects: false, request: req });
    return res;
  } catch (e) {
    laThrow(errCode || "NETWORK", "网络请求失败", { url: opts.url });
  }
}
async function laGetText(url, headers, timeout) {
  var res = await laHttp({ url: url, method: "GET", headers: headers || {}, timeout: timeout || 15 }, "NETWORK");
  return laStr(res && (res.bodyText !== undefined ? res.bodyText : res.body));
}
async function laGetJson(url, headers, timeout) {
  var t = await laGetText(url, headers, timeout);
  try { return JSON.parse(t || "{}"); } catch (e) { return {}; }
}
function laWithTimeout(promise, ms) {
  return Promise.race([
    promise,
    new Promise(function(_, reject) { setTimeout(function() { reject(new Error("timeout")); }, ms); })
  ]);
}

/* ================= MD5（来秀签名/乐嗨签名用） ================= */
var MD5 = (function() {
  function md5cycle(x, k) {
    var a = x[0], b = x[1], c = x[2], d = x[3];
    a = ff(a, b, c, d, k[0], 7, -680876936); d = ff(d, a, b, c, k[1], 12, -389564586);
    c = ff(c, d, a, b, k[2], 17, 606105819); b = ff(b, c, d, a, k[3], 22, -1044525330);
    a = ff(a, b, c, d, k[4], 7, -176418897); d = ff(d, a, b, c, k[5], 12, 1200080426);
    c = ff(c, d, a, b, k[6], 17, -1473231341); b = ff(b, c, d, a, k[7], 22, -45705983);
    a = ff(a, b, c, d, k[8], 7, 1770035416); d = ff(d, a, b, c, k[9], 12, -1958414417);
    c = ff(c, d, a, b, k[10], 17, -42063); b = ff(b, c, d, a, k[11], 22, -1990404162);
    a = ff(a, b, c, d, k[12], 7, 1804603682); d = ff(d, a, b, c, k[13], 12, -40341101);
    c = ff(c, d, a, b, k[14], 17, -1502002290); b = ff(b, c, d, a, k[15], 22, 1236535329);
    a = gg(a, b, c, d, k[1], 5, -165796510); d = gg(d, a, b, c, k[6], 9, -1069501632);
    c = gg(c, d, a, b, k[11], 14, 643717713); b = gg(b, c, d, a, k[0], 20, -373897302);
    a = gg(a, b, c, d, k[5], 5, -701558691); d = gg(d, a, b, c, k[10], 9, 38016083);
    c = gg(c, d, a, b, k[15], 14, -660478335); b = gg(b, c, d, a, k[4], 20, -405537848);
    a = gg(a, b, c, d, k[9], 5, 568446438); d = gg(d, a, b, c, k[14], 9, -1019803690);
    c = gg(c, d, a, b, k[3], 14, -187363961); b = gg(b, c, d, a, k[8], 20, 1163531501);
    a = gg(a, b, c, d, k[13], 5, -1444681467); d = gg(d, a, b, c, k[2], 9, -51403784);
    c = gg(c, d, a, b, k[7], 14, 1735328473); b = gg(b, c, d, a, k[12], 20, -1926607734);
    a = hh(a, b, c, d, k[5], 4, -378558); d = hh(d, a, b, c, k[8], 11, -2022574463);
    c = hh(c, d, a, b, k[11], 16, 1839030562); b = hh(b, c, d, a, k[14], 23, -35309556);
    a = hh(a, b, c, d, k[1], 4, -1530992060); d = hh(d, a, b, c, k[4], 11, 1272893353);
    c = hh(c, d, a, b, k[7], 16, -155497632); b = hh(b, c, d, a, k[10], 23, -1094730640);
    a = hh(a, b, c, d, k[13], 4, 681279174); d = hh(d, a, b, c, k[0], 11, -358537222);
    c = hh(c, d, a, b, k[3], 16, -722521979); b = hh(b, c, d, a, k[6], 23, 76029189);
    a = hh(a, b, c, d, k[9], 4, -640364487); d = hh(d, a, b, c, k[12], 11, -421815835);
    c = hh(c, d, a, b, k[15], 16, 530742520); b = hh(b, c, d, a, k[2], 23, -995338651);
    a = ii(a, b, c, d, k[0], 6, -198630844); d = ii(d, a, b, c, k[7], 10, 1126891415);
    c = ii(c, d, a, b, k[14], 15, -1416354905); b = ii(b, c, d, a, k[5], 21, -57434055);
    a = ii(a, b, c, d, k[12], 6, 1700485571); d = ii(d, a, b, c, k[3], 10, -1894986606);
    c = ii(c, d, a, b, k[10], 15, -1051523); b = ii(b, c, d, a, k[1], 21, -2054922799);
    a = ii(a, b, c, d, k[8], 6, 1873313359); d = ii(d, a, b, c, k[15], 10, -30611744);
    c = ii(c, d, a, b, k[6], 15, -1560198380); b = ii(b, c, d, a, k[13], 21, 1309151649);
    a = ii(a, b, c, d, k[4], 6, -145523070); d = ii(d, a, b, c, k[11], 10, -1120210379);
    c = ii(c, d, a, b, k[2], 15, 718787259); b = ii(b, c, d, a, k[9], 21, -343485551);
    x[0] = add32(a, x[0]); x[1] = add32(b, x[1]); x[2] = add32(c, x[2]); x[3] = add32(d, x[3]);
  }
  function cmn(q, a, b, x, s, t) { a = add32(add32(a, q), add32(x, t)); return add32((a << s) | (a >>> (32 - s)), b); }
  function ff(a, b, c, d, x, s, t) { return cmn((b & c) | ((~b) & d), a, b, x, s, t); }
  function gg(a, b, c, d, x, s, t) { return cmn((b & d) | (c & (~d)), a, b, x, s, t); }
  function hh(a, b, c, d, x, s, t) { return cmn(b ^ c ^ d, a, b, x, s, t); }
  function ii(a, b, c, d, x, s, t) { return cmn(c ^ (b | (~d)), a, b, x, s, t); }
  function md51(s) {
    var txt = ''; var n = s.length, state = [1732584193, -271733879, -1732584194, 271733878], i;
    for (i = 64; i <= s.length; i += 64) { md5cycle(state, md5blk(s.substring(i - 64, i))); }
    s = s.substring(i - 64); var tail = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
    for (i = 0; i < s.length; i++) tail[i >> 2] |= s.charCodeAt(i) << ((i % 4) << 3);
    tail[i >> 2] |= 0x80 << ((i % 4) << 3);
    if (i > 55) { md5cycle(state, tail); tail = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]; }
    tail[14] = n * 8; md5cycle(state, tail); return state;
  }
  function md5blk(s) { var md5blks = [], i; for (i = 0; i < 64; i += 4) { md5blks[i >> 2] = s.charCodeAt(i) + (s.charCodeAt(i+1) << 8) + (s.charCodeAt(i+2) << 16) + (s.charCodeAt(i+3) << 24); } return md5blks; }
  function rhex(n) { var s = '', j; for (j = 0; j < 4; j++) s += hex_chr[(n >> (j * 8 + 4)) & 0x0F] + hex_chr[(n >> (j * 8)) & 0x0F]; return s; }
  function hex(x) { for (var i = 0; i < x.length; i++) x[i] = rhex(x[i]); return x.join(''); }
  function add32(a, b) { return (a + b) & 0xFFFFFFFF; }
  var hex_chr = '0123456789abcdef'.split('');
  return function(s) { return hex(md51(s)); };
})();

/* ================= Stripchat 专用工具（移植自 1.1.1） ================= */

var SC_API_BASE = "https://stripchat.com/api/front";
var SC_SITE = "https://stripchat.com";
var SC_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var SC_HLS_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0";
var SC_DOPPIOCDN = "doppiocdn.org";

function scStr(v) { return v === undefined || v === null ? "" : String(v); }
function scInt(v, fb) { var n = parseInt(v, 10); return isNaN(n) ? fb : n; }

async function scHttpRequest(opts, errCode) {
  try {
    var req = { url: opts.url, method: opts.method || "GET", headers: opts.headers || {}, timeout: opts.timeout || 20 };
    if (opts.body !== undefined) req.body = opts.body;
    var res = await Host.http.request({ authMode: "none", followRedirects: false, request: req });
    return res;
  } catch (e) {
    laThrow(errCode || "NETWORK", "网络请求失败", { url: opts.url });
  }
}
async function scGetText(url, headers) {
  var res = await scHttpRequest({
    url: url, method: "GET",
    headers: Object.assign(
      { "User-Agent": SC_UA, "Referer": SC_SITE + "/", "Accept": "application/json, text/plain, */*" },
      headers || {}
    )
  }, "NETWORK");
  var body = res && (res.bodyText !== undefined ? res.bodyText : res.body);
  return scStr(body);
}
async function scGetJson(url, headers) {
  var text = await scGetText(url, headers);
  try { return JSON.parse(text || "{}"); } catch (e) { return {}; }
}

function scCountryFlag(code) {
  code = scStr(code).toUpperCase();
  if (!/^[A-Z]{2}$/.test(code)) return "";
  var out = "";
  for (var i = 0; i < 2; i++) out += String.fromCodePoint(code.charCodeAt(i) - 65 + 0x1F1E6);
  return out;
}
function scParseStatus(status, viewers) {
  status = scStr(status).toLowerCase();
  var st;
  if (status === "public") st = "🔴直播中";
  else if (status === "groupshow") st = "🎫门票房";
  else if (status === "ticket") st = "🎫购票房";
  else if (status === "off") st = "⚫已下播";
  else st = "🎫" + status;
  if (viewers) st += " 👤" + viewers + "人";
  return st;
}
function scLiveState(status) {
  status = scStr(status).toLowerCase();
  if (status === "public") return "1";
  if (status === "off") return "0";
  return "2";
}
function scModelToRoom(raw) {
  if (!raw || typeof raw !== "object") return null;
  var username = scStr(raw.username).trim();
  var mid = scStr(raw.id).trim();
  var stream = scStr(raw.streamName).trim();
  if (!username && !mid) return null;
  var status = scStr(raw.status || "off").toLowerCase();
  var viewers = raw.viewersCount || 0;
  var flag = scCountryFlag(scStr(raw.country || ""));
  var snapTs = raw.snapshotTimestamp || "";
  var pic = (mid && snapTs) ? ("https://img." + SC_DOPPIOCDN + "/snapshot/" + mid + "/" + snapTs) : "";
  var roomId = stream && /^\d+$/.test(stream) ? stream : mid;
  if (!roomId) roomId = username;
  return {
    userName: flag ? flag + username : username,
    roomTitle: scParseStatus(status, viewers),
    roomCover: pic, userHeadImg: pic,
    userId: mid || username, roomId: roomId,
    liveState: scLiveState(status), liveWatchedCount: viewers,
    _username: username, _status: status
  };
}
function scJoinUrl(base, rel) {
  if (!rel) return "";
  if (/^https?:\/\//i.test(rel)) return rel;
  var b = scStr(base).replace(/\/+$/, "");
  if (rel.charAt(0) === "/") {
    var m = b.match(/^(https?:\/\/[^\/]+)/i);
    return (m ? m[1] : b) + rel;
  }
  return b + "/" + rel;
}
function scExtractShards(variants) {
  var shards = {};
  for (var i = 0; i < variants.length; i++) {
    var m = scStr(variants[i].url).match(/b-hls-(\d+)/i);
    if (m) shards[m[1]] = true;
  }
  var keys = Object.keys(shards);
  if (!keys.length) return ["10", "11", "12", "13", "14", "15", "16", "20", "24", "25", "30", "32"];
  return keys;
}
async function scIsPlayable(url) {
  try {
    var text = await scGetText(url, { "User-Agent": SC_HLS_UA, "Referer": SC_SITE + "/" });
    if (!text || text.length < 12) return false;
    if (text.indexOf("#EXT-X-MOUFLON-ADVERT") >= 0) return false;
    if (text.indexOf("cpa/v2/") >= 0) return false;
    if (text.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") >= 0) return false;
    return text.indexOf("#EXTINF") >= 0;
  } catch (e) { return false; }
}
function scParseVariants(text, baseUrl) {
  var lines = scStr(text).split("\n"), out = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    var bwM = line.match(/BANDWIDTH=(\d+)/i);
    var nameM = line.match(/NAME="([^"]+)"/i);
    var resM = line.match(/RESOLUTION=(\d+)x(\d+)/i);
    var next = (lines[i + 1] || "").trim();
    if (!next || next.charAt(0) === "#") continue;
    var name = nameM ? nameM[1] : "";
    if (/blurred/i.test(name)) continue;
    out.push({
      bandwidth: bwM ? parseInt(bwM[1], 10) : 0,
      name: name, height: resM ? parseInt(resM[2], 10) : 0,
      url: scJoinUrl(baseUrl, next)
    });
  }
  return out;
}
function scVariantScore(v) {
  var h = v.height || 0;
  var n = scStr(v.name).toLowerCase();
  if (n === "source" || n === "orig" || n === "original") h = Math.max(h, 2160);
  return h * 1e9 + (v.bandwidth || 0);
}
async function scResolveStreamId(username) {
  username = scStr(username).trim().replace(/^\/+|\/+$/g, "").split("/").pop();
  if (/^\d+$/.test(username)) return username;
  try {
    var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(username));
    var id = data && (data.id || (data.model && data.model.id));
    if (id && /^\d+$/.test(String(id))) return String(id);
  } catch (e) {}
  return "";
}

var SC_CLASSES = [
  { id: "girls", title: "女主播" },
  { id: "couples", title: "情侣" },
  { id: "men", title: "男主播" },
  { id: "trans", title: "跨性别" }
];
var SC_TAGS = [
  { v: "autoTagNew", n: "新主播" },
  { v: "recommended", n: "推荐" },
  { v: "fuckMachine", n: "炮机" },
  { v: "ageTeen", n: "青年" },
  { v: "autoTagVr", n: "VR" },
  { v: "ethnicityAsian", n: "亚洲人" },
  { v: "tagLanguageChinese", n: "🇨🇳中国" },
  { v: "tagLanguageJapanese", n: "🇯🇵日本" },
  { v: "tagLanguageKorean", n: "🇰🇷韩国" },
  { v: "tagLanguageVietnamese", n: "🇻🇳越南" },
  { v: "tagLanguageUkrainian", n: "🇺🇦乌克兰" },
  { v: "tagLanguageRussianSpeaking", n: "🇷🇺俄罗斯" },
  { v: "tagLanguageUSModels", n: "🇺🇸美国" },
  { v: "tagLanguageColombian", n: "🇨🇴哥伦比亚" },
  { v: "tagLanguageGermanSpeaking", n: "🇩🇪德国" },
  { v: "tagLanguageFrench", n: "🇫🇷法国" },
  { v: "tagLanguageUKModels", n: "🇬🇧英国" },
  { v: "tagLanguageCanadian", n: "🇨🇦加拿大" },
  { v: "tagLanguageMexican", n: "🇲🇽墨西哥" },
  { v: "ethnicityIndian", n: "🇮🇳印度" },
  { v: "tagLanguageVenezuelan", n: "🇻🇪委内瑞拉" },
  { v: "tagLanguageRomanian", n: "🇷🇴罗马尼亚" },
  { v: "tagLanguageAfrican", n: "🌍非洲" },
  { v: "tagLanguageSpanishSpeaking", n: "🇪🇸西班牙" },
  { v: "ethnicityMiddleEastern", n: "🇸🇦🇦🇪阿拉伯" },
  { v: "tagLanguageKenyan", n: "🇰🇪肯尼亚" },
  { v: "tagLanguageSouthAfrican", n: "🇿🇦南非" },
  { v: "tagLanguageBrazilian", n: "🇧🇷巴西" },
  { v: "tagLanguageThai", n: "🇹🇭泰国" },
  { v: "tagLanguageItalian", n: "🇮🇹意大利" },
  { v: "ethnicityWhite", n: "白人" },
  { v: "ethnicityLatino", n: "拉丁" },
  { v: "ethnicityMultiracial", n: "混血" },
  { v: "ethnicityEbony", n: "黑人" },
  { v: "ageYoung", n: "鲜嫩青年22+" },
  { v: "subcultureStudent", n: "学生" },
  { v: "doBlowjob", n: "口交" },
  { v: "doDeepThroat", n: "深喉" },
  { v: "doFootFetish", n: "恋足" },
  { v: "autoTagInteractiveToy", n: "互动玩具" },
  { v: "doMasturbation", n: "自慰" },
  { v: "doAnal", n: "肛交" },
  { v: "doSquirt", n: "潮吹" },
  { v: "doDoggyStyle", n: "狗式" },
  { v: "doCosplay", n: "Cosplay" },
  { v: "doRolePlay", n: "RolePlay" }
];
var SC_TAGS_MEN = [
  { v: "sexGayCouples", n: "情侣" },
  { v: "orientationStraight", n: "直男" }
];

/* ================= 来秀 laixiu ================= */

var LX_API = "https://wapapi.imkktv.com";
var LX_IMG = "http://kkimg.imkktv.com";
var LX_SECRET = "kk792f28d6ff1f34ec702c08626d454b39pro";
var LX_IMEI = "";
var LX_CLASSES = [
  { id: "all", title: "全部直播" },
  { id: "hot", title: "热度排行" },
  { id: "dance", title: "舞蹈" },
  { id: "female", title: "女主播" },
  { id: "male", title: "男主播" }
];

function lxHeaders() {
  if (!LX_IMEI) {
    var s = "";
    for (var i = 0; i < 32; i++) s += Math.floor(Math.random() * 10);
    LX_IMEI = s;
  }
  var ts = String(Date.now()) + String(Math.floor(Math.random() * 900000) + 100000);
  var rid = MD5("web" + LX_IMEI + ts + LX_SECRET);
  return {
    "User-Agent": LA_UA, "Referer": "https://www.imkktv.com/",
    "Origin": "https://www.imkktv.com",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "platform": "WEB", "version": "1.0.0", "versionCode": "10003",
    "imei": LX_IMEI, "os": "web", "mobileModel": "web",
    "loginType": "2", "channel": "9",
    "timestamp": ts, "requestId": rid
  };
}
function lxFixImg(p) {
  p = laStr(p);
  if (!p) return "";
  if (p.indexOf("//") === 0) return "http:" + p;
  if (p.charAt(0) === "/") return LX_IMG + p;
  return p.replace("https://", "http://");
}
async function lxFetchPage(pg) {
  var url = LX_API + "/supplement/guest/image/banner/getBannerAndLiveHot/v2?currentPage=" + pg;
  var d = await laGetJson(url, lxHeaders(), 15);
  return (d && d.data && d.data.resLiveHotDtoList) || [];
}
function lxToRoom(item) {
  var aid = laStr(item.anchorId);
  var pic = lxFixImg(item.livingImg || item.liveCoverUrl || item.avatar);
  return {
    userName: laStr(item.nickname), roomTitle: "👁" + laStr(item.audienceNum || ""),
    roomCover: pic, userHeadImg: pic, userId: aid, roomId: "laixiu@" + aid,
    liveState: "1", liveWatchedCount: laInt(item.audienceNum, 0)
  };
}
async function lxGetRooms(tid, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var pages = await Promise.all([1, 2, 3].map(function(pg) { return lxFetchPage(pg); }));
  var all = [];
  pages.forEach(function(lst) { all = all.concat(lst); });
  if (!all.length) laThrow("EMPTY", "来秀列表为空", {});
  var filtered = all.filter(function(item) {
    var nn = laStr(item.nickname), ti = laStr(item.liveTitle || ""), tag = laStr(item.tag || "");
    if (tid === "dance") return /舞/.test(nn + ti + tag);
    if (tid === "female") return laInt(item.sex, 0) === 2;
    if (tid === "male") return laInt(item.sex, 0) === 1;
    return true;
  });
  filtered.sort(function(a, b) { return laInt(b.audienceNum, 0) - laInt(a.audienceNum, 0); });
  return filtered.slice(0, 200).map(function(it) { return lxToRoom(it); });
}
async function lxGetPlayback(aid) {
  var id = laStr(aid).split("$").pop().split("|")[0].split("/").pop().replace(/\D/g, "");
  if (!id) laThrow("INVALID_ARGS", "房间号无效", { roomId: aid });
  var url = LX_API + "/liveroom/guest/getPlayUrlGuest?anchorId=" + id;
  var d = await laGetJson(url, lxHeaders(), 20);
  var data = (d && d.data) || {};
  var u = laStr(data.urlPlayAcc || data.urlPlayFlv || data.urlPlayAccMix || data.urlPlayHls);
  if (u) {
    if (u.indexOf("//") === 0) u = "http:" + u;
    u = u.replace("https://", "http://");
    return [{ cdn: "default", qualitys: [{
      roomId: "laixiu@" + id, title: "直播", qn: 0, url: u,
      liveCodeType: u.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
      liveType: LA_LIVE_TYPE, userAgent: LA_UA,
      headers: { "Referer": "https://www.imkktv.com/" }
    }]}];
  }
  laThrow("NOT_FOUND", "无可用播放流", { roomId: aid });
}
async function lxSearch(key) {
  var pages = await Promise.all([1, 2, 3].map(function(pg) { return lxFetchPage(pg); }));
  var all = [];
  pages.forEach(function(lst) { all = all.concat(lst); });
  var kw = laStr(key).toLowerCase(), out = [];
  all.forEach(function(item) {
    var nn = laStr(item.nickname).toLowerCase(), ti = laStr(item.liveTitle || "").toLowerCase(), aid = laStr(item.anchorId).toLowerCase();
    if (kw && (nn.indexOf(kw) >= 0 || ti.indexOf(kw) >= 0 || aid.indexOf(kw) >= 0)) out.push(lxToRoom(item));
  });
  return out.slice(0, 30);
}

/* ================= 畅聊 changliao ================= */

var CL_TAG_API = "https://show.336769.com/api/ApiServices/service/top/show/tag";
var CL_ROOM_API = "https://show.336769.com/api/ApiServices/service/live/getLiveStreamInfo";
var CL_PHOTO = "https://photo.336769.com";
var CL_CLASSES = [
  { id: "all", title: "全部" },
  { id: "online", title: "在线直播" },
  { id: "female", title: "女主播" },
  { id: "male", title: "男主播" },
  { id: "dance", title: "舞蹈" }
];

function clHeaders() {
  return {
    "User-Agent": LA_UA, "Referer": "https://show.336769.com/",
    "Origin": "https://show.336769.com", "Accept": "application/json, text/plain, */*"
  };
}
function clFixImg(p) {
  p = laStr(p);
  if (!p) return "";
  if (p.indexOf("//") === 0) return "https:" + p;
  if (p.charAt(0) === "/") return CL_PHOTO + p;
  return p;
}
async function clFetchPage(pg) {
  var url = CL_TAG_API + "?pageIndex=" + pg + "&pageSize=100&tagid=45";
  var d = await laGetJson(url, clHeaders(), 20);
  if (d && d.code === 100000) return d.data || [];
  return [];
}
function clToRoom(item) {
  var rid = laStr(item.roomnumber || item.roomId || item.anchorId);
  var pic = clFixImg(item.showcover || item.avatar);
  var online = laInt(item.isonline, 0) === 1;
  return {
    userName: laStr(item.nickname), roomTitle: online ? ("人气" + laStr(item.audienceSize || "直播中")) : "离线",
    roomCover: pic, userHeadImg: pic, userId: rid, roomId: "changliao@" + rid,
    liveState: online ? "1" : "0", liveWatchedCount: laInt(item.audienceSize, 0)
  };
}
async function clGetRooms(tid, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var pages = await Promise.all([1, 2, 3].map(function(pg) { return clFetchPage(pg); }));
  var all = [];
  pages.forEach(function(lst) { all = all.concat(lst); });
  var filtered = all.filter(function(item) {
    if (laInt(item.isonline, 0) !== 1) return false;
    if (tid === "female") return laInt(item.gender, 0) === 2;
    if (tid === "male") return laInt(item.gender, 0) === 1;
    if (tid === "online") return true;
    if (tid === "dance") {
      var labels = item.coverLabelList || [];
      for (var i = 0; i < labels.length; i++) {
        if (labels[i].dressingNameEn === "Meiwu_master") return true;
      }
      return /舞/.test(laStr(item.nickname));
    }
    return true;
  });
  filtered.sort(function(a, b) { return laInt(b.audienceSize, 0) - laInt(a.audienceSize, 0); });
  return filtered.slice(0, 200).map(function(it) { return clToRoom(it); });
}
async function clGetPlayback(rid) {
  var id = laStr(rid).split("$").pop().split("|")[0];
  var pages = await Promise.all([clFetchPage(1), clFetchPage(2)]);
  for (var pg = 0; pg < pages.length; pg++) {
    var list = pages[pg];
    for (var i = 0; i < list.length; i++) {
      if (laStr(list[i].roomnumber) === id && list[i].videoUrl) {
        var u = laStr(list[i].videoUrl);
        return [{ cdn: "default", qualitys: [{
          roomId: "changliao@" + id, title: "直播", qn: 0, url: u,
          liveCodeType: u.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
          liveType: LA_LIVE_TYPE, userAgent: LA_UA, headers: { "Referer": "https://show.336769.com/" }
        }]}];
      }
    }
  }
  var url = CL_ROOM_API + "?roomnumber=" + encodeURIComponent(id) + "&anchorId=" + encodeURIComponent(id);
  var d = await laGetJson(url, clHeaders(), 20);
  if (d && d.code === 100000 && d.data) {
    var u2 = laStr(d.data.videoUrl || d.data.pullUrl || d.data.liveUrl);
    if (u2) {
      return [{ cdn: "default", qualitys: [{
        roomId: "changliao@" + id, title: "直播", qn: 0, url: u2,
        liveCodeType: u2.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
        liveType: LA_LIVE_TYPE, userAgent: LA_UA, headers: { "Referer": "https://show.336769.com/" }
      }]}];
    }
  }
  laThrow("NOT_FOUND", "无可用播放流", { roomId: rid });
}
async function clSearch(key) {
  var pages = await Promise.all([1, 2, 3].map(function(pg) { return clFetchPage(pg); }));
  var all = [];
  pages.forEach(function(lst) { all = all.concat(lst); });
  var kw = laStr(key).toLowerCase(), out = [];
  all.forEach(function(item) {
    var nn = laStr(item.nickname).toLowerCase(), loc = laStr(item.loca).toLowerCase(), rn = laStr(item.roomnumber).toLowerCase();
    if (kw && (nn.indexOf(kw) >= 0 || loc.indexOf(kw) >= 0 || rn.indexOf(kw) >= 0)) out.push(clToRoom(item));
  });
  return out.slice(0, 30);
}

/* ================= 流星 liuxing ================= */

var LXING_API = "https://live.660807.com/api/default.ashx?v=1.0.1&Device=0&SourceDevice=-1";
var LXING_IMG = "https://sr.660807.com";
var LXING_CDN = "http://txpull2.5see.com/live";
var LXING_CLASSES = [
  { id: "all", title: "全部直播" },
  { id: "hot", title: "热度排行" },
  { id: "dance", title: "舞蹈" },
  { id: "sing", title: "唱歌" },
  { id: "lianmai", title: "连麦" }
];
var LXING_CACHE = null, LXING_CACHE_TS = 0;

function lxingHeaders() {
  return {
    "User-Agent": LA_UA, "Accept": "application/json, text/plain, */*",
    "Origin": "https://live.660807.com", "Referer": "https://live.660807.com/"
  };
}
function lxingFixImg(p) {
  p = laStr(p);
  if (!p) return "";
  if (p.indexOf("//") === 0) return "https:" + p;
  if (p.charAt(0) === "/") return LXING_IMG + p;
  return p.replace("http://sr.660807.com", "https://sr.660807.com");
}
async function lxingFetchAll() {
  var now = Date.now();
  if (LXING_CACHE && (now - LXING_CACHE_TS) < 60000) return LXING_CACHE;
  var t = await laGetText(LXING_API, lxingHeaders(), 20);
  t = t.replace(/^\ufeff/, "");
  var root = {};
  try { root = JSON.parse(t); } catch (e) { laThrow("EMPTY", "流星列表解析失败", {}); }
  var seen = {}, out = [];
  function collect(arr) {
    (arr || []).forEach(function(item) {
      if (!item || typeof item !== "object") return;
      var idx = laStr(item.idx);
      if (!idx || seen[idx]) return;
      if (!item.nn && !item.ri && !item.lp) return;
      seen[idx] = true;
      out.push(item);
    });
  }
  collect(root.list);
  Object.keys(root).forEach(function(k) {
    if (k === "list") return;
    if (Array.isArray(root[k])) {
      var arr = root[k].filter(function(x) { return x && x.idx; });
      arr.sort(function(a, b) { return laInt(b.n, 0) - laInt(a.n, 0); });
      collect(arr);
    }
  });
  if (!out.length) laThrow("EMPTY", "流星列表为空", {});
  LXING_CACHE = out; LXING_CACHE_TS = now;
  return out;
}
function lxingIsLive(item) { return laInt(item.ls, 0) === 1 && !item.vodurl; }
function lxingToRoom(item) {
  var idx = laStr(item.idx);
  var pic = lxingFixImg(item.lp);
  var n = laInt(item.n, 0);
  var city = laStr(item.mycity);
  var remark = (city && city !== "火星" ? "[" + city + "] " : "") + (n ? "人气" + n : "直播中");
  return {
    userName: laStr(item.nn || item.nickname), roomTitle: remark,
    roomCover: pic, userHeadImg: pic, userId: idx, roomId: "liuxing@" + idx,
    liveState: "1", liveWatchedCount: n
  };
}
async function lxingGetRooms(tid, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var all = (await lxingFetchAll()).filter(function(it) { return lxingIsLive(it); });
  var filtered = all.filter(function(item) {
    var nn = laStr(item.nn);
    if (tid === "dance") return /舞/.test(nn);
    if (tid === "sing") return /唱|歌|声/.test(nn);
    if (tid === "lianmai") return laInt(item.lianmaitype, 0) === 1;
    return true;
  });
  filtered.sort(function(a, b) {
    if (tid === "hot") return (laInt(b.starGift, 0) * 100 + laInt(b.dayStar, 0) * 50 + laInt(b.n, 0)) - (laInt(a.starGift, 0) * 100 + laInt(a.dayStar, 0) * 50 + laInt(a.n, 0));
    return laInt(b.n, 0) - laInt(a.n, 0);
  });
  return filtered.slice(0, 200).map(function(it) { return lxingToRoom(it); });
}
function lxingFmtTime(unixTs) {
  var d = new Date((unixTs + 8 * 3600) * 1000);
  function p2(n) { return (n < 10 ? "0" : "") + n; }
  return p2(d.getUTCMonth() + 1) + p2(d.getUTCDate()) + p2(d.getUTCHours()) + p2(d.getUTCMinutes()) + p2(d.getUTCSeconds());
}
async function lxingGetPlayback(aid) {
  var id = laStr(aid).split("$").pop().split("|")[0];
  var all = await lxingFetchAll();
  var target = null;
  for (var i = 0; i < all.length; i++) {
    if (laStr(all[i].idx) === id || laStr(all[i].ri) === id) { target = all[i]; break; }
  }
  if (!target) laThrow("NOT_FOUND", "房间不存在", { roomId: aid });
  var idx = laStr(target.idx);
  var ts = laInt(target.startlivetime, 0) || laInt(target.ts, 0) || Math.floor(Date.now() / 1000);
  var offsets = [-5, -4, -6, -3, -7];
  for (var oi = 0; oi < offsets.length; oi++) {
    var url = LXING_CDN + "/" + idx + "/" + idx + lxingFmtTime(ts + offsets[oi]) + ".flv";
    try {
      var res = await laHttp({
        url: url, method: "GET",
        headers: { "User-Agent": LA_UA, "Referer": "https://live.660807.com/" },
        timeout: 5
      }, "PROBE");
      var body = res && (res.body || res.bodyText || "");
      var isFlv = (typeof body === "string") && body.substr(0, 3) === "FLV";
      if (res && (res.status === 200 || isFlv)) {
        return [{ cdn: "default", qualitys: [{
          roomId: "liuxing@" + id, title: "直播", qn: 0, url: url,
          liveCodeType: "flv", liveType: LA_LIVE_TYPE, userAgent: LA_UA,
          headers: { "User-Agent": LA_UA, "Referer": "https://live.660807.com/" },
          contentType: "video/x-flv"
        }]}];
      }
    } catch (e) {}
  }
  var fb = LXING_CDN + "/" + idx + "/" + idx + lxingFmtTime(ts - 5) + ".flv";
  return [{ cdn: "default", qualitys: [{
    roomId: "liuxing@" + id, title: "直播", qn: 0, url: fb,
    liveCodeType: "flv", liveType: LA_LIVE_TYPE, userAgent: LA_UA,
    headers: { "User-Agent": LA_UA, "Referer": "https://live.660807.com/" },
    contentType: "video/x-flv"
  }]}];
}
async function lxingSearch(key) {
  var all = await lxingFetchAll();
  var kw = laStr(key).toLowerCase(), out = [];
  all.forEach(function(item) {
    if (!lxingIsLive(item)) return;
    var idx = laStr(item.idx).toLowerCase(), nn = laStr(item.nn).toLowerCase();
    if (kw && (idx.indexOf(kw) >= 0 || nn.indexOf(kw) >= 0)) out.push(lxingToRoom(item));
  });
  return out.slice(0, 30);
}

/* ================= VV星球 vvxq ================= */

var VV_API = "https://h5p.vvxqiu.com";
var VV_ORIGIN = "https://h5webcdn-pro.vvxqiu.com";
var VV_IMG = "https://image-app-pro.wasaixiu.com";
var VV_UA = "ios/7.830 (ios 17.0; ; iPhone 15 (A2846/A3089/A3090/A3092))";
var VV_CLASSES = [
  { id: "all", title: "全部直播" },
  { id: "hot", title: "热门主播" },
  { id: "new", title: "新人主播" }
];

function vvHeaders() {
  return {
    "User-Agent": VV_UA, "access-control-request-method": "GET",
    "origin": VV_ORIGIN, "referer": VV_ORIGIN + "/"
  };
}
async function vvFetchPage(pg, ps) {
  var start = (pg - 1) * ps, end = start + ps;
  var url = VV_API + "/room/video/getLiveRoomList.do?start=" + start + "&end=" + end;
  var d = await laGetJson(url, vvHeaders(), 15);
  var infos = (d && d.infos) || [];
  var out = [];
  infos.forEach(function(it) {
    if (laStr(it.status) !== "100" || !it.playHfsUrl) return;
    out.push(it);
  });
  if (!out.length) laThrow("EMPTY", "VV星球列表为空", {});
  return out;
}
function vvToRoom(it) {
  var rid = laStr(it.roomId);
  var nn = laStr(it.nickName), rn = laStr(it.roomName);
  var name = (rn && rn !== nn) ? nn + " - " + rn : nn;
  var pic = laStr(it.anchorLogo);
  if (pic && pic.indexOf("http") !== 0) pic = VV_IMG + pic;
  var remark = "在线" + (it.online || 0);
  if (it.location) remark = it.location + " | " + remark;
  return {
    userName: name, roomTitle: remark, roomCover: pic, userHeadImg: pic,
    userId: rid, roomId: "vvxq@" + rid + "@@" + laStr(it.playHfsUrl),
    liveState: "1", liveWatchedCount: laInt(it.online, 0)
  };
}
async function vvGetRooms(tid, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var all = await vvFetchPage(1, 200);
  return all.map(function(it) { return vvToRoom(it); });
}
async function vvGetPlayback(vid) {
  var url = vid;
  if (vid.indexOf("@@") >= 0) url = vid.split("@@")[1];
  if (!url) laThrow("NOT_FOUND", "无可用播放流", {});
  return [{ cdn: "default", qualitys: [{
    roomId: "vvxq@" + vid, title: "直播", qn: 0, url: url,
    liveCodeType: "m3u8", liveType: LA_LIVE_TYPE, userAgent: VV_UA,
    headers: { "Origin": VV_ORIGIN, "Referer": VV_ORIGIN + "/" }
  }]}];
}
async function vvSearch(key) {
  var all = await vvFetchPage(1, 100);
  var kw = laStr(key).toLowerCase(), out = [];
  all.forEach(function(it) {
    var nn = laStr(it.nickName).toLowerCase(), rn = laStr(it.roomName).toLowerCase(), rid = laStr(it.roomId).toLowerCase();
    if (kw && (nn.indexOf(kw) >= 0 || rn.indexOf(kw) >= 0 || rid.indexOf(kw) >= 0)) out.push(vvToRoom(it));
  });
  return out.slice(0, 30);
}

/* ================= 乐嗨 lehai（游客自动注册，免登录） ================= */

var LH_SITE = "https://www.lehaitv.com";
var LH_SVC = "https://service.lehaitv.com/v2";
var LH_SALT = "1eha12h5";
var LH_CLASSES = [
  { id: "hot", title: "热门直播" },
  { id: "dancer", title: "热舞" }
];
var LH_SESS = null, LH_WEBDID = "", LH_ROOM_CACHE = null, LH_ROOM_TS = 0;

function lhHeaders() {
  if (!LH_WEBDID) LH_WEBDID = laUUID();
  return {
    "User-Agent": LA_UA, "Referer": LH_SITE + "/",
    "Origin": LH_SITE, "web_did": LH_WEBDID
  };
}
function lhQ2(v) {
  return encodeURIComponent(encodeURIComponent(laStr(v).trim()));
}
function lhSign(params) {
  var keys = Object.keys(params).filter(function(k) {
    var v = params[k];
    return v !== undefined && v !== null && laStr(v) !== "";
  }).sort();
  var chain = keys.map(function(k) { return k + "=" + lhQ2(params[k]); }).join("&");
  return MD5(chain + LH_SALT);
}
async function lhEnsureVisitor(force) {
  if (LH_SESS && !force) return LH_SESS;
  var d = await laGetJson(LH_SVC + "/user/registervisitor", lhHeaders(), 15);
  var data = (d && d.data) || {};
  var sid = laStr(data.sessionid), uid = laStr(data.uid);
  if (!sid || !uid) laThrow("AUTH", "乐嗨游客注册失败", {});
  LH_SESS = { token: decodeURIComponent(sid), tku: uid };
  return LH_SESS;
}
async function lhSignedGet(path, query) {
  var sess = await lhEnsureVisitor(false);
  for (var attempt = 0; attempt < 2; attempt++) {
    var st1 = String(Date.now());
    var params = { accessToken: sess.token, tku: sess.tku, _st1: st1 };
    Object.keys(query || {}).forEach(function(k) { params[k] = query[k]; });
    var sign = lhSign(params);
    var qs = Object.keys(params).map(function(k) {
      return k + "=" + encodeURIComponent(laStr(params[k]));
    }).join("&");
    var url = LH_SVC + path + "?" + qs + "&_ajaxData1=" + sign + "&_=" + Math.floor(Date.now() / 1000);
    var d = await laGetJson(url, lhHeaders(), 15);
    var code = d && d.status && d.status.statuscode;
    if ((code === "-998" || code === -998) && attempt === 0) {
      sess = await lhEnsureVisitor(true);
      continue;
    }
    return d;
  }
  return {};
}
async function lhFetchRooms() {
  var now = Date.now();
  if (LH_ROOM_CACHE && (now - LH_ROOM_TS) < 60000) return LH_ROOM_CACHE;
  var d = await laGetJson(LH_SITE + "/json/commonrooms.json", lhHeaders(), 15);
  var list = (d && d.hotAnchorList) || [];
  if (!list.length) laThrow("EMPTY", "乐嗨列表为空", {});
  var live = list.filter(function(it) { return laInt(it.live_status, 0) === 1; });
  LH_ROOM_CACHE = live; LH_ROOM_TS = now;
  return live;
}
function lhToRoom(it) {
  var rid = laStr(it.roomid);
  var nn = laStr(it.nickname) || ("房间" + rid);
  var pic = laStr(it.avatar || it.coverW9H16);
  var remark = it.is_dancer ? "热舞" : ("在线:" + laStr(it.member_num));
  return {
    userName: nn, roomTitle: remark, roomCover: pic, userHeadImg: pic,
    userId: rid, roomId: "lehai@" + rid, liveState: "1",
    liveWatchedCount: laInt(it.member_num, 0)
  };
}
async function lhGetRooms(tid, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var all = await lhFetchRooms();
  if (tid === "dancer") all = all.filter(function(it) { return it.is_dancer; });
  return all.slice(0, 200).map(function(it) { return lhToRoom(it); });
}
async function lhGetPlayback(rid) {
  var m = laStr(rid).split("$").pop().split("|")[0].split("/").pop().replace(/\D/g, "");
  if (!m) laThrow("INVALID_ARGS", "房间号无效", { roomId: rid });
  var d = await lhSignedGet("/room/" + m + "/media/advanceInfoRoom", {});
  var data = (d && d.data) || {};
  var url = laStr(data.media_url_web) || laStr(data.media_url_app) ||
            laStr(data.medial_url_app_for_h264) || laStr(data.media_url) || "";
  if (url) {
    return [{ cdn: "default", qualitys: [{
      roomId: "lehai@" + m, title: "直播", qn: 0, url: url,
      liveCodeType: url.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
      liveType: LA_LIVE_TYPE, userAgent: LA_UA, headers: { "Referer": LH_SITE + "/" }
    }]}];
  }
  laThrow("NOT_FOUND", "无可用播放流", { roomId: rid });
}
async function lhSearch(key) {
  var all = await lhFetchRooms();
  var kw = laStr(key).toLowerCase(), out = [];
  all.forEach(function(it) {
    var nn = laStr(it.nickname).toLowerCase(), rid = laStr(it.roomid).toLowerCase();
    if (kw && (nn.indexOf(kw) >= 0 || rid.indexOf(kw) >= 0)) out.push(lhToRoom(it));
  });
  return out.slice(0, 30);
}

/* ================= PandaTV panda ================= */

var PD_HOST = "https://5721004.xyz";
var PD_DEFPIC = "https://tupian.li/images/2024/03/30/660769b1ba623.png";
var PD_PROXIES = [
  "https://hubu.515355.xyz/proxy/?", "https://flank.515355.xyz/proxy/",
  "https://uae2.515355.xyz/proxy/", "https://pol.515355.xyz/proxy/",
  "https://f00.515355.xyz/proxy/", "https://ce2.515355.xyz/proxy/?"
];
var PD_CLASSES = [{ id: "pandalive", title: "🐼 PandaTV" }];

function pdHeaders() {
  return { "User-Agent": LA_UA, "Referer": "https://www.pandalive.co.kr/", "Origin": "https://www.pandalive.co.kr" };
}
async function pdFetchList() {
  var d = await laGetJson(PD_HOST + "/player/list.json", pdHeaders(), 15);
  return (d && d.list) || [];
}
function pdToRoom(it) {
  var uid = laStr(it.userId);
  var pic = laStr(it.thumbUrl) || PD_DEFPIC;
  return {
    userName: "📺 " + laStr(it.userNick), roomTitle: "👤 " + laStr(it.user) + (it.isAdult ? " 🔞" : ""),
    roomCover: pic, userHeadImg: pic, userId: uid, roomId: "panda@live_" + uid,
    liveState: "1", liveWatchedCount: laInt(it.user, 0)
  };
}
async function pdGetRooms(tid, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var all = await pdFetchList();
  if (!all.length) laThrow("EMPTY", "PandaTV 列表为空", {});
  var rooms = all.map(function(it) { return pdToRoom(it); });
  rooms.sort(function(a, b) { return b.liveWatchedCount - a.liveWatchedCount; });
  return rooms.slice(0, 200);
}
async function pdGetPlayback(vid) {
  var uid = laStr(vid).replace(/^live_/, "");
  var text = await laGetText(PD_HOST + "/player/list.m3u", pdHeaders(), 20);
  var lines = text.split("\n"), url = "";
  for (var i = 0; i < lines.length; i++) {
    if (lines[i].indexOf(uid) >= 0 && i + 1 < lines.length) { url = lines[i + 1].trim(); break; }
  }
  if (!url) laThrow("NOT_FOUND", "无可用播放流", { roomId: vid });
  var qualitys = [{
    roomId: "panda@" + vid, title: "直连", qn: 0, url: url,
    liveCodeType: "m3u8", liveType: LA_LIVE_TYPE, userAgent: LA_UA, headers: pdHeaders()
  }];
  PD_PROXIES.forEach(function(px, idx) {
    qualitys.push({
      roomId: "panda@" + vid, title: "代理" + (idx + 1), qn: 0, url: px + url,
      liveCodeType: "m3u8", liveType: LA_LIVE_TYPE, userAgent: LA_UA, headers: pdHeaders()
    });
  });
  return [{ cdn: "default", qualitys: qualitys }];
}
async function pdSearch(key) {
  var all = await pdFetchList();
  var kw = laStr(key).toLowerCase(), out = [];
  all.forEach(function(it) {
    var nm = laStr(it.userNick).toLowerCase(), au = laStr(it.userId).toLowerCase();
    if (kw && (nm.indexOf(kw) >= 0 || au.indexOf(kw) >= 0)) out.push(pdToRoom(it));
  });
  return out.slice(0, 50);
}

/* ================= Stripchat stripchat（分片直连，不放广告） ================= */

async function scGetCategories() {
  return SC_CLASSES.map(function(c) {
    var tags = c.id === "men" ? SC_TAGS_MEN.concat(SC_TAGS) : SC_TAGS;
    return {
      id: "stripchat_" + c.id, title: c.title, icon: "", biz: "",
      subList: tags.map(function(t) {
        return { id: t.v, parentId: "stripchat_" + c.id, title: t.n, icon: "", biz: t.v };
      })
    };
  });
}
async function scGetRooms(catId, tag, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var categoryId = laStr(catId).replace(/^stripchat_/, "") || "girls";
  if (["girls", "couples", "men", "trans"].indexOf(categoryId) < 0) categoryId = "girls";
  var ts = Date.now();
  async function fetchModels(withTag) {
    var url = SC_API_BASE + "/v2/models?primaryTag=" + encodeURIComponent(categoryId) +
      "&limit=61&offset=0&sortBy=stripRanking&_t=" + ts;
    if (withTag && tag) url += "&filterGroupTags=" + encodeURIComponent('[["' + tag + '"]]');
    var data = await scGetJson(url);
    var models = [];
    if (data && Array.isArray(data.models)) models = data.models;
    else if (data && Array.isArray(data.blocks)) {
      data.blocks.forEach(function(b) { if (b && Array.isArray(b.models)) models = models.concat(b.models); });
    }
    return models;
  }
  var models = await fetchModels(true);
  if (!models.length && tag) models = await fetchModels(false); // 标签无数据回退
  var rooms = [];
  for (var i = 0; i < Math.min(models.length, 60); i++) {
    var r = scModelToRoom(models[i]);
    if (r) { r.roomId = "stripchat@" + r.roomId; r.userId = "stripchat@" + r.userId; rooms.push(r); }
  }
  return rooms;
}
async function scGetPlayback(rawId) {
  rawId = laStr(rawId).replace(/^stripchat@/, "").trim();
  if (!rawId) laThrow("INVALID_ARGS", "roomId is required", {});
  var streamId = await scResolveStreamId(rawId);
  if (!streamId) laThrow("NOT_FOUND", "无法解析主播流ID", { roomId: rawId });
  var masters = [
    "https://edge-hls.doppiocdn.org/hls/" + streamId + "/master/" + streamId + "_auto.m3u8",
    "https://edge-hls.doppiocdn.com/hls/" + streamId + "/master/" + streamId + "_auto.m3u8",
    "https://edge-hls.growcdnssedge.com/hls/" + streamId + "/master/" + streamId + "_auto.m3u8"
  ];
  var seen = {};
  for (var mi = 0; mi < masters.length; mi++) {
    var text = await scGetText(masters[mi], { "User-Agent": SC_HLS_UA, "Referer": SC_SITE + "/" });
    var t = scStr(text).trim();
    if (!t || t.indexOf("#EXTM3U") !== 0) continue;
    if (t.indexOf("#EXT-X-MOUFLON-ADVERT") >= 0 && t.indexOf("#EXT-X-STREAM-INF") < 0) continue;
    if (t.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") >= 0) continue;
    var base = masters[mi].substring(0, masters[mi].lastIndexOf("/") + 1);
    var variants = scParseVariants(t, base);
    for (var vi = 0; vi < variants.length; vi++) {
      var v = variants[vi];
      if (!v.url) continue;
      var key = v.height + "|" + v.url.replace(/^https?:\/\/[^\/]+/i, "");
      if (!seen[key] || scVariantScore(v) > scVariantScore(seen[key])) seen[key] = v;
    }
    if (Object.keys(seen).length > 0) break;
  }
  var sorted = Object.keys(seen).map(function(k) { return seen[k]; })
    .sort(function(a, b) { return scVariantScore(b) - scVariantScore(a); });
  var shards = scExtractShards(sorted);
  var shard = shards[0] || "22";
  var qualityDefs = [
    { title: "原画", suffixes: ["_source", "_orig", ""] },
    { title: "1080p", suffixes: ["_1080p"] },
    { title: "720p", suffixes: ["_720p"] },
    { title: "480p", suffixes: ["_480p"] },
    { title: "360p", suffixes: ["_360p"] },
    { title: "240p", suffixes: ["_240p"] }
  ];
  var directUrls = [];
  for (var qi = 0; qi < qualityDefs.length; qi++) {
    var qd = qualityDefs[qi], found = null;
    var cands = [
      "https://media-hls.growcdnssedge.com/b-hls-" + shard + "/" + streamId + "/" + streamId,
      "https://media-hls.doppiocdn.org/b-hls-" + shard + "/" + streamId + "/" + streamId
    ];
    for (var ci = 0; ci < cands.length && !found; ci++) {
      for (var gi = 0; gi < qd.suffixes.length && !found; gi++) {
        var gurl = cands[ci] + qd.suffixes[gi] + ".m3u8";
        if (await scIsPlayable(gurl)) found = gurl;
      }
    }
    if (found) directUrls.push({ url: found, title: qd.title });
  }
  var finalVariants = directUrls.length > 0 ? directUrls : sorted;
  var headers = { "Referer": SC_SITE + "/" };
  var qualitys = [], usedTitles = {};
  for (var qj = 0; qj < finalVariants.length; qj++) {
    var vv = finalVariants[qj];
    var title = vv.title || (function() {
      var n = scStr(vv.name).toLowerCase(), h = vv.height || 0;
      if (n === "source" || n === "orig" || n === "original" || h >= 1600) return "原画";
      if (h >= 1000) return "1080p";
      if (h >= 700) return "720p";
      if (h >= 460) return "480p";
      return n || "自动";
    })();
    if (usedTitles[title]) continue;
    usedTitles[title] = true;
    qualitys.push({
      roomId: "stripchat@" + streamId, title: title, qn: vv.height || 0, url: vv.url,
      liveCodeType: "m3u8", liveType: LA_LIVE_TYPE, userAgent: SC_HLS_UA, headers: headers
    });
  }
  if (!qualitys.length) laThrow("NOT_FOUND", "无可用播放流", { roomId: rawId });
  return [{ cdn: "default", qualitys: qualitys }];
}
async function scSearch(keyword) {
  keyword = laStr(keyword).trim();
  if (!keyword) return [];
  var ts = Date.now(), seen = {}, out = [];
  var tags = ["girls", "couples", "men", "trans"];
  for (var ti = 0; ti < tags.length; ti++) {
    try {
      var url = SC_API_BASE + "/v4/models/search/group/username?query=" +
        encodeURIComponent(keyword) + "&limit=50&primaryTag=" + tags[ti] + "&_t=" + ts;
      var data = await scGetJson(url);
      var models = (data && Array.isArray(data.models)) ? data.models : [];
      for (var i = 0; i < models.length; i++) {
        var r = scModelToRoom(models[i]);
        if (r && !seen[r.roomId]) {
          seen[r.roomId] = true;
          r.roomId = "stripchat@" + r.roomId;
          r.userId = "stripchat@" + r.userId;
          out.push(r);
        }
      }
    } catch (e) {}
  }
  return out;
}

/* ================= 体育直播 sports1（必须直连，禁代理） ================= */

var SP1_API = "https://lzfs5tah9amkatbu4tb07.k8v4dh4.app";
var SP1_CLASSES = [
  { id: "live", title: "正在直播" },
  { id: "all", title: "全部主播" },
  { id: "football", title: "⚽足球" },
  { id: "basketball", title: "🏀篮球" },
  { id: "match", title: "赛事直播" }
];
var SP1_UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1";

function spHeaders(apiBase, referer) {
  return { "User-Agent": SP1_UA, "Referer": referer || apiBase, "Accept": "application/json" };
}
async function spGetIndex(apiBase, referer) {
  var url = apiBase + "/api/c5/business/livehouse/index?lang=zh&timestamp=" + Date.now();
  var d = await laGetJson(url, spHeaders(apiBase, referer), 15);
  if (d && d.success === true) return d.data || {};
  laThrow("EMPTY", "体育列表为空", {});
}
function spCollect(data) {
  var result = [], seen = {};
  var lists = [data.ongoingLivestreams || [], data.anchorLivestreams || [], data.streamingAnchorRanking || []];
  (data.matchLivestreams || []).forEach(function(ml) {
    if (ml && ml.reservedAnchors) lists.push(ml.reservedAnchors);
  });
  lists.forEach(function(arr) {
    if (!Array.isArray(arr)) return;
    arr.forEach(function(item) {
      if (!item || typeof item !== "object") return;
      var hid = laStr(item.houseId);
      if (!hid || seen[hid]) return;
      seen[hid] = true;
      result.push(item);
    });
  });
  return result;
}
function spStreamUrl(item) {
  var hls = laStr(item.playStreamAddress2), flv = laStr(item.playStreamAddress);
  if (hls && hls !== "www") return hls;
  if (flv && flv !== "www") return flv;
  return "";
}
function spFmtView(n) {
  n = laInt(n, 0);
  if (n >= 10000) return (n / 10000).toFixed(1) + "万";
  return String(n);
}
function spToRoom(item, plat) {
  var hid = laStr(item.houseId);
  var hn = laStr(item.houseName || item.houseNameEn || ("ID:" + hid));
  var nn = laStr(item.nickName);
  var title = (nn ? nn + " - " : "") + hn;
  var cover = laStr(item.houseImage || item.loadingCover || item.userImage);
  var ls = laInt(item.liveStatus, 0);
  return {
    userName: title, roomTitle: ls === 2 ? ("👁" + spFmtView(item.visitHistory) + "|直播中") : "回放",
    roomCover: cover, userHeadImg: cover,
    userId: hid, roomId: plat + "@" + hid, liveState: ls === 2 ? "1" : "0",
    liveWatchedCount: laInt(item.visitHistory, 0)
  };
}
async function spGetRooms(apiBase, referer, plat, tid, page) {
  if (Math.max(1, laInt(page, 1)) > 1) return [];
  var data = await spGetIndex(apiBase, referer);
  var all = spCollect(data);
  var out = [];
  all.forEach(function(item) {
    var ls = laInt(item.liveStatus, 0), rt = laInt(item.raceTypeId, 0);
    var has = !!spStreamUrl(item);
    var keep = false;
    if (tid === "live") keep = ls === 2 && has;
    else if (tid === "all") keep = has && ls !== 3 && ls !== 4;
    else if (tid === "football") keep = rt === 1 && has;
    else if (tid === "basketball") keep = rt === 2 && has;
    else if (tid === "match") keep = (item.matchList || []).length > 0 && has;
    else keep = has;
    if (keep) out.push(spToRoom(item, plat));
  });
  return out.slice(0, 200);
}
async function spGetPlayback(apiBase, referer, plat, hid, ua) {
  var data = await spGetIndex(apiBase, referer);
  var all = spCollect(data);
  for (var i = 0; i < all.length; i++) {
    if (laStr(all[i].houseId) === hid) {
      var url = spStreamUrl(all[i]);
      if (url) {
        return [{ cdn: "default", qualitys: [{
          roomId: plat + "@" + hid, title: "直播", qn: 0, url: url,
          liveCodeType: url.indexOf(".m3u8") >= 0 ? "m3u8" : "flv",
          liveType: LA_LIVE_TYPE, userAgent: ua || SP1_UA,
          headers: { "Referer": referer || apiBase }
        }]}];
      }
    }
  }
  laThrow("NOT_FOUND", "无可用播放流", { roomId: hid });
}
async function spSearch(apiBase, referer, plat, key) {
  var data = await spGetIndex(apiBase, referer);
  var all = spCollect(data);
  var kw = laStr(key).toLowerCase().trim(), out = [];
  all.forEach(function(item) {
    if (!spStreamUrl(item)) return;
    var hn = laStr(item.houseName).toLowerCase(), nn = laStr(item.nickName).toLowerCase(), hid = laStr(item.houseId).toLowerCase();
    if (kw && (hn.indexOf(kw) >= 0 || nn.indexOf(kw) >= 0 || hid.indexOf(kw) >= 0)) out.push(spToRoom(item, plat));
  });
  return out.slice(0, 30);
}

/* ================= 蜘蛛直播 sports2（同源，必须直连） ================= */

var SP2_API = "https://ugcaamdqtywxlcnuucb01.k8v4dh4.app";
var SP2_REFERER = "https://zzzb93vip.app";
var SP2_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.6613.127 Safari/537.36";

/* ================= 平台路由（简单 switch，不用复杂正则） ================= */

var LA_PLAT_IDS = ["laixiu", "changliao", "liuxing", "vvxq", "lehai", "panda", "stripchat", "sports1", "sports2"];
var LA_PLAT_NAMES = {
  laixiu: "🎤来秀直播", changliao: "💬畅聊直播", liuxing: "🌠流星直播",
  vvxq: "🪐VV星球", lehai: "🎪乐嗨直播", panda: "🐼PandaTV",
  stripchat: "🌍Stripchat", sports1: "⚽体育直播", sports2: "🕷蜘蛛直播"
};
var LA_PLAT_CLASSES = {
  laixiu: LX_CLASSES, changliao: CL_CLASSES, liuxing: LXING_CLASSES,
  vvxq: VV_CLASSES, lehai: LH_CLASSES, panda: PD_CLASSES,
  sports1: SP1_CLASSES, sports2: SP1_CLASSES
};

/* 解析 getRooms 的 payload → {plat, cat, tag}
 * 普通平台：id="laixiu_all", parentId="laixiu"
 * stripchat标签：id="tagLanguageChinese"(标签值), parentId="stripchat_girls"
 */
function laRouteRooms(id, parentId, tag) {
  id = laStr(id); parentId = laStr(parentId); tag = laStr(tag);
  // stripchat 标签：parentId 是 stripchat_xxx 且 id 与 parentId 不同
  if (parentId.indexOf("stripchat_") === 0 && id !== parentId) {
    return { plat: "stripchat", cat: parentId.substring("stripchat_".length), tag: id };
  }
  // 普通：id = "plat_cat"
  var us = id.indexOf("_");
  if (us > 0) {
    var plat = id.substring(0, us);
    if (LA_PLAT_IDS.indexOf(plat) >= 0) {
      return { plat: plat, cat: id.substring(us + 1), tag: tag };
    }
  }
  // 点顶级：id = "laixiu"
  if (LA_PLAT_IDS.indexOf(id) >= 0) {
    var classes = LA_PLAT_CLASSES[id] || [];
    return { plat: id, cat: classes.length ? classes[0].id : "", tag: tag };
  }
  // 兜底：从 parentId 取平台
  if (LA_PLAT_IDS.indexOf(parentId) >= 0) {
    return { plat: parentId, cat: id, tag: tag };
  }
  laThrow("INVALID_ARGS", "无法识别平台", { id: id, parentId: parentId });
}

/* 解析 roomId → {plat, vid}，roomId 形如 "laixiu@123" */
function laRouteRoom(roomId) {
  var s = laStr(roomId);
  var at = s.indexOf("@");
  if (at > 0) {
    var plat = s.substring(0, at);
    if (LA_PLAT_IDS.indexOf(plat) >= 0) return { plat: plat, vid: s.substring(at + 1) };
  }
  laThrow("INVALID_ARGS", "无法识别平台", { roomId: roomId });
}

function laSubList(plat) {
  if (plat === "stripchat") return null; // stripchat 单独处理
  var classes = LA_PLAT_CLASSES[plat] || [];
  return classes.map(function(c) {
    return { id: plat + "_" + c.id, parentId: plat, title: c.title, icon: "", biz: c.id };
  });
}

/* ================= 插件入口 ================= */

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async getCategories(payload) {
    var out = [];
    // 8 个普通平台：顶级 id = 平台 id，带 subList 二级分类
    ["laixiu", "changliao", "liuxing", "vvxq", "lehai", "panda", "sports1", "sports2"].forEach(function(pid) {
      out.push({
        id: pid, title: LA_PLAT_NAMES[pid], icon: "", biz: "",
        subList: laSubList(pid)
      });
    });
    // stripchat：4 个性别分类各为顶级，标签作 subList
    var scCats = await scGetCategories();
    scCats.forEach(function(c) {
      out.push({ id: c.id, title: "🌍" + c.title, icon: "", biz: "", subList: c.subList || [] });
    });
    return out;
  },

  async getRooms(payload) {
    var p = laPayload(payload);
    var r = laRouteRooms(p.id, p.parentId, p.tag || p.biz);
    var page = Math.max(1, laInt(p.page, 1));
    switch (r.plat) {
      case "laixiu": return await lxGetRooms(r.cat, page);
      case "changliao": return await clGetRooms(r.cat, page);
      case "liuxing": return await lxingGetRooms(r.cat, page);
      case "vvxq": return await vvGetRooms(r.cat, page);
      case "lehai": return await lhGetRooms(r.cat, page);
      case "panda": return await pdGetRooms(r.cat, page);
      case "stripchat": return await scGetRooms(r.cat, r.tag, page);
      case "sports1": return await spGetRooms(SP1_API, SP1_API, "sports1", r.cat, page);
      case "sports2": return await spGetRooms(SP2_API, SP2_REFERER, "sports2", r.cat, page);
      default: laThrow("INVALID_ARGS", "未知平台", { plat: r.plat });
    }
  },

  async getPlayback(payload) {
    var p = laPayload(payload);
    var r = laRouteRoom(p.roomId || p.userId);
    switch (r.plat) {
      case "laixiu": return await lxGetPlayback(r.vid);
      case "changliao": return await clGetPlayback(r.vid);
      case "liuxing": return await lxingGetPlayback(r.vid);
      case "vvxq": return await vvGetPlayback(r.vid);
      case "lehai": return await lhGetPlayback(r.vid);
      case "panda": return await pdGetPlayback(r.vid);
      case "stripchat": return await scGetPlayback(r.vid);
      case "sports1": return await spGetPlayback(SP1_API, SP1_API, "sports1", r.vid, SP1_UA);
      case "sports2": return await spGetPlayback(SP2_API, SP2_REFERER, "sports2", r.vid, SP2_UA);
      default: laThrow("INVALID_ARGS", "未知平台", { plat: r.plat });
    }
  },

  async search(payload) {
    var p = laPayload(payload);
    var keyword = laStr(p.keyword).trim();
    if (!keyword) return [];
    var tasks = [
      laWithTimeout(lxSearch(keyword).catch(function() { return []; }), 10000),
      laWithTimeout(clSearch(keyword).catch(function() { return []; }), 10000),
      laWithTimeout(lxingSearch(keyword).catch(function() { return []; }), 10000),
      laWithTimeout(vvSearch(keyword).catch(function() { return []; }), 10000),
      laWithTimeout(lhSearch(keyword).catch(function() { return []; }), 10000),
      laWithTimeout(pdSearch(keyword).catch(function() { return []; }), 10000),
      laWithTimeout(scSearch(keyword).catch(function() { return []; }), 10000),
      laWithTimeout(spSearch(SP1_API, SP1_API, "sports1", keyword).catch(function() { return []; }), 10000),
      laWithTimeout(spSearch(SP2_API, SP2_REFERER, "sports2", keyword).catch(function() { return []; }), 10000)
    ];
    var names = ["🎤来秀直播", "💬畅聊直播", "🌠流星直播", "🪐VV星球", "🎪乐嗨直播", "🐼PandaTV", "🌍Stripchat", "⚽体育直播", "🕷蜘蛛直播"];
    var results = await Promise.all(tasks);
    var out = [];
    results.forEach(function(arr, i) {
      (arr || []).forEach(function(rm) {
        rm.roomTitle = "[" + names[i] + "] " + (rm.roomTitle || "");
        out.push(rm);
      });
    });
    return out.slice(0, 100);
  },

  async getRoomDetail(payload) {
    var p = laPayload(payload);
    var r = laRouteRoom(p.roomId || p.userId);
    return {
      userName: r.vid, roomTitle: LA_PLAT_NAMES[r.plat] || r.plat,
      roomCover: "", userHeadImg: "", userId: r.vid,
      roomId: p.roomId, liveState: "1"
    };
  },

  async getLiveState(payload) {
    return { liveState: "1" };
  },

  async resolveShare(payload) {
    var p = laPayload(payload);
    var text = laStr(p.shareCode || p.shareUrl || p.url).trim();
    if (!text) laThrow("INVALID_ARGS", "shareCode required", {});
    var m = text.match(/stripchat\.com\/([A-Za-z0-9_]+)/i);
    if (m) {
      var streamId = await scResolveStreamId(m[1]);
      return {
        userName: m[1], roomTitle: "", roomCover: "", userHeadImg: "",
        userId: streamId, roomId: "stripchat@" + streamId, liveState: "1"
      };
    }
    laThrow("INVALID_ARGS", "无法解析分享链接", {});
  },

  async getDanmaku(payload) {
    return { args: {}, headers: null };
  }
};
