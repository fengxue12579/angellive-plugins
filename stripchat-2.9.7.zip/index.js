// ============================================================
// StripChat AngelLive Plugin v2.9.5
// Cookie 登录 | 直连播放 | 封面代理
// ============================================================

// ---- Login Credential Management ----
var _sc_loginPlatformId = "stripchat";
var _sc_loginRuntime = { credentialSynced: false, credentialStatus: { state: "missing", expireAt: 0, userId: "", userName: "", message: "" } };
function _sc_loginTrim(v) { return v === undefined || v === null ? "" : String(v).trim(); }
function _sc_loginBuildStatus(s) {
  var src = s && typeof s === "object" ? s : {};
  return { state: _sc_loginTrim(src.state) || "unknown", expireAt: src.expireAt || 0, userId: _sc_loginTrim(src.userId), userName: _sc_loginTrim(src.userName), message: _sc_loginTrim(src.message) };
}
function _sc_loginSetStatus(s) { _sc_loginRuntime.credentialStatus = _sc_loginBuildStatus(s); return _sc_loginBuildStatus(_sc_loginRuntime.credentialStatus); }
function _sc_loginMarkSynced(msg) { _sc_loginRuntime.credentialSynced = true; return _sc_loginSetStatus({ state: "unknown", expireAt: 0, userId: "", userName: "", message: _sc_loginTrim(msg) || "credential synced" }); }
function _sc_loginMarkCleared() { _sc_loginRuntime.credentialSynced = false; return _sc_loginSetStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "" }); }
function _sc_loginReadCookieHeader() { if (globalThis.Host && Host.session && typeof Host.session.getCookieHeader === "function") { return _sc_loginTrim(Host.session.getCookieHeader(_sc_loginPlatformId)); } return ""; }
function _sc_loginReadCookieValue(hdr, name) {
  var cookie = _sc_loginTrim(hdr), target = _sc_loginTrim(name);
  if (!cookie || !target) return "";
  var parts = cookie.split(";"); for (var i = 0; i < parts.length; i++) { var seg = _sc_loginTrim(parts[i]); if (!seg) continue; var idx = seg.indexOf("="); var key = idx >= 0 ? seg.slice(0, idx).trim() : seg; var val = idx >= 0 ? seg.slice(idx + 1).trim() : ""; if (key === target) return val; } return "";
}
function _sc_loginIsLoggedIn(hdr) { return _sc_loginReadCookieValue(hdr, "isLogged") === "1"; }
function _sc_loginCheckCredential() {
  var hdr = _sc_loginReadCookieHeader();
  if (!hdr) return _sc_loginSetStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未检测到 Cookie" });
  if (!_sc_loginIsLoggedIn(hdr)) return _sc_loginSetStatus({ state: "missing", expireAt: 0, userId: "", userName: "", message: "未登录，请使用账号密码登录" });
  var uuid = _sc_loginReadCookieValue(hdr, "moe_uuid") || _sc_loginReadCookieValue(hdr, "stripchat_com_sessionId") || "stripchat_user";
  return _sc_loginSetStatus({ state: "valid", expireAt: 0, userId: uuid, userName: "StripChat 用户", message: "" });
}

// ---- Constants ----
var _SC_BASE_URL = "https://go.mavrtracktor.com";
var _SC_PAGE_URL = "https://zh.stripchat.global";
var _SC_USER_AGENT = "Mozilla/5.0 (Linux; Android 15; 2407FRK8EC Build/AP3A.240617.008; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/128.0.6613.127 Mobile Safari/537.36";
var _SC_CDN_URL = "https://edge-hls.growcdnssedge.com";
var _SC_WORKER_URL = "https://stripchat-proxy.fengxue556.ccwu.cc"; // Worker签名画质服务
var _SC_API_HEADERS = { "User-Agent": _SC_USER_AGENT, "Referer": _SC_PAGE_URL + "/" };

// ---- Utility ----
function _sc_makeError(code, message, ctx) {
  if (globalThis.Host && typeof Host.makeError === "function") return Host.makeError(code || "UNKNOWN", message || "", ctx || {});
  return new Error("LP_PLUGIN_ERROR:" + JSON.stringify({ code: String(code || "UNKNOWN"), message: String(message || ""), context: ctx || {} }));
}
function _sc_throw(code, message, ctx) {
  if (globalThis.Host && typeof Host.raise === "function") Host.raise(code, message, ctx || {});
  throw _sc_makeError(code, message, ctx);
}

// CDN 前缀替换：doppiocdn（低画质低延迟）-> growcdnssedge（高画质）
var _SC_HD_CDN = "https://media-hls.growcdnssedge.com";
var _SC_LD_CDN_PATTERNS = [
    "media-hls.doppiocdn.org",
    "media-hls.doppiocdn.com",
    "media-hls.doppiocdn.net",
    "edge-hls.doppiocdn.org",
    "edge-hls.doppiocdn.com",
    "edge-hls.doppiocdn.net"
];
function _sc_upgradeToHD(url) {
    if (!url) return url;
    // 替换低画质 CDN 前缀为高画质 CDN
    for (var i = 0; i < _SC_LD_CDN_PATTERNS.length; i++) {
        if (url.indexOf(_SC_LD_CDN_PATTERNS[i]) >= 0) {
            url = url.replace("https://" + _SC_LD_CDN_PATTERNS[i], _SC_HD_CDN);
            break;
        }
    }
    // 去掉 playlistType=lowLatency（低延迟模式会降低画质）
    url = url.replace(/[&?]playlistType=lowLatency(&|$)/, function(m, tail) {
        return tail ? "&" : "";
    });
    // 清理末尾可能的 ?&残留
    url = url.replace(/[?&]$/, "");
    return url;
}

// URL 转换：图片代理 /scimg/
var _SC_IMG_PROXY = "https://stripchat-proxy.fengxue556.ccwu.cc";
function _sc_imgProxy(url) {
  if (!_SC_IMG_PROXY || !url) return url;
  var s = url.replace(/^https?:\/\//, ""), si = s.indexOf("/");
  return si < 0 ? url : _SC_IMG_PROXY + "/scimg/" + s;
}


// 画质数值排序：1080p60->1080, 720p->720, original->9999
function _sc_qn(key) { if (key === "original") return 9999; var m = String(key).match(/(\d+)/); return m ? parseInt(m[1], 10) : 0; }

// ---- HTTP Request (with retry) ----
function _sc_httpGet(url, timeout) {
  return Host.http.request({
    platformId: "stripchat", authMode: "platform_cookie",
    request: { url: url, method: "GET", headers: _SC_API_HEADERS, timeout: timeout || 20 }
  }).then(function (r) {
    if (r.status >= 500) throw _sc_makeError("NETWORK", "HTTP " + r.status);
    return r;
  });
}

// ---- Categories ----
function _sc_getCategories() {
  return Promise.resolve([
    { id: "girls/chinese", parentId: "", title: "女主播", icon: "", biz: "girls/chinese", subList: [
      { id: "girls/chinese", parentId: "girls/chinese", title: "中国女孩", icon: "", biz: "girls/chinese" },
      { id: "girls/japanese", parentId: "girls/chinese", title: "日本女孩", icon: "", biz: "girls/japanese" },
      { id: "girls/korean", parentId: "girls/chinese", title: "韩国女孩", icon: "", biz: "girls/korean" },
      { id: "girls/american", parentId: "girls/chinese", title: "美国女孩", icon: "", biz: "girls/american" },
      { id: "girls/russian", parentId: "girls/chinese", title: "俄罗斯女孩", icon: "", biz: "girls/russian" },
      { id: "girls/new", parentId: "girls/chinese", title: "最新女主播", icon: "", biz: "girls/new" }
    ]},
    { id: "couples/chinese", parentId: "", title: "情侣", icon: "", biz: "couples/chinese", subList: [
      { id: "couples/chinese", parentId: "couples/chinese", title: "中国情侣", icon: "", biz: "couples/chinese" },
      { id: "couples/popular", parentId: "couples/chinese", title: "热门情侣", icon: "", biz: "couples/popular" }
    ]},
    { id: "men/popular", parentId: "", title: "男主播", icon: "", biz: "men/popular", subList: [
      { id: "men/popular", parentId: "men/popular", title: "最受欢迎", icon: "", biz: "men/popular" },
      { id: "men/gays", parentId: "men/popular", title: "男同聊天", icon: "", biz: "men/gays" }
    ]},
    { id: "girls/recommended", parentId: "", title: "推荐", icon: "", biz: "girls/recommended", subList: [
      { id: "girls/recommended", parentId: "girls/recommended", title: "全部推荐", icon: "", biz: "girls/recommended" }
    ]},
    { id: "girls/popular", parentId: "", title: "热门", icon: "", biz: "girls/popular", subList: [
      { id: "girls/popular", parentId: "girls/popular", title: "全部热门", icon: "", biz: "girls/popular" }
    ]},
    { id: "couples/group-sex", parentId: "", title: "群交直播", icon: "", biz: "couples/group-sex", subList: [
      { id: "couples/group-sex", parentId: "couples/group-sex", title: "全部群交", icon: "", biz: "couples/group-sex" }
    ]},
    { id: "couples/lesbians", parentId: "", title: "女同", icon: "", biz: "couples/lesbians", subList: [
      { id: "couples/lesbians", parentId: "couples/lesbians", title: "全部女同", icon: "", biz: "couples/lesbians" }
    ]},
    { id: "girls/vr", parentId: "", title: "VR", icon: "", biz: "girls/vr", subList: [
      { id: "girls/vr", parentId: "girls/vr", title: "全部VR", icon: "", biz: "girls/vr" }
    ]},
    { id: "trans/popular", parentId: "", title: "变性人", icon: "", biz: "trans/popular", subList: [
      { id: "trans/popular", parentId: "trans/popular", title: "全部变性人", icon: "", biz: "trans/popular" }
    ]},
    { id: "girls/new", parentId: "", title: "新主播", icon: "", biz: "girls/new", subList: [
      { id: "girls/new", parentId: "girls/new", title: "全部新主播", icon: "", biz: "girls/new" }
    ]}
  ]);
}

// ---- API: Fetch models list ----
function _sc_fetchModels(cateId, page) {
  var url = _SC_BASE_URL + "/api/models?tag=" + encodeURIComponent(cateId)
    + "&forceClient=1&stripcashR=0&limit=200&offset=" + ((page - 1) * 200)
    + "&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";
  return _sc_httpGet(url, 20).then(function (r) {
    return JSON.parse(r.bodyText || "{}").models || [];
  });
}

// ---- Model -> Room mapping ----
function _sc_modelToRoom(m) {
  return {
    roomId: String(m.id || ""), userId: String(m.id || ""),
    userName: String(m.username || ""), roomTitle: String(m.username || ""),
    roomCover: _sc_imgProxy(String(m.snapshotUrl || "")),
    userHeadImg: _sc_imgProxy(String(m.avatarUrl || m.snapshotUrl || "")),
    liveType: "stripchat", liveState: "1",
    liveWatchedCount: String(m.viewersCount || "0")
  };
}

// ---- Core: getRooms ----
function _sc_getRooms(cateId, page) {
  return _sc_fetchModels(cateId, page).then(function (models) {
    return models.map(_sc_modelToRoom);
  });
}

// ---- Core: getRoomDetail ----
function _sc_getRoomDetail(roomId) {
  return _sc_fetchModels("girls/popular", 1).then(function (models) {
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) return _sc_modelToRoom(models[i]);
    }
    _sc_throw("NOT_FOUND", "room not found", { roomId: String(roomId) });
  });
}

// ---- Build quality object ----
function _sc_buildQuality(roomId, title, qn, url) {
  return {
    roomId: String(roomId), title: title, qn: qn, url: url,
    liveCodeType: "m3u8", liveType: "stripchat",
    userAgent: _SC_USER_AGENT,
    headers: { "Referer": _SC_PAGE_URL + "/" },
    playbackHints: { streamFormat: "hlsLive", selectionBehavior: "direct" }
  };
}

// ---- Build quality list from stream.urls ----
function _sc_buildQualitys(roomId, streamUrls) {
  var qualitys = [], keys = Object.keys(streamUrls);
  for (var i = 0; i < keys.length; i++) {
    var key = keys[i], url = streamUrls[key];
    if (!url) continue;
    qualitys.push(_sc_buildQuality(roomId, key === "original" ? "原画" : key.toUpperCase(), _sc_qn(key), _sc_upgradeToHD(url)));
  }
  return qualitys.sort(function (a, b) { return b.qn - a.qn; });
}

// ---- HLS Master Playlist Parser ----
function _sc_parseMaster(text, baseURL, roomId) {
  var lines = String(text).split(/\r?\n/), variants = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    // find next non-empty, non-comment line = URI
    var uri = "";
    for (var j = i + 1; j < lines.length; j++) {
      var t = lines[j].trim();
      if (t && t.charAt(0) !== "#") { uri = t; break; }
    }
    if (!uri) continue;
    // parse RESOLUTION
    var re = /RESOLUTION=(\d+)x(\d+)/i.exec(line);
    var h = re ? parseInt(re[2], 10) : 0;
    var bw = parseInt((line.match(/BANDWIDTH=(\d+)/i) || [])[1] || "0", 10);
    // resolve relative URL
    if (uri.indexOf("http") !== 0) {
      var base = baseURL.split("?")[0].split("#")[0];
      if (uri.charAt(0) === "/") {
        var pi = base.indexOf("://") + 3, ps = base.indexOf("/", pi);
        uri = (ps > 0 ? base.substring(0, ps) : base) + uri;
      } else {
        var ls = base.lastIndexOf("/");
        uri = (ls >= 0 ? base.substring(0, ls + 1) : base + "/") + uri;
      }
    }
    variants.push({ title: h > 0 ? h + "p" : "Auto", qn: h, bandwidth: bw, url: uri });
  }
  variants.sort(function (a, b) { return b.qn !== a.qn ? b.qn - a.qn : b.bandwidth - a.bandwidth; });
  var seen = {}, qualitys = [];
  for (var v = 0; v < variants.length; v++) {
    if (variants[v].url && !seen[variants[v].url]) {
      seen[variants[v].url] = true;
      qualitys.push(_sc_buildQuality(roomId, variants[v].title, variants[v].qn, _sc_upgradeToHD(variants[v].url)));
    }
  }
  return qualitys;
}

// ---- Core: getPlayback (optimized) ----
function _sc_getPlayback(roomId) {
  // 走 Worker 签名画质链路（模仿瑟瑟聚合模块1）
  var workerQualitiesUrl = _SC_WORKER_URL + "/qualities?room=" + encodeURIComponent(String(roomId));

  return _sc_httpGet(workerQualitiesUrl, 10).then(function (resp) {
    if (resp.status !== 200) {
      // Worker 不可用时回退直连
      return _sc_getPlaybackFallback(roomId);
    }
    var data = JSON.parse(resp.bodyText || "{}");
    var qualitys = (data.qualitys || []).map(function (q) {
      return _sc_buildQuality(roomId, q.title, q.qn, _sc_upgradeToHD(q.url));
    });

    if (qualitys.length === 0) {
      return _sc_getPlaybackFallback(roomId);
    }

    return [{ cdn: "worker-signed", displayName: "签名线路", qualitys: qualitys }];
  }).catch(function () {
    return _sc_getPlaybackFallback(roomId);
  });
}

// ---- Fallback: 直连画质（Worker不可用时） ----
function _sc_getPlaybackFallback(roomId) {
  var apiUrl = _SC_BASE_URL + "/api/models?tag=girls/popular"
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";

  return _sc_httpGet(apiUrl, 20).then(function (resp) {
    var obj = JSON.parse(resp.bodyText || "{}");
    var models = obj.models || [], found = null;
    for (var i = 0; i < models.length; i++) {
      if (String(models[i].id) === String(roomId)) { found = models[i]; break; }
    }

    var streamUrls = (found && found.stream && found.stream.urls) || {};
    var defaultQualitys = _sc_buildQualitys(roomId, streamUrls);

    if (defaultQualitys.length === 0) {
      var fallback = _SC_CDN_URL + "/hls/" + encodeURIComponent(String(roomId)) + "/master/" + encodeURIComponent(String(roomId)) + "_auto.m3u8";
      defaultQualitys = [_sc_buildQuality(roomId, "Auto", 0, fallback)];
    }

    return [{ cdn: "direct", displayName: "直连", qualitys: defaultQualitys }];
  });
}

// ---- Core: refreshPlayback ----
function _sc_refreshPlayback(roomId, cdnId) {
  // 走 Worker 签名画质链路
  var workerQualitiesUrl = _SC_WORKER_URL + "/qualities?room=" + encodeURIComponent(String(roomId));

  return _sc_httpGet(workerQualitiesUrl, 10).then(function (resp) {
    if (resp.status !== 200) return _sc_buildQuality(roomId, "Auto", 0, _SC_CDN_URL + "/hls/" + encodeURIComponent(String(roomId)) + "/master/" + encodeURIComponent(String(roomId)) + "_auto.m3u8");
    var data = JSON.parse(resp.bodyText || "{}");
    var qualitys = data.qualitys || [];
    if (qualitys.length > 0) {
      var best = qualitys[0]; // 1080p 优先
      return _sc_buildQuality(roomId, best.title, best.qn, best.url);
    }
    return _sc_buildQuality(roomId, "Auto", 0, _SC_CDN_URL + "/hls/" + encodeURIComponent(String(roomId)) + "/master/" + encodeURIComponent(String(roomId)) + "_auto.m3u8");
  }).catch(function () {
    return _sc_buildQuality(roomId, "Auto", 0, _SC_CDN_URL + "/hls/" + encodeURIComponent(String(roomId)) + "/master/" + encodeURIComponent(String(roomId)) + "_auto.m3u8");
  });
}

// ---- Core: search ----
function _sc_search(keyword) {
  var url = _SC_BASE_URL + "/api/models?q=" + encodeURIComponent(keyword)
    + "&forceClient=1&stripcashR=0&limit=200&usePreroll&webp=1&type=popular&timezone=Asia/Shanghai";
  return _sc_httpGet(url, 20).then(function (r) {
    return JSON.parse(r.bodyText || "{}").models || [];
  }).then(function (models) { return models.map(_sc_modelToRoom); });
}

// ---- Core: resolveShare ----
function _sc_resolveShare(shareCode) {
  var input = String(shareCode || "").trim();
  if (!input) _sc_throw("INVALID_ARGS", "shareCode is empty", { field: "shareCode" });
  var username = "";
  var m = input.match(/stripchat\.(?:global|com)\/([\w]+)/);
  if (m && m[1]) username = m[1];
  else if (/^[a-zA-Z0-9_]+$/.test(input)) username = input;
  if (!username) _sc_throw("NOT_FOUND", "cannot extract username", { shareCode: input });
  return Promise.resolve({ roomId: username, userId: username, userName: username, roomTitle: username, roomCover: "", userHeadImg: "", liveType: "stripchat", liveState: "1", liveWatchedCount: "0" });
}

// ============================================================
// Plugin Export
// ============================================================
globalThis.LiveParsePlugin = {
  apiVersion: 1,

  getCategories: function () { return _sc_getCategories(); },

  getRooms: function (payload) {
    var id = String(payload && payload.id ? payload.id : "");
    var page = payload && payload.page ? Number(payload.page) : 1;
    if (!id) _sc_throw("INVALID_ARGS", "id is required", { field: "id" });
    return _sc_getRooms(id, page);
  },

  getPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getPlayback(roomId);
  },

  refreshPlayback: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    var cdn = String((payload && payload.cdn) || "");
    var quality = (payload && payload.quality) || {};
    var ctx = quality.requestContext || {};
    var cdnId = String(ctx.cdn || cdn || "growcdn");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_refreshPlayback(roomId, cdnId);
  },

  getRoomDetail: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return _sc_getRoomDetail(roomId);
  },

  getLiveState: function (payload) {
    var roomId = String(payload && payload.roomId ? payload.roomId : "");
    if (!roomId) _sc_throw("INVALID_ARGS", "roomId is required", { field: "roomId" });
    return Promise.resolve({ liveState: "1" });
  },

  search: function (payload) {
    var keyword = String(payload && payload.keyword ? payload.keyword : "");
    if (!keyword) _sc_throw("INVALID_ARGS", "keyword is required", { field: "keyword" });
    return _sc_search(keyword);
  },

  resolveShare: function (payload) {
    var shareCode = String(payload && payload.shareCode ? payload.shareCode : "");
    if (!shareCode) _sc_throw("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    return _sc_resolveShare(shareCode);
  },

  clearCredential: function () { return Promise.resolve(_sc_loginMarkCleared()); },
  setCredential: function () { return Promise.resolve(Object.assign({ ok: true }, _sc_loginMarkSynced("credential synced"))); },
  getCredentialStatus: function () { return Promise.resolve(_sc_loginCheckCredential()); },
  validateCredential: function () { return Promise.resolve(_sc_loginCheckCredential()); }
};
