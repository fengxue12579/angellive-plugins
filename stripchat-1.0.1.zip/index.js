"use strict";
/* LiveParse platform plugin: Stripchat
 * pluginId: stripchat, version: 1.0.0, apiVersion: 1
 *
 * Host 能力: Host.http.request / Host.raise / Host.makeError
 * 网络统一走匿名请求，无需登录。
 *
 * Payload 字段约定（与官方插件保持一致）:
 *   getRooms({id, page, pageSize})
 *   getPlayback({roomId|userId})
 *   search({keyword, page, pageSize})
 *   getRoomDetail({roomId|userId})
 *   getLiveState({roomId|userId})
 *   resolveShare({shareCode|shareUrl})
 *   getDanmaku({roomId|userId})
 */

var SC_PLUGIN_ID = "stripchat";
var SC_API_BASE = "https://stripchat.com/api/front";
var SC_SITE = "https://stripchat.com";
var SC_LIVE_TYPE = "10";
var SC_DEFAULT_PAGE_SIZE = 51;
var SC_MAX_PAGE_SIZE = 100;
var SC_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
var SC_HLS_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:146.0) Gecko/20100101 Firefox/146.0";
var SC_CATEGORIES = ["girls", "couples", "men", "trans"];

/* ---------------- error ---------------- */

function scThrow(code, message, context) {
  if (globalThis.Host && typeof Host.raise === "function") {
    Host.raise(code, message, context || {});
  }
  if (globalThis.Host && typeof Host.makeError === "function") {
    throw Host.makeError(code || "UNKNOWN", message || "", context || {});
  }
  throw new Error(
    "LP_PLUGIN_ERROR:" +
      JSON.stringify({ code: String(code || "UNKNOWN"), message: String(message || ""), context: context || {} })
  );
}

/* ---------------- small utils ---------------- */

function scStr(v) {
  return v === undefined || v === null ? "" : String(v);
}

function scInt(v, fallback) {
  var n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function scPick(obj, keys) {
  if (!obj || typeof obj !== "object") return "";
  for (var i = 0; i < keys.length; i++) {
    var v = obj[keys[i]];
    if (v !== undefined && v !== null && String(v) !== "") return v;
  }
  return "";
}

function scRuntimePayload(payload) {
  return payload && typeof payload === "object" ? payload : {};
}

function scPageSize(v) {
  var n = Math.trunc(scInt(v, SC_DEFAULT_PAGE_SIZE));
  return Math.max(1, Math.min(SC_MAX_PAGE_SIZE, n));
}

/* ---------------- http ---------------- */

async function scHttpRequest(request, networkLabel) {
  var req = { timeout: 20 };
  for (var k in request) {
    if (Object.prototype.hasOwnProperty.call(request, k)) req[k] = request[k];
  }
  if (!req.headers) req.headers = {};
  try {
    return await Host.http.request({
      authMode: "none",
      followRedirects: false,
      request: req
    });
  } catch (_) {
    scThrow("NETWORK", "无法连接 Stripchat，请稍后重试", { reason: networkLabel || "network_error" });
  }
}

async function scGetJson(url) {
  var res = await scHttpRequest(
    {
      url: url,
      method: "GET",
      headers: {
        "User-Agent": SC_UA,
        "Referer": SC_SITE + "/",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-US,en;q=0.9"
      }
    },
    "api_network_error"
  );
  var status = scInt(res && (res.statusCode || res.status), 0);
  if (status && (status < 200 || status >= 300)) {
    scThrow("UPSTREAM", "Stripchat API 返回异常状态码", { status: status });
  }
  try {
    return JSON.parse(scStr(res && res.bodyText));
  } catch (_) {
    scThrow("INVALID_RESPONSE", "Stripchat API 返回非 JSON 数据", {});
  }
}

async function scGetText(url, headers) {
  var res = await scHttpRequest(
    {
      url: url,
      method: "GET",
      headers: Object.assign(
        { "User-Agent": SC_HLS_UA, "Referer": SC_SITE + "/", Accept: "*/*" },
        headers || {}
      )
    },
    "playlist_network_error"
  );
  return scStr(res && res.bodyText);
}

/* ---------------- model mapping ---------------- */

function scCountryFlag(code) {
  code = scStr(code).toUpperCase();
  if (!/^[A-Z]{2}$/.test(code)) return "";
  var out = "";
  for (var i = 0; i < 2; i++) {
    out += String.fromCodePoint(code.charCodeAt(i) - 65 + 0x1f1e6);
  }
  return out;
}

function scStatusText(status, viewers) {
  var s = scStr(status).toLowerCase();
  var t;
  if (s === "public") t = "🔴直播中";
  else if (s === "groupshow") t = "🎫门票房";
  else if (s === "ticket") t = "🎫购票房";
  else if (s === "off") t = "⚫已下播";
  else t = "🎫" + s;
  return viewers ? t + " 👤" + viewers + "人" : t;
}

/* "1" 直播中 / "0" 未开播 / "2" 付费房(门票/购票) */
function scLiveStateOf(status) {
  var s = scStr(status).toLowerCase();
  if (s === "public") return "1";
  if (s === "off") return "0";
  return "2";
}

function scModelToLive(m) {
  if (!m || typeof m !== "object") return null;
  var username = scStr(m.username).trim();
  var mid = scStr(m.id).trim();
  var streamName = scStr(m.streamName).trim();
  if (!username && !mid) return null;
  var status = scStr(m.status) || "off";
  var viewers = scInt(m.viewersCount, 0);
  var flag = scCountryFlag(m.country);
  var cover = "";
  if (mid && m.snapshotTimestamp) {
    cover = "https://img.doppiocdn.org/snapshot/" + mid + "/" + scStr(m.snapshotTimestamp);
  }
  var roomId = /^\d+$/.test(streamName) ? streamName : mid;
  return {
    userName: (flag ? flag : "") + username,
    roomTitle: scStatusText(status, viewers),
    roomCover: cover,
    userHeadImg: cover,
    userId: username || roomId,
    roomId: roomId || username,
    liveState: scLiveStateOf(status),
    liveWatchedCount: viewers ? String(viewers) : ""
  };
}

function scExtractModels(data) {
  var models = [];
  if (data && Array.isArray(data.models)) {
    models = data.models;
  } else if (data && Array.isArray(data.blocks)) {
    for (var i = 0; i < data.blocks.length; i++) {
      var b = data.blocks[i];
      if (b && Array.isArray(b.models)) models = models.concat(b.models);
    }
  }
  return models;
}

/* ---------------- m3u8 variant parsing ---------------- */

function scJoinUrl(base, rel) {
  if (!rel) return "";
  if (/^https?:\/\//i.test(rel)) return rel;
  var b = scStr(base).replace(/\/+$/, "");
  if (rel.charAt(0) === "/") {
    var m = b.match(/^(https?:\/\/[^\/]+)/i);
    return (m ? m[1] : b) + rel;
  }
  return b + "/" + rel;
}

function scParseMasterVariants(text, baseUrl) {
  var lines = scStr(text).split("\n");
  var variants = [];
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].trim();
    if (line.indexOf("#EXT-X-STREAM-INF:") !== 0) continue;
    var bwM = line.match(/BANDWIDTH=(\d+)/i);
    var nameM = line.match(/NAME="([^"]+)"/i);
    var resM = line.match(/RESOLUTION=(\d+)x(\d+)/i);
    var next = (lines[i + 1] || "").trim();
    if (!next || next.charAt(0) === "#") continue;
    var name = nameM ? nameM[1] : "";
    if (/blurred/i.test(name)) continue;
    variants.push({
      bandwidth: bwM ? parseInt(bwM[1], 10) : 0,
      name: name,
      width: resM ? parseInt(resM[1], 10) : 0,
      height: resM ? parseInt(resM[2], 10) : 0,
      url: scJoinUrl(baseUrl, next)
    });
  }
  return variants;
}

function scVariantScore(v) {
  var h = v.height || 0;
  var n = scStr(v.name).toLowerCase();
  if (n === "source" || n === "orig" || n === "original") h = Math.max(h, 2160);
  return h * 1e9 + (v.bandwidth || 0);
}

function scQualityTitle(v) {
  var n = scStr(v.name).toLowerCase();
  if (n === "source" || n === "orig" || n === "original") return "原画";
  var h = v.height || 0;
  if (h >= 1600) return "原画";
  if (h >= 1000) return "1080p";
  if (h >= 700) return "720p";
  if (h >= 460) return "480p";
  if (h > 0) return h + "p";
  if (/1080/.test(n)) return "1080p";
  if (/720/.test(n)) return "720p";
  if (/480/.test(n)) return "480p";
  return n || "未知";
}

/* username -> numeric stream id */
async function scResolveStreamId(username) {
  var uname = scStr(username).trim();
  if (/^\d+$/.test(uname)) return uname;
  var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(uname));
  if (data) {
    var sid = scStr(data.streamName || data.id).trim();
    if (/^\d+$/.test(sid)) return sid;
  }
  var s = await scGetJson(
    SC_API_BASE + "/v4/models/search/suggestion?query=" + encodeURIComponent(uname) + "&limit=8&primaryTag=girls"
  );
  var models = s && Array.isArray(s.models) ? s.models : [];
  if (models.length) {
    var ql = uname.toLowerCase();
    var hit = null;
    for (var i = 0; i < models.length; i++) {
      if (scStr(models[i].username).toLowerCase() === ql) {
        hit = models[i];
        break;
      }
    }
    hit = hit || models[0];
    var sid2 = scStr(hit.streamName || hit.id).trim();
    if (/^\d+$/.test(sid2)) return sid2;
  }
  return "";
}

function scPlaybackHeaders() {
  return {
    "User-Agent": SC_HLS_UA,
    "Referer": SC_SITE + "/",
    "Accept-Language": "en,zh-CN;q=0.9,zh;q=0.8"
  };
}

/* ---------------- plugin entry ---------------- */

globalThis.LiveParsePlugin = {
  apiVersion: 1,

  async getCategories(payload) {
    scRuntimePayload(payload);
    var tags = [
      { id: "autoTagNew", title: "新主播", biz: "autoTagNew" },
      { id: "recommended", title: "推荐", biz: "recommended" },
      { id: "tagLanguageChinese", title: "🇨🇳中国", biz: "tagLanguageChinese" },
      { id: "ethnicityAsian", title: "亚洲人", biz: "ethnicityAsian" },
      { id: "tagLanguageJapanese", title: "🇯🇵日本", biz: "tagLanguageJapanese" },
      { id: "tagLanguageKorean", title: "🇰🇷韩国", biz: "tagLanguageKorean" },
      { id: "ageTeen", title: "青年", biz: "ageTeen" },
      { id: "autoTagInteractiveToy", title: "互动玩具", biz: "autoTagInteractiveToy" }
    ];
    var defs = [
      { id: "girls", title: "女主播" },
      { id: "couples", title: "情侣" },
      { id: "men", title: "男主播" },
      { id: "trans", title: "跨性别" }
    ];
    return defs.map(function (d) {
      return {
        id: d.id,
        title: d.title,
        icon: "",
        biz: "",
        subList: tags.map(function (t) {
          return { id: t.id, parentId: d.id, title: t.title, icon: "", biz: t.biz };
        })
      };
    });
  },

  async getRooms(payload) {
    var p = scRuntimePayload(payload);
    var categoryId = scStr(p.id) || "girls";
    if (SC_CATEGORIES.indexOf(categoryId) < 0) categoryId = "girls";
    var page = Math.max(1, scInt(p.page, 1));
    var pageSize = scPageSize(p.pageSize);
    var tag = scStr(p.tag);
    var offset = (page - 1) * pageSize;
    var url =
      SC_API_BASE +
      "/v2/models?primaryTag=" +
      encodeURIComponent(categoryId) +
      "&limit=" +
      pageSize +
      "&offset=" +
      offset +
      "&sortBy=stripRanking";
    if (tag) {
      url += "&filterGroupTags=" + encodeURIComponent('[["' + tag + '"]]');
    }
    var data = await scGetJson(url);
    var models = scExtractModels(data);
    var out = [];
    for (var i = 0; i < models.length; i++) {
      var live = scModelToLive(models[i]);
      if (live) out.push(live);
    }
    return out;
  },

  async getPlayback(payload) {
    var p = scRuntimePayload(payload);
    var rawId = scStr(p.roomId || p.userId).trim();
    if (!rawId) {
      scThrow("INVALID_ARGS", "roomId is required", { field: "roomId" });
    }
    var streamId = await scResolveStreamId(rawId);
    if (!streamId) {
      scThrow("NOT_FOUND", "无法解析 Stripchat 主播的流 ID", { roomId: rawId });
    }

    var masters = [
      "https://edge-hls.doppiocdn.org/hls/" + streamId + "/master/" + streamId + "_auto.m3u8",
      "https://edge-hls.growcdnssedge.com/hls/" + streamId + "/master/" + streamId + "_auto.m3u8"
    ];
    var seen = {};
    for (var mi = 0; mi < masters.length; mi++) {
      var mu = masters[mi];
      var text = await scGetText(mu);
      var t = text.trim();
      if (!t || t.indexOf("#EXTM3U") !== 0) continue;
      if (t.indexOf("#EXT-X-MOUFLON-ADVERT") >= 0 && t.indexOf("#EXT-X-STREAM-INF") < 0) continue;
      if (t.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") >= 0) continue;
      var base = mu.substring(0, mu.lastIndexOf("/") + 1);
      var variants = scParseMasterVariants(t, base);
      for (var vi = 0; vi < variants.length; vi++) {
        var v = variants[vi];
        if (!v.url) continue;
        var path = v.url.replace(/^https?:\/\/[^\/]+/i, "");
        var key = v.height + "|" + path;
        if (!seen[key] || scVariantScore(v) > scVariantScore(seen[key])) seen[key] = v;
      }
      if (Object.keys(seen).length > 0) break;
    }

    var sorted = Object.keys(seen)
      .map(function (k) {
        return seen[k];
      })
      .sort(function (a, b) {
        return scVariantScore(b) - scVariantScore(a);
      });

    var headers = scPlaybackHeaders();
    var qualitys = [];
    var usedTitles = {};
    for (var qi = 0; qi < sorted.length; qi++) {
      var vv = sorted[qi];
      var title = scQualityTitle(vv);
      if (usedTitles[title]) {
        title = title + " " + (vv.height ? vv.height + "p" : String(vv.bandwidth));
      }
      usedTitles[title] = true;
      qualitys.push({
        roomId: streamId,
        title: title,
        qn: vv.height || 0,
        url: vv.url,
        liveCodeType: "m3u8",
        liveType: SC_LIVE_TYPE,
        userAgent: SC_HLS_UA,
        headers: headers
      });
    }

    /* 自动: master playlist，播放器自适应清晰度 */
    qualitys.push({
      roomId: streamId,
      title: "自动",
      qn: -1,
      url: masters[0],
      liveCodeType: "m3u8",
      liveType: SC_LIVE_TYPE,
      userAgent: SC_HLS_UA,
      headers: headers
    });

    if (!qualitys.length) {
      scThrow("NOT_FOUND", "Stripchat 未返回可用播放地址", { roomId: rawId });
    }
    return [{ cdn: "doppiocdn", qualitys: qualitys }];
  },

  async search(payload) {
    var p = scRuntimePayload(payload);
    var keyword = scStr(p.keyword).trim();
    if (!keyword) {
      scThrow("INVALID_ARGS", "keyword is required", { field: "keyword" });
    }
    var results = await Promise.all(
      SC_CATEGORIES.map(function (t) {
        var url =
          SC_API_BASE +
          "/v4/models/search/group/username?query=" +
          encodeURIComponent(keyword) +
          "&limit=900&primaryTag=" +
          t;
        return scGetJson(url);
      })
    );
    var seen = {};
    var out = [];
    for (var i = 0; i < results.length; i++) {
      var arr = results[i] && Array.isArray(results[i].models) ? results[i].models : [];
      for (var j = 0; j < arr.length; j++) {
        var live = scModelToLive(arr[j]);
        if (!live) continue;
        var key = live.userId || live.roomId;
        if (seen[key]) continue;
        seen[key] = true;
        out.push(live);
      }
    }
    out.sort(function (a, b) {
      var d = scInt(b.liveState, 0) - scInt(a.liveState, 0);
      if (d !== 0) return d;
      return scInt(b.liveWatchedCount, 0) - scInt(a.liveWatchedCount, 0);
    });
    return out;
  },

  async getRoomDetail(payload) {
    var p = scRuntimePayload(payload);
    var rawId = scStr(p.roomId || p.userId).trim();
    if (!rawId) {
      scThrow("INVALID_ARGS", "roomId is required", { field: "roomId" });
    }
    if (/^\d+$/.test(rawId)) {
      return {
        userName: "",
        roomTitle: "",
        roomCover: "",
        userHeadImg: "",
        userId: rawId,
        roomId: rawId,
        liveState: "3"
      };
    }
    var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(rawId));
    if (!data || (!data.id && !data.username)) {
      scThrow("NOT_FOUND", "Stripchat 主播不存在", { roomId: rawId });
    }
    return (
      scModelToLive(data) || {
        userName: rawId,
        roomTitle: "",
        roomCover: "",
        userHeadImg: "",
        userId: rawId,
        roomId: rawId,
        liveState: "3"
      }
    );
  },

  async getLiveState(payload) {
    var p = scRuntimePayload(payload);
    var rawId = scStr(p.roomId || p.userId).trim();
    if (!rawId) {
      scThrow("INVALID_ARGS", "roomId is required", { field: "roomId" });
    }
    if (!/^\d+$/.test(rawId)) {
      var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(rawId));
      var status = scStr(data && data.status).toLowerCase();
      return { liveState: status === "public" ? "1" : "0" };
    }
    var mu = "https://edge-hls.doppiocdn.org/hls/" + rawId + "/master/" + rawId + "_auto.m3u8";
    var text = await scGetText(mu);
    var t = text.trim();
    if (
      t.indexOf("#EXTM3U") === 0 &&
      t.indexOf("#EXT-X-STREAM-INF") >= 0 &&
      t.indexOf("#EXT-X-MOUFLON-ADVERT") < 0 &&
      t.indexOf("#EXT-X-PLAYLIST-TYPE:VOD") < 0
    ) {
      return { liveState: "1" };
    }
    return { liveState: "0" };
  },

  async resolveShare(payload) {
    var p = scRuntimePayload(payload);
    var shareCode = scStr(p.shareCode || p.shareUrl || p.url).trim();
    if (!shareCode) {
      scThrow("INVALID_ARGS", "shareCode is required", { field: "shareCode" });
    }
    var m = shareCode.match(/stripchat\.com\/(?:cams?\/)?([A-Za-z0-9_\-]+)/i);
    var username = m ? m[1] : "";
    if (!username || /^(api|static|www)$/i.test(username)) {
      scThrow("PARSE", "无法从分享链接解析 Stripchat 主播名", { shareCode: shareCode });
    }
    var data = await scGetJson(SC_API_BASE + "/v2/models/username/" + encodeURIComponent(username));
    if (!data || (!data.id && !data.username)) {
      scThrow("NOT_FOUND", "Stripchat 主播不存在", { username: username });
    }
    return scModelToLive(data);
  },

  async getDanmaku(payload) {
    scRuntimePayload(payload);
    /* Stripchat 无公开弹幕接口 */
    return { args: {}, headers: null };
  }
};
